data:extend({
  {
    type = "font",
    name = "RecipeBook",
    from = "RecipeBook",
    size = 12,
    filtered = true,
  },
})
