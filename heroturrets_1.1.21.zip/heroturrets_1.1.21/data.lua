﻿heroturrets = { util = get_liborio() }

--require("wiki") 
--wiki_register_mod_wiki(heroturrets_wiki)

