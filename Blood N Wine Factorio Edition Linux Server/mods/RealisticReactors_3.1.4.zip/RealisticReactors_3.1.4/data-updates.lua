require("prototypes.patch_other_mods")
