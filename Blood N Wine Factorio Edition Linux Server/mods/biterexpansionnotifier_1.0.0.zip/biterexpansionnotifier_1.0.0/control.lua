global.benn = {x = 0, y = 0}

local function x_distance(pos1, pos2)
  return math.abs(pos1.x - pos2.x)
end

local function y_distance(pos1, pos2)
  return math.abs(pos1.y - pos2.y)
end

local function distance(pos1, pos2)
  return math.sqrt(
    (x_distance(pos1, pos2) ^ 2) + (y_distance(pos1, pos2) ^ 2)
  )
end




local function re_init(event)
  -- Build global state if it doesn't exist (i.e. mod update)
  global.benn = global.benn or {x = 0, y = 0}
end

script.on_init(re_init)
script.on_configuration_changed(re_init)

script.on_event(defines.events.on_biter_base_built, function(event)
  local built_base = event.entity
  if built_base.valid then
    -- This gets called for every biter sacrificed
    local base_position = built_base.position
    if distance(global.benn, built_base.position) > 1 then
      for _, player in pairs(game.connected_players) do
        local player_settings = settings.get_player_settings(player)
        if player_settings["benn-biter-chat-alert"].value then
          player.print({"alert-description.biter-base-built-desc", math.floor(base_position.x+0.5), math.floor(base_position.y+0.5), built_base.surface.name})
        end
        if player_settings["benn-biter-map-alert"].value then
          player.add_custom_alert(
            built_base,
            {
              type = "virtual",
              name = "biter-warning"
            },
            {"alert-description.biter-base-built", math.floor(base_position.x+0.5), math.floor(base_position.y+0.5), built_base.surface.name},
            true
          )          
        end
      end
      global.benn = base_position   
    end
  end
end)