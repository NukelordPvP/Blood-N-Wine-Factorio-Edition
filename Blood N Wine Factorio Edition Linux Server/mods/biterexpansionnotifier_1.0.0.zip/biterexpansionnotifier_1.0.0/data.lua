data:extend(
{
  {
    type = "virtual-signal",
    name = "biter-warning",
    icon = "__biterexpansionnotifier__/graphics/biter-warning.png",
    icon_size = 64
  }
}
)
