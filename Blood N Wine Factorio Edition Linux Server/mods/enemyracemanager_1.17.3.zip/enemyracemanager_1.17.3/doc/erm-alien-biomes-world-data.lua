world = {
  aux = {
    max = 1,
    min = 0
  },
  elevation = {
    max = 66.908134460449219,
    min = -44.176467895507813
  },
  enemy_base_probability = {
    max = 5.8135747909545898,
    min = -1016.4248046875
  },
  moisture = {
    max = 1,
    min = 0
  },
  temperature = {
    max = 150,
    min = -20
  }
}