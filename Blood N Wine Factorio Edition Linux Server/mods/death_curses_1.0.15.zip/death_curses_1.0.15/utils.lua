
local format_time   = util.formattime
function format_time_from_tick(ThatTick)
  if game.tick > ThatTick then return format_time(game.tick-ThatTick)
  else return format_time(ThatTick - game.tick)
  end
end


function getDayTimeString(player)
 local daytime = player.surface.daytime + 0.5
 local dayminutes = math.floor(daytime * 24 * 60) % 60
 local dayhour = math.floor(daytime * 24 ) % 24
return string.format("%02d:%02d", dayhour, dayminutes)
end



function format_evolution(force)
 return string.format("%.2f", math.floor(force.evolution_factor * 1000) / 10)
end



function get_gps_tag(position)
if get_gps_tag then 
	return '[gps='..math.floor(position.x)..','..math.floor(position.y)..']'
	else return ''
	end
end



--------------------------------------------------------------------------------------
function iif( cond, val1, val2 )
	if cond then
		return val1
	else
		return val2
	end
end


--for k,v in Sort_a_Table(your_table, function(t,a,b) return t[b] > t[a] end) do
function Sort_a_Table(t, order)
    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys 
    if order then
        table.sort(keys, function(a,b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end

--------------------------------------------------------------------------------------
function add_list(list, obj)
	-- to avoid duplicates...
	for i, obj2 in pairs(list) do
		if obj2 == obj then
			return(false)
		end
	end
	table.insert(list,obj)
	return(true)
end

--------------------------------------------------------------------------------------
function del_list(list, obj)
	for i, obj2 in pairs(list) do
		if obj2 == obj then
			table.remove( list, i )
			return(true)
		end
	end
	return(false)
end
--------------------------------------------------------------------------------------
function del_list2(list, list2)
	for i, obj2 in pairs(list2) do del_list(list, obj2) end
end
--------------------------------------------------------------------------------------
function in_list(list, obj)
	for k, obj2 in pairs(list) do
		if obj2 == obj then
			return(k)
		end
	end
	return(nil)
end

