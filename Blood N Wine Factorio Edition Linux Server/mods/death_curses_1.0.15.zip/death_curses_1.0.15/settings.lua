

data:extend({

	{
	    type = "bool-setting",
	    name = "dc_show_death_count",
	    setting_type = "runtime-per-user",
	    default_value = true,
	},

	{
	    type = "bool-setting",
	    name = "dc_enable_corpse_tag",
	    setting_type = "runtime-per-user",
	    default_value = true,
	},

	{
	    type = "bool-setting",
	    name = "dc_enable_curses",
	    setting_type = "runtime-global",
	    default_value = true,
	},
	
	{
	    type = "bool-setting",
	    name = "dc_enable_screams",
	    setting_type = "runtime-global",
	    default_value = true,
	},
	
	{
	type = "int-setting",
	name = "dc_curse_duration",
	setting_type = "runtime-global",
	default_value = 8,
	minimum_value = 1,
	maximum_value = 100,
	}, 

	
})
