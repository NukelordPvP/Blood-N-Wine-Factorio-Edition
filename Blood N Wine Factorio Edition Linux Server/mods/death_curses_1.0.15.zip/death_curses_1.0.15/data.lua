
data:extend({
   {
      type="sprite",
      name="dc_death_icon",
      filename = "__death_curses__/graphics/death_icon_32.png",
      priority = "extra-high",
      width = 32,
      height= 32,
   },
   {
      type="sprite",
      name="dc_curse_icon",
      filename = "__death_curses__/graphics/death_red_icon_32.png",
      priority = "extra-high",
      width = 32,
      height= 32,
   },
   
    {
      type = "virtual-signal",
      name = "dc_signal_death",
      icon = "__death_curses__/graphics/death_icon_64.png",
      icon_size = 64,
	  subgroup = "virtual-signal",
      order = "s[signal]-a"
    } ,  
    {
      type = "virtual-signal",
      name = "dc_signal_curse",
      icon = "__death_curses__/graphics/death_red_icon_64.png",
      icon_size = 64,
	  subgroup = "virtual-signal",
      order = "s[signal]-a"
    }   
   
})



local s= {
    type = "sound",
    name = "dc_deah_scream", 
    category = "gui-effect",
    volume = 1.0,
    audible_distance_modifier = 200,	
    variations = {}
  }
for m=1,11 do table.insert(s.variations,{filename = "__death_curses__/sounds/scream"..m..".ogg"}) end  
data:extend({s})

