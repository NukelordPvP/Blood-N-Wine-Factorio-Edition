data:extend{
{
    type = "projectile",
    name = "dp-destroyer",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
        {
        type = "direct",
        action_delivery =
        {
            type = "instant",
            target_effects =
            {
            {
                type = "destroy-decoratives",
                from_render_layer = "decorative",
                to_render_layer = "object",
                include_soft_decoratives = true, -- soft decoratives are decoratives with grows_through_rail_path = true
                include_decals = false,
                invoke_decorative_trigger = true,
                decoratives_with_trigger_only = false, -- if true, destroys only decoratives that have trigger_effect set
                radius = 1
            }
            }
        }
        }
    }
}
}