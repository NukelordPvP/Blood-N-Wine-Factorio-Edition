data:extend{
  {
    type = "bool-setting",
    name = "se-add-menu-simulations",
    setting_type = "startup",
    default_value = true,
    order = "a-a"
  },
  {
    type = "bool-setting",
    name = "se-remove-vanilla-simulations",
    setting_type = "startup",
    default_value = true,
    order = "a-b"
  },
  {
    type = "int-setting",
    name = "se-default-simulation-length",
    setting_type = "startup",
    default_value = 60,
    minimum_value = 1,
    maximum_value = 10000,
    order = "a-c"
  }
}