local e = defines.events

local function setup_globals()
    global.driving = global.driving or {}
end

script.on_init(setup_globals)
script.on_configuration_changed(setup_globals)

local abs, min, tanh, sin, cos = math.abs, math.min, math.tanh, math.sin, math.cos
local tau = math.pi * 2

local vec = {}
function vec.new(n) return {x = n, y = n} end
function vec.add(a, b) return {x = a.x + b.x, y = a.y + b.y} end
function vec.mul(v, n) return {x = v.x * n, y = v.y * n} end
function vec.div(v, n) return {x = v.x / n, y = v.y / n} end
function vec.rotate(v, a) return {x = (v.x * cos(a)) - (v.y * sin(a)), y = (v.x * sin(a)) + (v.y * cos(a))} end

---@param car LuaEntity
---@return Vector.0
local function speed_vector(car)
    local mag = car.speed
    local angle = (car.orientation - 0.25) * tau
    local x = cos(angle) * mag
    local y = sin(angle) * mag
    return {x = x, y = y}
end

local offset = 1/32
---@param car LuaEntity
---@param pos MapPosition
---@return boolean
local function car_collides(car, pos)
    local surface = car.surface
    if surface.entity_prototype_collides(car, pos, false) then return true end
    local dummy = car.name .. "-dummy"
    local box = car.prototype.collision_box
    local angle = car.orientation * tau
    local points = {
        vec.add(pos, vec.rotate({x = box.left_top.x - offset, y = box.left_top.y - offset}, angle)),
        vec.add(pos, vec.rotate({x = box.right_bottom.x + offset, y = box.left_top.y - offset}, angle)),
        vec.add(pos, vec.rotate({x = box.right_bottom.x + offset, y = box.right_bottom.y + offset}, angle)),
        vec.add(pos, vec.rotate({x = box.left_top.x - offset, y = box.right_bottom.y + offset}, angle)),
    }
    -- rendering.clear()
    for _, point in pairs(points) do
        -- rendering.draw_rectangle{
        --     color = {0,1,0},
        --     filled = true,
        --     left_top = {x = point.x - 1/128, y = point.y - 1/128},
        --     right_bottom = {x = point.x + 1/128, y = point.y + 1/128},
        --     surface = car.surface,
        --     draw_on_ground = false,
        -- }
        if surface.entity_prototype_collides(dummy, point, false) then return true end
    end
    return false
end

local penalty = 0.77
script.on_event(e.on_tick, function(event)
    local drift = settings.global["svp-drift"].value
    local handling = settings.global["svp-handling"].value
    for k, data in pairs(global.driving) do
        ---@cast data DrivingData
        local car = data.car
        if not car.valid then
        global.driving[k] = nil
        goto continue
        end
        local speed = abs(car.speed) --[[@as float]]
        if speed == 0 and data.speed == 0 then
            data.position = car.position
            data.orientation = car.orientation
            goto continue
        end
        local accelerating = speed > data.speed
        local difference = (car.orientation - data.orientation)
        difference = difference > 0.5 and difference - 1 or difference < -0.5 and difference + 1 or difference
        local _drift = accelerating and drift or drift * penalty
        local _handling = accelerating and 1 - ((1 - handling) * penalty) or handling
        _handling = 1 - _handling * min(abs(difference) * 100, 1)
        local rotation = ((1 - _handling) * tanh(-3.5 * speed + 1.6) + _handling + 1) / 2
        local friction = _drift * (tanh(4.5 * speed - 2) + 1) / 2
        local vector = vec.div(vec.add(vec.mul(data.vector, friction), speed_vector(car)), friction + 1)
        local new_pos = vec.add(data.position, vector)
        local pos = car.position
        car.teleport(vec.add(pos, vec.new(10)))
        if car_collides(car, new_pos) then
            new_pos = pos
            car.speed = 0
            speed = 0
        end
        car.teleport(new_pos)
        car.orientation = data.orientation + difference * rotation
        data.vector = vector
        data.speed = speed --[[@as float]]
        data.position = car.position
        data.orientation = car.orientation
        ::continue::
    end
end)

script.on_event(e.on_player_driving_changed_state, function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    local entity = event.entity
    if entity and entity.type == "car" then
        global.driving[entity.unit_number] = nil
    end
    local car = player.vehicle
    if car and car.type == "car" then
        ---@class DrivingData
        global.driving[car.unit_number] = {
            car = car,
            speed = abs(car.speed),
            position = car.position,
            orientation = car.orientation,
            vector = speed_vector(car)
        }
    end
end)

do return end

local player = {} --[[@as LuaPlayer]]

local hand_location = player.hand_location
local cursor_stack = {}
if hand_location then
    cursor_stack.name = player.cursor_stack.name
    cursor_stack.count = player.cursor_stack.count
    player.clear_cursor()
end

-- do your stuff here

if hand_location then
    player.cursor_stack.set_stack(cursor_stack)
    local inventory = player.get_inventory(hand_location.inventory)
    local slot = inventory[hand_location.slot]
    slot.set_stack{name = cursor_stack.name, count = slot.count - cursor_stack.count}
end