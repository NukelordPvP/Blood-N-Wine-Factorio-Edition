------------------------------
---- data-updates.lua ----
------------------------------

-- Define code stage
OSM.data_stage = 2

-- Update data types
require("__osm-lib__.core.data-definitions")