require("__Warmonger__/prototypes/categories/recipe-categories")
require("__Warmonger__/prototypes/entities/buildings/pipe-patch")
require("__Warmonger__/prototypes/entities/remnants/kr-big-random-pipes-remnant")
require("__Warmonger__/prototypes/entities/buildings/bio-lab")
require("__Warmonger__/prototypes/items/creep-items")
require("__Warmonger__/prototypes/recipes/creep-recipes")
require("__Warmonger__/prototypes/entities/buildings/creep-processing")
require("__Warmonger__/prototypes/technologies/biomass-tech")
require("__Warmonger__/prototypes/sounds/sounds")
require("__Warmonger__/prototypes/tiles/creep-tile")
require("__Warmonger__/prototypes/entities/remnants/strike-back")


require("__Warmonger__/prototypes/others/key-bind-initialization")
require("__Warmonger__/prototypes/others/shortcut")

