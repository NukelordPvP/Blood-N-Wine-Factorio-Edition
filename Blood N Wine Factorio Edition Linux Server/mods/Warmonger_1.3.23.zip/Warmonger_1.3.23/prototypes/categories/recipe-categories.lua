data:extend({
  {
    type = "recipe-category",
    name = "bioprocessing"
  },

  {
    type = "recipe-category",
    name = "creep-raw-material-recipe"
  }
})
