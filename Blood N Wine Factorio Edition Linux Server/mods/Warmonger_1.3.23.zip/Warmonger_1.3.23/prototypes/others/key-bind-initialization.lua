data:extend({
  {
    type = "custom-input",
    name = "kr-creep-collector",
    key_sequence = "ALT + C",
    action = "spawn-item",
    item_to_spawn = "kr-creep-collector",
  }
})
