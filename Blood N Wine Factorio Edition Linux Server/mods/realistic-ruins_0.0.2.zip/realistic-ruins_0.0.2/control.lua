local ruin_set = require("ruins/realistic") -- an array of ruins

local function add(name, parent)
    local ruins = remote.call("AbandonedRuins", "get_ruin_set", parent)
    if not ruins then return end
    for size,set in pairs(ruin_set) do
        local abandoned = ruins[size]
        for name,rest in pairs(set) do
            if game.active_mods[name] then
                for _,ruin in ipairs(rest) do
                    table.insert(abandoned, ruin)
                end
            end
        end
    end
    remote.call("AbandonedRuins", "add_ruin_set", name, ruins.small, ruins.medium, ruins.large)
end

local function make_ruin_set()
    add("realistic", "base")
    add("realistic-krastorio", "krastorio2")
end

script.on_init(make_ruin_set)
-- script.on_load(make_ruin_set)
script.on_nth_tick(1, function ()
    script.on_nth_tick(1, nil)
    make_ruin_set()
end)
