return
{
  entities =
  {
    {"curved-rail",   {x = -4, y = -4}, {dir = "northwest", force = "enemy", }},
    {"straight-rail", {x = -7, y =  1}, {dir = "east", force = "enemy", dead = 1, }},
    {"straight-rail", {x =  8, y =  1}, {dir = "east", force = "enemy", dead = 1, }},
    {"straight-rail", {x =  3, y = -3}, {dir = "east", force = "enemy", dead = 1, }},
    {"straight-rail", {x =  1, y = -3}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x = -5, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x = -3, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x = -1, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x =  1, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x =  3, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x =  5, y =  1}, {dir = "east", force = "enemy", }},
    {"straight-rail", {x =  7, y =  1}, {dir = "east", force = "enemy", }},
    {"artillery-wagon", {x = -2.4, y = -3.5}, {force = "enemy", dead = 1, }},
    {"fluid-wagon", {x = -5.26, y = -4.79}, {force = "enemy", dead = 1, }},
    {"cargo-wagon", {x = -2.84, y = 1}, {force = "enemy", dead = 1, }},
    {"locomotive", {x = 4.16, y = 1}, {force = "enemy", dead = 1, }},
  },
}
