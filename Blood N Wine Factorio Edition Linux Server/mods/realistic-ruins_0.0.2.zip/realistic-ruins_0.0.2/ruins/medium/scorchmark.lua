return
{
  entities =
  {
    {"huge-scorchmark", {x = 0, y = 0}, {}},
  },
}
