return
{
  entities =
  {
    {"rock-big", {x = -4.03, y = -3.86}, {}},
    {"rock-big", {x = -0.55, y = -4.72}, {}},
    {"rock-big", {x =  3.38, y = -2.82}, {}},
    {"rock-big", {x = -6.07, y = -0.52}, {}},
    {"rock-big", {x =  5.26, y =  1.06}, {}},
    {"rock-big", {x = -4.82, y =  3.66}, {}},
    {"rock-big", {x = -0.57, y =  5.61}, {}},
    {"rock-big", {x =  3.50, y =  5.07}, {}},
  },
}
