return
{
  entities =
  {
    {"crash-site-assembling-machine-2-repaired", {x = 0, y = 0}, {recipe = "storage-tank", }},
  },
}
