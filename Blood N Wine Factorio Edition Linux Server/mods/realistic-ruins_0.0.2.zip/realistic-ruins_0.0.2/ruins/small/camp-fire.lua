return
{
  entities =
  {
    {"dead-dry-hairy-tree", {x = 1.15, y = 2}, {}},
    {"wooden-chest", {x = 0, y = -2}, {items = {wood = 23}, dead = 0.9, }},
    {"camp-fire", {x = -1.15, y = 1.23}, {force = "enemy"}},
  },
}
