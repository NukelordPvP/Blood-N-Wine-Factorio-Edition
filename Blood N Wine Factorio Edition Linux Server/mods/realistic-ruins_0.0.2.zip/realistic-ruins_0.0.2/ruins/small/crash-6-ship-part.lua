return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-6",  {x = 0, y = 0}, {}},
  },
}
