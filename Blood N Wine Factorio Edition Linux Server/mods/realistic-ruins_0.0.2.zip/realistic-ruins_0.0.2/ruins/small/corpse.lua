return
{
  entities =
  {
    {"character-corpse", {x = 0, y = 0}, {force = "enemy"}},
  },
}
