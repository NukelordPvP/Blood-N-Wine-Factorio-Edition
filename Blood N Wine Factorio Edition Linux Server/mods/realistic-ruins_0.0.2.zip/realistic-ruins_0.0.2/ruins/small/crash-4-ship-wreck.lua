return
{
  entities =
  {
    {"medium-ship-wreck", {x = 0, y = 0}, {}},
  },
}
