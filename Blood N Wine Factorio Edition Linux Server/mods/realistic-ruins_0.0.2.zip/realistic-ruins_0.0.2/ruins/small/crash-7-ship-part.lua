return
{
  entities =
  {
    {"crash-site-spaceship-wreck-medium-1", {x = 0, y = 0}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
  },
}
