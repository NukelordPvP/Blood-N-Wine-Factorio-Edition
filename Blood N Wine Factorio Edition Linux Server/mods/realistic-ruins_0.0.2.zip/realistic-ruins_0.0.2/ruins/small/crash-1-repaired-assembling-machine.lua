return
{
  entities =
  {
    {"crash-site-assembling-machine-1-repaired", {x = 0, y = 0}, {recipe = "burner-inserter", }},
  },
}
