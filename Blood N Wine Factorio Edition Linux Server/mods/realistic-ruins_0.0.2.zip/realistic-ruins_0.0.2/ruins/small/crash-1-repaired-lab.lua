return
{
  entities =
  {
    {"crash-site-lab-repaired", {x = 0, y = 0}, {}},
  },
}
