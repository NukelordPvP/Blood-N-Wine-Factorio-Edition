return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-2",  {x = 0, y = 0}, {}},
  },
}
