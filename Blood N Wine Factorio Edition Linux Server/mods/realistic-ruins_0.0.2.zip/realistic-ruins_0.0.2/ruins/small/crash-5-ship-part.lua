return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-5",  {x = 0, y = 0}, {}},
  },
}
