return
{
  entities =
  {
    {"big-ship-wreck-2", {x = 0, y = 0}, {items = {["land-mine"] = {type = "random", min = 0, max = 8}}, }},
  },
}
