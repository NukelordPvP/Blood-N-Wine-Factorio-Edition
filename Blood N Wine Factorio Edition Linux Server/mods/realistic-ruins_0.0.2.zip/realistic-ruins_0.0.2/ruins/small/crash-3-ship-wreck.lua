return
{
  entities =
  {
    {"big-ship-wreck-3", {x = 0, y = 0}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
  },
}
