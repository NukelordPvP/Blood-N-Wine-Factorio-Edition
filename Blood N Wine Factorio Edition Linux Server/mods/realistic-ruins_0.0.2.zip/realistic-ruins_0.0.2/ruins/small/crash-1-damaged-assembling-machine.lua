return
{
  entities =
  {
    {"crash-site-assembling-machine-1-broken", {x = 0, y = 0}, {}},
  },
}
