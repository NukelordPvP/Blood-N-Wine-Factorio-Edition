return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-4", {x = 0.99, y = 0.16}, {}},
    {"crash-site-chest-1", {x = -1.18, y = 0.52}, {items = {
        ["advanced-circuit"     ] = {type = "random", min = 0, max = 200},
        ["electronic-circuit"   ] = {type = "random", min = 0, max = 200},
        ["battery"              ] = {type = "random", min = 0, max = 200},
        ["iron-plate"           ] = {type = "random", min = 0, max = 100},
        ["steel-plate"          ] = {type = "random", min = 0, max = 100},
        ["copper-plate"         ] = {type = "random", min = 0, max = 100},
        ["iron-gear-wheel"      ] = {type = "random", min = 0, max = 100},
        ["processing-unit"      ] = {type = "random", min = 0, max = 100},
        ["plastic-bar"          ] = {type = "random", min = 0, max = 100},
        ["raw-fish"             ] = {type = "random", min = 0, max = 100},
        ["solid-fuel"           ] = {type = "random", min = 0, max = 50},
        ["flying-robot-frame"   ] = {type = "random", min = 0, max = 50},
        ["low-density-structure"] = {type = "random", min = 0, max = 10},
    }, }},
  },
}
