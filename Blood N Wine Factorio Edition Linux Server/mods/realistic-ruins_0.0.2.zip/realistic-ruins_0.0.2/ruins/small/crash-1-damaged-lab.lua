return
{
  entities =
  {
    {"crash-site-lab-broken", {x = 0, y = 0}, {}},
  },
}
