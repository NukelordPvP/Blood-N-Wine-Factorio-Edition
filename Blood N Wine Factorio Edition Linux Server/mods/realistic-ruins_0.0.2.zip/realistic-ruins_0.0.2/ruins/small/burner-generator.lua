return
{
  entities =
  {
    {"burner-generator", {x = 0, y = 0}, {dir = "west", force = "enemy", dmg = { dmg = {type = "random", min = 0, max = 400}} }},
  },
}
