return
{
  entities =
  {
    {"crash-site-generator", {x = 0, y = 0}, {}},
  },
}
