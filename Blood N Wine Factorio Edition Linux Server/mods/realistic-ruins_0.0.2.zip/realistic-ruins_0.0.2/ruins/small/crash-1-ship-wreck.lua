return
{
  entities =
  {
    {"big-ship-wreck-1", {x = 0, y = 0}, {items = {["rocket"] = {type = "random", min = 0, max = 8}}, }},
  },
}
