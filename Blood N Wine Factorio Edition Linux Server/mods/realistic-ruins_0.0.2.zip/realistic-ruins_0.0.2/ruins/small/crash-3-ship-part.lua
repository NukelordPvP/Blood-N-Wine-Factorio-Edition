return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-3",  {x = 0, y = 0}, {}},
  },
}
