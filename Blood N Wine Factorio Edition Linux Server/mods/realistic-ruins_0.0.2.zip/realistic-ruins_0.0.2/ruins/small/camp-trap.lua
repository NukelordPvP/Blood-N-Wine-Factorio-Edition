return
{
  entities =
  {
    {"tree-01", {x = 1, y = -0.93}, {}},
    {"camp-fire", {x = -0.25, y = 0.34}, {force = "enemy"}},
    {"land-mine", {x = -1.5, y = -1.08}, {force = "enemy"}},
    {"land-mine", {x = -0.25, y = 0.42}, {force = "enemy"}},
    {"land-mine", {x = -1.02, y = 1.75}, {force = "enemy"}},
  },
}
