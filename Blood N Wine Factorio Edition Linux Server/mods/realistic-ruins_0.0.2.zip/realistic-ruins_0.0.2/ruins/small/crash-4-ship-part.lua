return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-4",  {x = 0, y = 0}, {}},
  },
}
