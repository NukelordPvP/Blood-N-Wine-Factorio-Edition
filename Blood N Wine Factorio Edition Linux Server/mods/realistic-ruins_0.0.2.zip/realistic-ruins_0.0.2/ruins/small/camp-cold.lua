return
{
  entities =
  {
    {"camp-fire", {x = 0, y = 0}, {force = "enemy"}},
    {{type = "random-of-entity-type", entity_type = "tree"}, {x = 0, y = 0}, {}},
  },
}
