return
{
  entities =
  {
    {"crash-site-spaceship-wreck-small-1",  {x = 0, y = 0}, {}},
  },
}
