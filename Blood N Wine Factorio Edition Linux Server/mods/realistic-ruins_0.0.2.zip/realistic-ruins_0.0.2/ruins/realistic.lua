return {
    small = require("ruins.small"),
    medium = require("ruins.medium"),
    large = require("ruins.large"),
}

