return
{
  entities =
  {
    {"crash-site-spaceship", {x = 24.5, y = -4.5}, {items = {
        ["firearm-magazine"     ] = {type = "random", min = 0, max = 13},
        ["rocket-control-unit"  ] = {type = "random", min = 0, max = 1},
        ["low-density-structure"] = {type = "random", min = 0, max = 3},
    }, }},
    {"crash-site-spaceship-wreck-small-1",  {x = - 3.66, y =  5.64}, {}},
    {"crash-site-spaceship-wreck-small-2",  {x = - 9.4 , y =  2.32}, {}},
    {"crash-site-spaceship-wreck-small-3",  {x = -17.23, y =  3.93}, {}},
    {"crash-site-spaceship-wreck-small-4",  {x =  10.95, y = -6.96}, {}},
    {"crash-site-spaceship-wreck-small-5",  {x =   2.11, y =  6.27}, {}},
    {"crash-site-spaceship-wreck-small-6",  {x =  12.19, y = -4.97}, {}},
    {"crash-site-spaceship-wreck-medium-1", {x = - 1.58, y =  1.12}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
    {"crash-site-spaceship-wreck-medium-2", {x =   4.76, y =  1.24}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
    {"crash-site-spaceship-wreck-medium-3", {x =  10.07, y =  0.55}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
    {"crash-site-spaceship-wreck-big-1",    {x =   6.96, y = -0.11}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
    {"crash-site-spaceship-wreck-big-2",    {x =   2.46, y = -2.05}, {items = {["iron-plate"] = {type = "random", min = 0, max = 8}}, }},
  },
}
