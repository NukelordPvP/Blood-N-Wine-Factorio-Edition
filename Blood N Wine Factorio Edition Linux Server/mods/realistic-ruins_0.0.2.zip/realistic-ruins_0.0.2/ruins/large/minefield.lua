return
{
  entities =
  {
    {"land-mine", {x =   9.63, y = -12.03}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = - 1.03, y = -10.29}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = -12.62, y = - 6.80}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = - 3.44, y = - 4.39}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x =  10.66, y = - 3.57}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = -11.08, y =   3.30}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x =   6.40, y =   4.84}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = - 3.05, y =   9.43}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x = -12.46, y =  12.99}, {force = "enemy", dead = 0.5, }},
    {"land-mine", {x =  14.81, y =  15.04}, {force = "enemy", dead = 0.5, }},
  },
}
