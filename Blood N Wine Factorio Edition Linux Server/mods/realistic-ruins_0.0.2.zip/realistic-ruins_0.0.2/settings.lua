
local set = data.raw["string-setting"]["AbandonedRuins-set"]

set.default_value = "realistic"
table.insert(set.allowed_values, "realistic")

if mods["AbandonedRuins-Krastorio2"] then
    table.insert(set.allowed_values, "realistic-krastorio")
    set.default_value = "realistic-krastorio"
end

