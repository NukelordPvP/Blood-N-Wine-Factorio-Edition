local collision_mask_util_extended = require "collision-mask-util-extended.control.collision-mask-util-control"


local function is_water(tile)
    return tile.prototype.collision_mask[ "water-tile"]
   and not tile.prototype.collision_mask["ground-tile"]
end

local function is_placer(entity)
    return string.find(entity.name, "%-placer$")
end

local function is_underwater(entity)
    return string.find(entity.name, "^underwater%-pipe")
end

local function is_blueprint(stack)
    return stack
       and stack.valid_for_read
       and stack.is_blueprint
       and stack.is_blueprint_setup()
end

local function cancel_placement(surface, tile, entity, player_index)
    local player = player_index and game.players[player_index]
    local item = (entity.prototype.items_to_place_this or {})[1]
    local inserted,position,stack = 0,entity.position
    if item and item.name then
        stack = {name = item.name, count = 1}
    end
    if player then
        if player.mine_entity(entity, false) then
            inserted = 1
        elseif stack then
            inserted = player.insert(stack)
        end
    end
    if inserted == 0 and stack then
        surface.create_entity{
            name = "item-on-ground",
            position = position,
            stack = stack,
        }
    end
    if entity and entity.valid then entity.destroy() end
    surface.create_entity{
        name = "flying-text",
        position = position,
        text = {"cant-build-reason.cant-build-on-tile", tile.prototype.localised_name},
        render_player_index = player_index,
    }
end

local function vrotpi(v) return {x=v.y, y=-v.x} end
local function dry_neightbour(surface, position)
    local v = {x=1,y=0}
    for i = 1,4 do -- check neigbours, to disable pipes on the shore
        local tile = surface.get_tile(position.x+v.x, position.y+v.y)
        if tile and not is_water(tile) then return tile end
        v = vrotpi(v)
    end
end

local function check_placement(entity, player_index)
    local surface = entity.surface
    local tile = surface.get_tile(entity.position.x, entity.position.y)
    if not tile or is_water(tile) or not dry_neightbour(surface, entity.position) then return end
    cancel_placement(surface, tile, entity, player_index)
end

local function convert_placement(entity, player_index)
    if not entity.valid then return end
    local surface = entity.surface
    local tile = dry_neightbour(surface, entity.position)
    if tile then return cancel_placement(surface, tile, entity, player_index) end
    local options = {
        name = string.sub(entity.name, 1, -8),
        position = entity.position,
        direction = entity.direction,
        force = entity.force,
    }
    entity.destroy()
    surface.create_entity(options)
end

local function convert_blueprint(stack)
    local entities = stack.get_blueprint_entities()
    if not entities then return end
    for _,entity in pairs(entities) do
        if is_underwater(entity) and not is_placer(entity) then
            entity.name = entity.name .. "-placer"
        end
    end
    stack.set_blueprint_entities(entities)
end

local function check_blueprint(player)
    local stack = player.cursor_stack
    if not is_blueprint(stack) then return end
    convert_blueprint(stack)
end

local function init()
    collision_mask_util_extended.named_collision_mask_integrity_check()
end

--------------------------------------------------------------------------------

local events = {
    entity = {
        added = {
            defines.events.on_built_entity,
            defines.events.script_raised_built,
            defines.events.script_raised_revive,
            defines.events.on_robot_built_entity,
            defines.events.on_trigger_created_entity,
        },
    },
    cursor_stack = {
        changed = defines.events.on_player_cursor_stack_changed,
    },
}

local filters = {
    {filter="name", name="underwater-pipe"},
    {filter="name", name="underwater-pipe-to-ground"},
    {filter="name", name="underwater-pipe-placer"},
    {filter="name", name="underwater-pipe-to-ground-placer"},
}


script.on_init(init)
script.on_configuration_changed(init)

script.on_event(events.cursor_stack.changed, function (event)
    local player = game.players[event.player_index]
    check_blueprint(player)
end)

script.on_event(events.entity.added, function (event)
    local entity = event.created_entity or event.entity
    if not is_underwater(entity) then return end
    if is_placer(entity) then
        convert_placement(entity, event.player_index)
    else
        check_placement(entity, event.player_index)
    end
end)

for _,event in ipairs(events.entity.added) do
    if event ~= defines.events.on_trigger_created_entity then
        script.set_event_filter(event, filters)
    end
end

