Simple pipes and underground pipes which must be placed on water tiles. The pipes can be used for near-shore oil exploration missions with [Cargo Ships](https://mods.factorio.com/mod/cargo-ships) and/or as an alternative way for pipeline construction. However there are more use cases than we can list here.


# Documentation
--------------------------------------------------------------------------------
* read the [«FAQ»](https://mods.factorio.com/mod/underwater-pipes/faq) and the [«Changelog»](https://mods.factorio.com/mod/underwater-pipes/changelog) for more details
* discuss with us on the [«Discussion»](https://mods.factorio.com/mod/underwater-pipes/discussion) page


# Suggested mods
--------------------------------------------------------------------------------
* [Cargo Ships](https://mods.factorio.com/mod/cargo-ships)


# Supported languages
------------------------------------------------------------------------------------------------
* English
* German
* Russian


# Compatibility
--------------------------------------------------------------------------------
We haven't discover any incompatibilities with other mods to date. Please report on the mod page discussion if any incompatibilities are discovered.
Works with multiplayer.


# License
--------------------------------------------------------------------------------
The mod ‹Underwater Pipes› was made by dodo.the.last and published under The Unlicense.


# Credits
-------------------------------------------------------------------------------------
The Russian translation was made by [max2344](https://mods.factorio.com/user/max2344).


# Notes
--------------------------------------------------------------------------------
The information on this mod page represents the state of the current release and might be updated without prior notification or public announcement. Please refer to the «Documentation» section of this page for details.



# FAQ
--------------------------------------------------------------------------------


# Found a bug, issue or a missing feature?
---------------------------------------------------------------------------------------------------------------------------------------------
Please report bugs or issues to our [«Discussion»](https://mods.factorio.com/mod/underwater-pipes/discussion) page in accordance with [factorio bug report rules](https://forums.factorio.com/viewtopic.php?f=7&t=3638) or talk with us about the desired features.


# Are there any settings?
---------------------------------------------------------------------------------------------------------------------------------------------
There are no user settings.


# What is required during the gameplay?
---------------------------------------------------------------------------------------------------------------------------------------------
#### Requisite technologies
* steel processing
* concrete

#### Research
* 500x automation science pack
* 500x logistic science pack
* 30s time

#### Item recipe
* 2x pipe
* 5x steel plate
* 20x concrete
* 0.5s time

