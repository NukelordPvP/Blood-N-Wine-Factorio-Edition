
data:extend({


    {   type = "string-setting",
        name = 'underwater-pipe-tint-mode',
        setting_type = "startup",
        default_value = 'realistic',
        allowed_values = {
            "realistic",
            "legacy",
        },
    },


})
