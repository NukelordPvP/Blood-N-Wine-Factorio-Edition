local collision_mask_util_extended = require "collision-mask-util-extended.data.collision-mask-util-extended"

local function id(...) return ... end
local function head(t) return t[1] end
local function map(t,f) local r = {} for k,v in pairs(t) do r[k] = f(v,k) end return r end
local function     merge(t,o) for k,v in pairs(o) do t[k] = v end return t end
local function deepmerge(t,o)
    for k,v in pairs(o) do
        if type(v) == 'table' and type(t[k]) == type(v) then
            v = deepmerge(t[k], v)
        end
        t[k] = v
    end
    return t
end

local function rm_icon(entity)
    entity.icon_size = nil
    entity.icon = nil
    return entity
end

local function hide_background(sprites)
    for name, sprite in pairs(sprites) do
        if string.find(name, "_background$") then
            sprites[name] = {
                filename = "__core__/graphics/empty.png",
                priority = "low",
                height = 1,
                width = 1,
            }
        end
    end
    return sprites
end

local function do_underwater_hint(sprite, tint, depth)
    if not sprite then return end
    sprite.tint = tint
    sprite.shift = sprite.shift or {0,0}
    sprite.shift[2] = sprite.shift[2] + depth
end

local function underwater_hint(sprites, tint, depth)
    for _, sprite in pairs(sprites) do
        if sprite.layers then
            underwater_hint(sprite.layers, tint, depth)
        else
            do_underwater_hint(sprite, tint, depth)
            do_underwater_hint(sprite.hr_version, tint, depth)
        end
    end
    return hide_background(sprites)
end

local function do_blendmode(mode, sprites)
    for _, sprite in pairs(sprites) do
        if sprite.filename then
            if not sprite.draw_as_light then
                sprite.blend_mode = mode
            end
            if sprite.hr_version and not sprite.hr_version.draw_as_light then
                sprite.hr_version.blend_mode = mode
            end
        elseif sprite.layers then
            do_blendmode(mode, sprite.layers)
        end
    end
    return sprites
end

local function do_resistances(a, b)
    local resistances,lookup = {},{}
    for _,resistance in ipairs(b) do lookup[resistance.type] = true end
    for _,resistance in ipairs(a or {}) do
        if not lookup[resistance.type] then
            table.insert(resistances, resistance)
        end
    end
    for _,resistance in ipairs(b) do
        table.insert(resistances, resistance)
    end
    return resistances
end


--------------------------------------------------------------------------------

local is_legacy = settings.startup['underwater-pipe-tint-mode'].value == 'legacy'
local underwater_tint = is_legacy and {a=0.2, r=0.2,g=0.2,b=0.2} or {a=0.2, r=0.01,g=0.18,b=0.2}
local material_tint = {a=1, r=0.666, g=0.666, b=0.666}
local blend_mode = is_legacy and 'normal' or 'additive-soft'
local depth = is_legacy and 0.321 or 0.432

local pipe_entity = table.deepcopy(data.raw["pipe"]["pipe"])
local pipe_to_ground_entity = table.deepcopy(data.raw["pipe-to-ground"]["pipe-to-ground"])

local pipe_item = table.deepcopy(data.raw.item["pipe"])
local pipe_to_ground_item = table.deepcopy(data.raw.item["pipe-to-ground"])

local pipe_corpse = table.deepcopy(data.raw.corpse["pipe-remnants"])
local pipe_to_ground_corpse = table.deepcopy(data.raw.corpse["pipe-to-ground-remnants"])


local underwater_layer = collision_mask_util_extended.get_make_named_collision_mask("underwater-layer")

local resistances = {
    {type = 'fire',      percent = 100},
    {type = 'acid',      percent = 100},
    {type = 'laser',     percent = 100},
    {type = 'impact',    percent =  50},
    {type = 'physical',  percent =  99.98},
    {type = 'explosion', percent =  99.99},
}

local function transform_sprites(sprites)
    local unp = id
    if sprites.filename then
        -- its only a single sheet
        sprites = {sprites}
        unp = head
    end
    sprites = underwater_hint(sprites, underwater_tint, depth)
    sprites = do_blendmode(blend_mode, sprites)
    return unp(sprites)
end


    -- icons ---------------------------------------------------------------


local function underwater_icon(entity)
    return {
        {icon="__base__/graphics/terrain/water/water-o.png", icon_size=32},
        {icon=entity.icon, icon_size=entity.icon_size, tint=underwater_tint, blend_mode=blend_mode},
    }
end

local function material_icon(entity)
    return {
        {icon=entity.icon, icon_size=entity.icon_size, tint=material_tint},
    }
end

local icons = {
    underwater = {
        pipe           = underwater_icon(pipe_entity),
        pipe_to_ground = underwater_icon(pipe_to_ground_entity),
    },
    material = {
        pipe           = material_icon(pipe_entity),
        pipe_to_ground = material_icon(pipe_to_ground_entity),
    },
}

    -- entity --------------------------------------------------------------


local underwater = {

    pipe = rm_icon(merge(deepmerge(pipe_entity, {
        name = "underwater-pipe",
        minable = {result = "underwater-pipe"},
    }), {
        collision_mask = {underwater_layer},
        pictures = transform_sprites(pipe_entity.pictures),
        corpse = "underwater-pipe-remnants",
        icons = icons.underwater.pipe,
        resistances = do_resistances(pipe_entity.resistances, resistances),
    })),


    pipe_to_ground = rm_icon(merge(deepmerge(pipe_to_ground_entity, {
        name = "underwater-pipe-to-ground",
        minable = {result = "underwater-pipe-to-ground"},
        fluid_box = {
            pipe_covers = transform_sprites(pipe_to_ground_entity.fluid_box.pipe_covers),
        },
    }), {
        collision_mask = {underwater_layer},
        pictures = transform_sprites(pipe_to_ground_entity.pictures),
        corpse = "underwater-pipe-to-ground-remnants",
        icons = icons.underwater.pipe_to_ground,
        resistances = do_resistances(pipe_to_ground_entity.resistances, resistances),
    })),

}

local placer = {}

for name,prototype in pairs(underwater) do
    local entity = table.deepcopy(prototype)
    entity.name = entity.name .. "-placer"
    table.insert(entity.collision_mask, "ground-tile")
    placer[name] = entity
    -- fix pipette
    prototype.placeable_by = {
        item = prototype.name,
        count = 1,
    }
end

local remnants = {

    pipe = rm_icon(merge(pipe_corpse, {
        name = "underwater-pipe-remnants",
        animation = transform_sprites(pipe_corpse.animation),
        icons = icons.underwater.pipe,
    })),

    pipe_to_ground = rm_icon(merge(pipe_to_ground_corpse, {
        name = "underwater-pipe-to-ground-remnants",
        animation = transform_sprites(pipe_to_ground_corpse.animation),
        icons = icons.underwater.pipe_to_ground,
    })),

}


data:extend{

    remnants.pipe,
    remnants.pipe_to_ground,

    underwater.pipe,
    underwater.pipe_to_ground,

    placer.pipe,
    placer.pipe_to_ground,


    -- item ----------------------------------------------------------------


    rm_icon(deepmerge(pipe_item, {
        name = "underwater-pipe",
        place_result = "underwater-pipe-placer",
        order = pipe_item.order .. "a",
        icons = icons.material.pipe,
    })),


    rm_icon(deepmerge(pipe_to_ground_item, {
        name = "underwater-pipe-to-ground",
        place_result = "underwater-pipe-to-ground-placer",
        order = pipe_to_ground_item.order .. "a",
        icons = icons.material.pipe_to_ground,
    })),


    -- recipe --------------------------------------------------------------


    {   type = "recipe",
        name = "underwater-pipe",
        energy_required = 0.5,
        ingredients = {
            {"pipe",        2},
            {"steel-plate", 5},
            {"concrete",   20},
        },
        result = "underwater-pipe",
        enabled = false,
        icons = icons.underwater.pipe,
    },


    {   type = "recipe",
        name = "underwater-pipe-to-ground",
        energy_required = 0.5,
        ingredients = {
            {"underwater-pipe", 20},
        },
        result_count = 2,
        result = "underwater-pipe-to-ground",
        enabled = false,
        icons = icons.underwater.pipe_to_ground,
    },


    -- technology ----------------------------------------------------------


    {   type = "technology",
        name = "underwater-pipes",
        prerequisites = {"concrete", "steel-processing"},
        icon = "__underwater-pipes__/graphics/technology.png",
        icon_size = 128,
        order = "a-h-d",
        effects = {
            {type = "unlock-recipe", recipe = "underwater-pipe"},
            {type = "unlock-recipe", recipe = "underwater-pipe-to-ground"},
        },
        unit = {
            time = 30,
            count = 500,
            ingredients = {
                {  "logistic-science-pack", 1},
                {"automation-science-pack", 1},
            },
        },
    },


}

