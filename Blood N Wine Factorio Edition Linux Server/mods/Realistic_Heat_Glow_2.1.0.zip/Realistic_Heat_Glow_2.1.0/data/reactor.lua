

-- nuclear-reactor ------------------------------------------------------------------------------------
-- heat buffer
--	adding
data.raw.reactor["nuclear-reactor"].heat_buffer.heat_glow = REALISTIC_HEAT_GLOW_FUNC{
	filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/reactor-heat-glow.png",
	priority = "extra-high",
	width = 188, height = 190,
	shift = util.by_pixel(-2, -4),
}

do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["nuclear-reactor"].heat_buffer.heat_glow)
if settings.startup["realistic-heat-glow-enable"].value then
	do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["nuclear-reactor"].heat_buffer.heat_glow) 
end
--end


data.raw.reactor["nuclear-reactor"].heat_buffer.heat_picture = REALISTIC_HEAT_GLOW_FUNC{
	filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/reactor-heated.png",
	priority = "extra-high",
	width = 108, height = 128,
	shift = util.by_pixel(1, -7),
	hr_version = {
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/hr-reactor-heated.png",
		priority = "extra-high",
		width = 216, height = 256,
		scale = 0.5,
		shift = util.by_pixel(3, -6.5),
	}
}


if settings.startup["realistic-heat-glow-enable"].value then
	do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["nuclear-reactor"].heat_buffer.heat_picture)
	do_blendmode(REALISTIC_HEAT_GLOW_RR_BLENDMODE, data.raw.reactor["nuclear-reactor"].heat_buffer.heat_picture)
end

data.raw.reactor["nuclear-reactor"].heat_lower_layer_picture = REALISTIC_HEAT_GLOW_FUNC{
	filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/reactor-pipes-heated.png",
	priority = "extra-high",
	width = 156, height = 156,
	shift = util.by_pixel(-3, -4),
	hr_version = {
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/hr-reactor-pipes-heated.png",
		priority = "extra-high",
		width = 320, height = 316,
		scale = 0.5,
		shift = util.by_pixel(-0.5, -4.5)
	}
}


if settings.startup["realistic-heat-glow-enable"].value then
	do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["nuclear-reactor"].heat_lower_layer_picture)
	do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["nuclear-reactor"].heat_lower_layer_picture)
end

data.raw.reactor["nuclear-reactor"].heat_connection_patches_connected = {
	sheet = REALISTIC_HEAT_GLOW_FUNC{
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/reactor-connect-patches-heated.png",
		priority = "extra-high",
		width = 32, height = 32,
		variation_count = 12,
		hr_version = {
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/hr-reactor-connect-patches-heated.png",
			priority = "extra-high",
			width = 64, height = 64,
			variation_count = 12,
			scale = 0.5
		}
	}
}
if settings.startup["realistic-heat-glow-enable"].value then
	do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["nuclear-reactor"].heat_connection_patches_connected.sheet)
	do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["nuclear-reactor"].heat_connection_patches_connected.sheet)
end

data.raw.reactor["nuclear-reactor"].heat_connection_patches_disconnected = {
	sheet = REALISTIC_HEAT_GLOW_FUNC{
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/reactor-connect-patches-heated.png",
		priority = "extra-high",
		width = 32, height = 32,
		variation_count = 12,
		y = 32,
		hr_version = {
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/nuclear-reactor/hr-reactor-connect-patches-heated.png",
			priority = "extra-high",
			width = 64, height = 64,
			variation_count = 12,
			y = 64,
			scale = 0.5
		}
	}
}
if settings.startup["realistic-heat-glow-enable"].value then
	do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["nuclear-reactor"].heat_connection_patches_disconnected.sheet)
	do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["nuclear-reactor"].heat_connection_patches_disconnected.sheet)
end
-- end nuclear-reactor ------------------------------------------------------------------------------------

