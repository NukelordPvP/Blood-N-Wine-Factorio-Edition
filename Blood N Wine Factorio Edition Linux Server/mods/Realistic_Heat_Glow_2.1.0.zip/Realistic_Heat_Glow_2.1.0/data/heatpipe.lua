

-- heat-pipe ------------------------------------------------------------------------------------
--	adding
data.raw["heat-pipe"]["heat-pipe"].heat_buffer.heat_glow = REALISTIC_HEAT_GLOW_FUNC{
	filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-pipe/heated-glow.png",
	priority = "extra-high",
	width = 55, height = 55,
	scale = 1.2,
}

do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw["heat-pipe"]["heat-pipe"].heat_buffer.heat_glow)

if settings.startup["realistic-heat-glow-enable"].value then
	do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw["heat-pipe"]["heat-pipe"].heat_buffer.heat_glow) 
end


data.raw["heat-pipe"]["heat-pipe"].heat_glow_sprites = make_heat_pipe_pictures(REALISTIC_HEAT_GLOW_BASEDIR.."/heat-pipe/", "heated", {
	single = { empty = true },
	straight_vertical = { variations = 6 },
	straight_horizontal = { variations = 6 },
	corner_right_up = { name = "corner-up-right", variations = 6 },
	corner_left_up = { name = "corner-up-left", variations = 6 },
	corner_right_down = { name = "corner-down-right", variations = 6 },
	corner_left_down = { name = "corner-down-left", variations = 6 },
	t_up = {},
	t_down = {},
	t_right = {},
	t_left = {},
	cross = { name = "t" },
	ending_up = {},
	ending_down = {},
	ending_right = {},
	ending_left = {},
    }, settings.startup["realistic-heat-glow-enable"].value)


if settings.startup["realistic-heat-glow-enable"].value then
	for _, sprite in pairs(data.raw["heat-pipe"]["heat-pipe"].heat_glow_sprites) do
		if sprite.filename then
			do_tint(REALISTIC_HEAT_GLOW_TINT, sprite)
		else
			for _, f in pairs(sprite) do
				do_tint(REALISTIC_HEAT_GLOW_TINT, f)
				do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, f)
			end
		end
	end
end
-- end heat-pipe ------------------------------------------------------------------------------------

