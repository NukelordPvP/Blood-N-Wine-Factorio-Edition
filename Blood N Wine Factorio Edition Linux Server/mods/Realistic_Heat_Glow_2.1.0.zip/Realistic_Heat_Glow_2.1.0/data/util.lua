

REALISTIC_HEAT_GLOW_BASEDIR = "__Realistic_Heat_Glow__/graphics"
REALISTIC_HEAT_GLOW_TINT = {r=1, g=0.63, b=0.39}
REALISTIC_HEAT_GLOW_REACTOR_SHIFT = util.by_pixel(1, -12)
REALISTIC_HEAT_GLOW_REACTOR_SCALE = 0.3543 --0.3542
REALISTIC_HEAT_GLOW_DEF_BLENDMODE = "normal"
REALISTIC_HEAT_GLOW_RR_BLENDMODE  = "additive-soft"
REALISTIC_HEAT_GLOW_RR_COLOR = {b = 0.94, g = 1.0, r = 0.0} -- {b = 1.0, g = 0.15, r = 0.0}

REALISTIC_HEAT_GLOW_FUNC = function(v) return v end
if settings.startup["realistic-heat-glow-enable"].value then
	REALISTIC_HEAT_GLOW_FUNC = apply_heat_pipe_glow
end


function do_blendmode(mode, sprite)
	if sprite.filename then

		if not sprite.draw_as_light then
			sprite.blend_mode=mode
		end

		if sprite.hr_version and not sprite.hr_version.draw_as_light then
			sprite.hr_version.blend_mode=mode
		end

	elseif sprite.layers then
		for _, s in pairs(sprite.layers) do
			do_blendmode(mode, s)
		end
	end
	return sprite
end


function do_tint(tint, sprite)
	if sprite.filename then
		if sprite.hr_version then
			sprite.hr_version.tint=table.deepcopy(tint)
		end
		sprite.tint=table.deepcopy(tint)

	elseif sprite.layers then
		for _, s in pairs(sprite.layers) do
			do_tint(tint, s)
		end
	end
	return sprite
end


function do_picture(sprite, pic, hr_pic)
	if sprite then
		for _, x in pairs(sprite) do
			if x.filename then
				x.filename = pic or x.filename
				if x.hr_version and x.hr_version.filename then
					x.hr_version.filename = hr_pic or x.hr_version.filename
				end
			end
		end
		return sprite
	end
end


