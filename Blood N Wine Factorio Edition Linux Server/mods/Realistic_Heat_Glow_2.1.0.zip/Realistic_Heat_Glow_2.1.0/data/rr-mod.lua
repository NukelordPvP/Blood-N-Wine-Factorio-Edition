

-- RealisticReactors support ------------------------------------------------------------------------------------
if mods["RealisticReactors"] then




	data.raw.reactor["realistic-reactor-normal"].heat_lower_layer_picture = {
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/reactor-pipes-heated.png",
		priority = "extra-high",
		width = 288, height = 348,
		scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
		shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
	}

	data.raw.reactor["realistic-reactor-breeder"].heat_lower_layer_picture = {
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/reactor-pipes-heated.png",
		priority = "extra-high",
		width = 288, height = 348,
		scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
		shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
	}




	data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_picture = REALISTIC_HEAT_GLOW_FUNC{
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/reactor-heated.png",
		priority = "extra-high",
		width = 288, height = 348,
		shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
		scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
	}


	data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_picture  = REALISTIC_HEAT_GLOW_FUNC{
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/breeder-heated.png",
		priority = "extra-high",
		width = 288, height = 348,
		shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
		scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
	}


	if settings.startup["realistic-heat-glow-enable"].value then
		data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_glow = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/reactor-heat-glow.png",
			priority = "extra-high",
			width = 288, height = 348,
			shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
			scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
		}


		data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_glow = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/realistic-reactors/breeder-heat-glow.png",
			priority = "extra-high",
			width = 288, height = 348,
			shift = REALISTIC_HEAT_GLOW_REACTOR_SHIFT,
			scale = REALISTIC_HEAT_GLOW_REACTOR_SCALE,
		}


		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_glow)
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_glow)

		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_glow)
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_glow)


		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-normal"].heat_lower_layer_picture)
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, data.raw.reactor["realistic-reactor-normal"].heat_lower_layer_picture)

		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_picture)
		do_blendmode(REALISTIC_HEAT_GLOW_RR_BLENDMODE, data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_picture)

		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-breeder"].heat_lower_layer_picture)
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE,  data.raw.reactor["realistic-reactor-breeder"].heat_lower_layer_picture)

		do_tint(REALISTIC_HEAT_GLOW_TINT, data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_picture)
		do_blendmode(REALISTIC_HEAT_GLOW_RR_BLENDMODE, data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_picture)

	end
--	else
--		data.raw.reactor["realistic-reactor-normal"].heat_buffer.heat_glow = nil
--		data.raw.reactor["realistic-reactor-breeder"].heat_buffer.heat_glow = nil
--	end


	if settings.startup["realistic-heat-glow-rr-light"].value then
		data.raw.reactor["realistic-reactor-normal"].working_light_picture.tint = REALISTIC_HEAT_GLOW_RR_COLOR
		data.raw.reactor["realistic-reactor-breeder"].working_light_picture.tint = REALISTIC_HEAT_GLOW_RR_COLOR


		if data.raw.reactor["realistic-reactor-normal"].light.color then
			data.raw.reactor["realistic-reactor-normal"].light.color = REALISTIC_HEAT_GLOW_RR_COLOR
		end


		if data.raw.reactor["realistic-reactor-breeder"].light.color then 
			data.raw.reactor["realistic-reactor-breeder"].light.color = REALISTIC_HEAT_GLOW_RR_COLOR
		end
	end



end
-- end RealisticReactors support ------------------------------------------------------------------------------------

