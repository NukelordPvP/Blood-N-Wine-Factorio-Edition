

-- heat exchanger ------------------------------------------------------------------------------------
--	adding
data.raw.boiler["heat-exchanger"].energy_source.heat_glow = {
		north = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-N-glow.png",
			priority = "extra-high",
			width = 38, height = 70,
			shift = util.by_pixel(0, 8),
		},
		east = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-E-glow.png",
			priority = "extra-high",
			width = 60, height = 62,
			shift = util.by_pixel(-22, -12),
		},
		south = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-S-glow.png",
			priority = "extra-high",
			width = 38, height = 40,
			shift = util.by_pixel(0, -36),
		},
		west = REALISTIC_HEAT_GLOW_FUNC{
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-W-glow.png",
			priority = "extra-high",
			width = 60, height = 64,
			shift = util.by_pixel(20, -12),
		},
}
for _, dir in pairs(data.raw.boiler["heat-exchanger"].energy_source.heat_glow) do
	do_tint(REALISTIC_HEAT_GLOW_TINT, dir)
	if settings.startup["realistic-heat-glow-enable"].value then
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, dir) 
	end
end


data.raw.boiler["heat-exchanger"].energy_source.heat_picture = {
        north = {
          filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-N-heated.png",
          priority = "extra-high",
          width = 24, height = 48,
          shift = util.by_pixel(-1, 8),
          hr_version = {
            filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/hr-heatex-N-heated.png",
            priority = "extra-high",
            width = 44, height = 96,
            shift = util.by_pixel(-0.5, 8.5),
            scale = 0.5,
          }
        },
        east = {
          filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-E-heated.png",
          priority = "extra-high",
          width = 40, height = 40,
          shift = util.by_pixel(-21, -13),
          hr_version = {
            filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/hr-heatex-E-heated.png",
            priority = "extra-high",
            width = 80, height = 80,
            shift = util.by_pixel(-21, -13),
            scale = 0.5,
          }
        },
        south = {
          filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-S-heated.png",
          priority = "extra-high",
          width = 16, height = 20,
          shift = util.by_pixel(-1, -30),
          hr_version = {
            filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/hr-heatex-S-heated.png",
            priority = "extra-high",
            width = 28, height = 40,
            shift = util.by_pixel(-1, -30),
            scale = 0.5,
          }
        },
        west = {
          filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-W-heated.png",
          priority = "extra-high",
          width = 32, height = 40,
          shift = util.by_pixel(23, -13),
          hr_version = {
            filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/hr-heatex-W-heated.png",
            priority = "extra-high",
            width = 64, height = 76,
            shift = util.by_pixel(23, -13),
            scale = 0.5,
          }
        },
      }


if settings.startup["realistic-heat-glow-enable"].value then
	for _, v in pairs(data.raw.boiler["heat-exchanger"].energy_source.heat_picture) do
			do_tint(REALISTIC_HEAT_GLOW_TINT, v)
			do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, v)
	end
end

data.raw.boiler["heat-exchanger"].energy_source.heat_pipe_covers = make_4way_animation_from_spritesheet(
	{
		filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/heatex-endings-heated.png",
		priority = "extra-high",
		width = 32, height = 32,
		direction_count = 4,
		hr_version = {
			filename = REALISTIC_HEAT_GLOW_BASEDIR.."/heat-exchanger/hr-heatex-endings-heated.png",
			priority = "extra-high",
			width = 64, height = 64,
			direction_count = 4,
			scale = 0.5
		}
	}
)

--[[
if settings.startup["realistic-heat-glow-enable"].value then
	for _, v in pairs(data.raw.boiler["heat-exchanger"].energy_source.heat_pipe_covers) do
		do_tint(REALISTIC_HEAT_GLOW_TINT, v)
		do_blendmode(REALISTIC_HEAT_GLOW_DEF_BLENDMODE, v)
	end
end
--]]
-- end heat exchanger ------------------------------------------------------------------------------------

