Prettier heat glow for heatpipes.

# Startup settings
------------------------------------------------------------------------------------------------
* Enable light halo on entities: Alternate light mode similar to factorio 0.17. When enabled, a light halo around heat-pipe entities will be drawn (as boolean); Default: disabled
* Enable blue glow for RealisticReactors: Alternate reactor working light for RealisticReactors, like "Realistic Reactor Glow" mod (as boolean); Default: disabled

# Recommended mods
------------------------------------------------------------------------------------------------
* [Realistic Reactor Glow](https://mods.factorio.com/mod/RealisticReactorGlow)
* [Realistic Reactors](https://mods.factorio.com/mod/RealisticReactors)

# Compatibility
------------------------------------------------------------------------------------------------
We haven't discover any incompatibilities with other mods to date. Please report on the mod page discussion if any incompatibilities are discovered.

# License
-----------------------------------------------------------------------------------------------
This mod was made by max2344, OwnlyMe and others, published under the MIT license.

# Credits
------------------------------------------------------------------------------------------------
Special Thanks to:

* OwnlyMe
* Albert ( https://www.twitch.tv/boxbox )
* Arcani ( https://mods.factorio.com/mod/Hovercrafts )
* Decafeiner
* KiritoTRw
* James Austin
* Utah Valley Fence Company
* Darkgamer504
* Denis K.

Thank you so much for your support!!!!

