

REALISTIC_HEAT_GLOW_DEF_SETTINGS = {
	{
		type = "bool-setting",
		name = "realistic-heat-glow-enable",
		setting_type = "startup",
		default_value = false,
		order = "a1",
	},
}


REALISTIC_HEAT_GLOW_RR_COMPAT_SETTINGS = {
	{
		type = "bool-setting",
		name = "realistic-heat-glow-rr-light",
		setting_type = "startup",
		default_value = false,
		order = "a2",
	},
}


data:extend(REALISTIC_HEAT_GLOW_DEF_SETTINGS)


if mods["RealisticReactors"] then
	data:extend(REALISTIC_HEAT_GLOW_RR_COMPAT_SETTINGS)
end

