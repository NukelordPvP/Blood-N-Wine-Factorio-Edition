

require("data.util")
require("data.heatpipe")
require("data.heatexchanger")
require("data.reactor")
require("data.rr-mod")

--log(serpent.block(data.raw["reactor"]["realistic-reactor-normal"].heat_lower_layer_picture))
--log(serpent.block(data.raw["reactor"]["realistic-reactor-normal"].heat_buffer.heat_picture))
--log(serpent.block(data.raw["reactor"]["realistic-reactor-normal"].heat_buffer.heat_glow))
--log(serpent.block(data.raw.reactor["realistic-reactor-normal"].working_light_picture))

--log(serpent.block(data.raw["reactor"]["realistic-reactor-breeder"].heat_lower_layer_picture))
--log(serpent.block(data.raw["reactor"]["realistic-reactor-breeder"].heat_buffer.heat_picture))
--log(serpent.block(data.raw["reactor"]["realistic-reactor-breeder"].heat_buffer.heat_glow))
--log(serpent.block(data.raw.reactor["realistic-reactor-breeder"].working_light_picture))

--log(serpent.block(data.raw["reactor"]["nuclear-reactor"].heat_buffer.heat_glow))
--log(serpent.block(data.raw["reactor"]["nuclear-reactor"].heat_buffer.heat_picture))
--log(serpent.block(data.raw["reactor"]["nuclear-reactor"].heat_lower_layer_picture))
--log(serpent.block(data.raw["reactor"]["nuclear-reactor"].heat_connection_patches_connected))
--log(serpent.block(data.raw["reactor"]["nuclear-reactor"].heat_connection_patches_disconnected))

--log(serpent.block(data.raw.boiler["heat-exchanger"].energy_source.heat_picture))
--log(serpent.block(data.raw.boiler["heat-exchanger"].energy_source.heat_glow))
--log(serpent.block(data.raw.boiler["heat-exchanger"].energy_source.heat_pipe_covers))

--log(serpent.block(data.raw["heat-pipe"]["heat-pipe"].heat_buffer.heat_glow))
--log(serpent.block(data.raw["heat-pipe"]["heat-pipe"].heat_glow_sprites))

