
-- Erase old globals, farewell!!!
global.ores = nil
global.items = nil
global.fluids = nil