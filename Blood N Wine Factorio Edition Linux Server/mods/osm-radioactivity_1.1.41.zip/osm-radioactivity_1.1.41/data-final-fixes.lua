------------------------------
---- data-final-fixes.lua ----
------------------------------

-- Set mod name
OSM.mod = "Radioactivity Kills Slowly"

-- Build prototypes table and assign radiation values to entity/item/fluid
OSM.RKS.build.core()

OSM.RKS = nil
OSM.mod = nil