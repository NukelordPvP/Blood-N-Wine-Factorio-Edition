# space-exploration-graphics
Space Exploration Graphics

This is NOT an open source project, please check the licence file.

If you would like to contribute please contact Earendel on Discord first: https://discord.gg/ymjUVMv
