This packages add various effects and sounds for [Enemy Race Manager](https://mods.factorio.com/mod/enemyracemanager)

Assets Credits:
------------------------
Effects from
https://vxresource.wordpress.com/category/resources/animations/

Effects bought from
https://graphicriver.net/item/game-effects-sprites-aura/20737572
https://graphicriver.net/item/explosion-sprites-pack/21761224

Terran Announcer Sound from Starcraft 1, Blizzard