--GRAPHICSPATH = "__cargo-ships__/graphics/"
GRAPHICSPATH = "__cargo-ships-graphics__/graphics/"
emptypic = { filename = GRAPHICSPATH .. "blank.png", size = 1, direction_count = 1, variation_count = 1 }
