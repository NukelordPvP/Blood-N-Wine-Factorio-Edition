DREDGEPATH = "__dredgeworks__/graphics/"
emptypic = { filename = DREDGEPATH .. "blank.png", size = 1, direction_count = 1, variation_count = 1 }
floating_inserter_index = {}