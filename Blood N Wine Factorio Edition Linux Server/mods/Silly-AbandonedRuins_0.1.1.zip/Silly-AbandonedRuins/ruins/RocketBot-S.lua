return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {items = {["droid-rocket"] = {type = "random", min = 2, max = 5}, rocket = {type = "random", min = 10, max = 15}}, }},
  },
}
