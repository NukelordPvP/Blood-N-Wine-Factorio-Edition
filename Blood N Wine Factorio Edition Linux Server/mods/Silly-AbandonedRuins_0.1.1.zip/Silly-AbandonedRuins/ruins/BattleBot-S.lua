return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"iron-chest", {x = 1.5, y = 1.5}, {items = {["droid-smg"] = {type = "random", min = 3, max = 7}, ["piercing-rounds-magazine"] = {type = "random", min = 20, max = 40}}, }},
  },
}
