return
{
  entities =
  {
    {"boiler", {x = -3, y = -1.5}, {dead = 0.5, dir = "east", }},
    {"steam-engine", {x = 0.5, y = -1.5}, {dead = 0.5, dir = "east", }},
    {"boiler", {x = -3, y = 2.5}, {dead = 0.5, dir = "east", }},
    {"pipe", {x = -3.5, y = 0.5}, {}},
    {"small-electric-pole-remnants", {x = -1.5, y = 0.5}, {}},
    {"wooden-chest", {x = 1.5, y = 0.5}, {dead = 0.25, items = {["small-electric-pole"] = {type = "random", min = 4, max = 24}}, }},
    {"wooden-chest", {x = 3.5, y = 0.5}, {dead = 0.5, items = {["medium-electric-pole"] = {type = "random", min = 2, max = 8}}, }},
    {"steam-engine-remnants", {x = 0.5, y = 2.5}, {dir = "east", }},
  },
}
