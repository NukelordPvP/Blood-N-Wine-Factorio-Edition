return
{
  entities =
  {
    {"pipe-to-ground", {x = 0.5, y = -6.5}, {}},
    {"gas-refinery-small-2", {x = -0.5, y = 0.5}, {dir = "west", }},
    {"pipe-to-ground", {x = -5.5, y = 0.5}, {dir = "west", }},
    {"pipe-to-ground", {x = 4.5, y = 0.5}, {dir = "east", }},
    {"pipe-to-ground", {x = 5.5, y = 0.5}, {dir = "west", }},
    {"pipe-to-ground", {x = 0.5, y = 6.5}, {dir = "south", }},
  },
}
