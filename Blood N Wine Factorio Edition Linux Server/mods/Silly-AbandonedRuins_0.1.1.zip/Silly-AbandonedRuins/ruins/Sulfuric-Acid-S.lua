return
{
  entities =
  {
    {"rock-big", {x = -0.5, y = -1}, {}},
    {"wooden-chest", {x = 1, y = 0.5}, {items = {["liquid-sulfuric-acid-barrel"] = 1}, }},
  },
}
