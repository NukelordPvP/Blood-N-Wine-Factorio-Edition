return
{
  entities =
  {
    {"tree-04", {x = -1, y = -1}, {}},
    {"wooden-chest", {x = 0.5, y = 0.5}, {dead = 0.95, items = {rpg_amnesia_potion = 1}, }},
  },
}
