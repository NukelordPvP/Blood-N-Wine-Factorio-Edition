return
{
  entities =
  {
    {"steel-chest", {x = -1, y = 0}, {dead = 0.67,}},
    {"steel-chest", {x = -1, y = -1}, {dead = 0.67,}},
    {"fast-transport-belt", {x = 1, y = -1}, {dead = 0.25,}},
    {"fast-transport-belt", {x = 1, y = 0}, {dead = 0.25,}},
    {"filter-inserter", {x = 0, y = 0}, {dead = 0.5, dir = "east", }},
    {"filter-inserter", {x = 0, y = -1}, {dead = 0.5, dir = "east", }},
    {"steel-chest", {x = -1, y = 1}, {dead = 0.67,}},
    {"fast-transport-belt", {x = 1, y = 1}, {dead = 0.25,}},
    {"filter-inserter", {x = 0, y = 1}, {dead = 0.5, dir = "east", }},
  },
}
