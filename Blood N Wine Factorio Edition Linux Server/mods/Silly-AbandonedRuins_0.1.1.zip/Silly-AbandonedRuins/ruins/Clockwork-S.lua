return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {items = {["droid-rifle"] = {type = "random", min = 10, max = 15}, ["firearm-magazine"] = {type = "random", min = 20, max = 50}}, }},
  },
}
