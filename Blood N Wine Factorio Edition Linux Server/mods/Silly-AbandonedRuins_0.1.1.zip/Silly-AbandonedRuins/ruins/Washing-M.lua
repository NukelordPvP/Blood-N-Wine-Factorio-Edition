return
{
  entities =
  {
    {"pipe-to-ground", {x = 0.5, y = -7}, {}},
    {"washing-plant", {x = 0.5, y = -3}, {dir = "south", }},
    {"pipe-to-ground", {x = -5.5, y = 0}, {dir = "west", }},
    {"pipe-to-ground", {x = 4.5, y = 0}, {dir = "east", }},
    {"pipe-to-ground", {x = 5.5, y = 0}, {dir = "west", }},
    {"washing-plant", {x = 0.5, y = 3}, {dir = "south", }},
    {"pipe-to-ground", {x = 0.5, y = 6}, {dir = "south", }},
  },
}
