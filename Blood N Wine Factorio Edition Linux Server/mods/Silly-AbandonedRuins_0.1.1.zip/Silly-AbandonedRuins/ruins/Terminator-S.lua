return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {items = {["laser-turret"] = {type = "random", min = 1, max = 3}, terminator = {type = "random", min = 1, max = 3}}, }},
  },
}
