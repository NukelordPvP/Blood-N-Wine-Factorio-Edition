table.insert(data.raw["string-setting"]["AbandonedRuins-set"].allowed_values, "silly") -- allow this mod's own set to be selected
data.raw["string-setting"]["AbandonedRuins-set"].default_value = "silly" -- and select it by default
