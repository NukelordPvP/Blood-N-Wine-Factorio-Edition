data:extend({
    {
    type = "recipe",
    name = "fluid-level-indicator",
    energy_required = 2,
    enabled = false,
    ingredients = {
        {"steel-plate", 2},
        {"pipe", 2},
        {"small-lamp",1}
    },
    results = {
        {"fluid-level-indicator", 1}
    }
}
})
