data:extend{
  {
      type = "custom-input",
      name = "jetpack",
      key_sequence = "J",
      enabled_while_spectating = false,
  },
}
