for _, force in pairs(game.forces) do
	local technologies = force.technologies
	local recipes = force.recipes

	recipes["sapling-grow-bag"].enabled = technologies["ammonium-nitrate"].researched
end
