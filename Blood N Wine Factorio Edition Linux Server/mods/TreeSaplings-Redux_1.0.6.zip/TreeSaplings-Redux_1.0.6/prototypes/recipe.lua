local globalvalues = require("stdlib/globalvalues")

data:extend({
	{
		type = "recipe",
		name = "ammonium-nitrate",
		icon = "__TreeSaplings-Redux__/graphics/icons/ammonium-nitrate.png",
		icon_size = 32,
		category = "chemistry",
		ingredients =
		{
			{type="fluid", name="ammonia", amount=15},
			{type="fluid", name="nitric-acid", amount=15}
		},
		result = "ammonium-nitrate",
		result_count = 5,
		energy_required = 10,
		enabled = false
	},
	{
		type = "recipe",
		name = "ammonia",
		subgroup = "fluid-recipes",
		icon = "__TreeSaplings-Redux__/graphics/icons/fluids/ammonia.png",
		icon_size = 32,
		category = "chemistry",
		ingredients =
		{
			{type="fluid", name="water", amount=20},
			{type="fluid", name="petroleum-gas", amount=10}
		},
		results = {{type="fluid", name="ammonia", amount=10}},
		energy_required = 2,
		enabled = false
	},
	{
		type = "recipe",
		name = "nitric-acid",
		subgroup = "fluid-recipes",
		icon = "__TreeSaplings-Redux__/graphics/icons/fluids/nitric-acid.png",
		icon_size = 32,
		category = "chemistry",
		ingredients =
		{
			{type="fluid", name="water", amount=20},
			{type="fluid", name="ammonia", amount=10}
		},
		results = {{type="fluid", name="nitric-acid", amount=10}},
		energy_required = 2,
		enabled = false
	},
	{
		type = "recipe",
		name = "planter",
		icon = "__TreeSaplings-Redux__/graphics/icons/planter.png",
		icon_size = 32,
		category = "crafting",
		ingredients = {
			{"wood", 4}
		},
		result = "planter",
		enabled = false
	},
	{
		type = "recipe",
		name = "sapling-grow-bag",
		icon = "__TreeSaplings-Redux__/graphics/icons/sapling-grow-bag.png",
		icon_size = 32,
		category = "crafting",
		ingredients = {
			{"wood", 1},
			{"ammonium-nitrate", 1}
		},
		result = "sapling-grow-bag",
		enabled = false
	},
	{
		type = "recipe",
		name = "grow-sapling",
		icon = "__TreeSaplings-Redux__/graphics/icons/sapling.png",
		icon_size = 32,
		category = "growing",
		ingredients = {
			{"sapling-grow-bag", 1}
		},
		result = "wood",
		result_count = 4,
		energy_required = globalvalues.planter_grow_time,
		overload_multiplier = 1,
		enabled = false,
		hidden = true
	}
})