data:extend({
	{
		type = "item",
		name = "ammonium-nitrate",
		subgroup = "raw-material",
		icon = "__TreeSaplings-Redux__/graphics/icons/ammonium-nitrate.png",
		stack_size = 50,
		icon_size = 32
	},
	{
		type = "item",
		name = "planter",
		subgroup = "production-machine",
		icon = "__TreeSaplings-Redux__/graphics/icons/planter.png",
		icon_size = 32,
		stack_size = 50,
		place_result = "planter"
	},
	{
		type = "item",
		name = "sapling-grow-bag",
		localised_name = {"item-name.sapling-grow-bag"},
		subgroup = "raw-material",
		icon = "__TreeSaplings-Redux__/graphics/icons/sapling-grow-bag.png",
		icon_size = 32,
		stack_size = 10,
		place_result = "sapling-placer"
	}
})