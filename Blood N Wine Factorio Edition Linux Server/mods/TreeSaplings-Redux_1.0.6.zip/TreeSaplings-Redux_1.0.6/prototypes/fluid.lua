data:extend({
	{
		type = "fluid",
		name = "ammonia",
		icon = "__TreeSaplings-Redux__/graphics/icons/fluids/ammonia.png",
		icon_size = 32,
		default_temperature = 25,
		heat_capacity = "0.1KJ",
		base_color = {r=0.9, g=0.8, b=0.6},
		flow_color = {r=0.9, g=0.8, b=0.5},
		pressure_to_speed_ratio = 0.4,
		flow_to_energy_ratio = 0.59
	},
	{
		type = "fluid",
		name = "nitric-acid",
		icon = "__TreeSaplings-Redux__/graphics/icons/fluids/nitric-acid.png",
		icon_size = 32,
		default_temperature = 25,
		heat_capacity = "0.1KJ",
		base_color = {r=0.9, g=0.8, b=0.3},
		flow_color = {r=0.8, g=0.7, b=0.2},
		pressure_to_speed_ratio = 0.4,
		flow_to_energy_ratio = 0.59
	}
})