data:extend({
	{
		type = "recipe-category",
		name = "growing"
	}
})