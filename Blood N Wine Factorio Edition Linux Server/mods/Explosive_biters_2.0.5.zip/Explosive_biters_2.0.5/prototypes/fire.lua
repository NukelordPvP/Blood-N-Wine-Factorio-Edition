local DAMAGE_S = settings.startup["eb-DamageScaler"].value

require "util"
local fire = util.table.deepcopy(data.raw.fire["fire-flame"])
fire.initial_lifetime = 600
fire.name="explosive-biter-flame"
fire.damage_per_tick = {amount = 1*DAMAGE_S, type = "fire"},
data:extend({fire})

local fire = util.table.deepcopy(data.raw.fire["fire-flame"])
fire.initial_lifetime = 700
fire.name="explosive-spitter-flame"
fire.damage_per_tick = {amount = 1.5*DAMAGE_S, type = "fire"},
data:extend({fire})