require ("eb-biter-animations")

local sounds = require("__base__/prototypes/entity/sounds.lua")

local ebiter_tint2 = nil --{r=0.65, g=0.75, b=0.35, a=0.7}   -- back
local leviathan_tint= {r=0.85, g=0.25, b=0.7, a=0.7}

local spit_tint1 = {r=1, g=0.3, b=0.3, a=0.95}
local spit_tint2 = {r=0.88, g=0.94, b=0, a=0.9}


local HEALTH_S = settings.startup["eb-HealthScaler"].value
local DAMAGE_S = settings.startup["eb-DamageScaler"].value

local function make_biter_area_damage(damage,radius)
return  {
					type = "area",
					radius = radius,
					force = "enemy",
					ignore_collision_condition = true,
					action_delivery =
					{
					  type = "instant",
					  target_effects =
					  {
						{
						  type = "damage",
						  damage = {amount = damage, type = "physical"}
						},
						{
						type = "create-particle",
						repeat_count = 5,
						particle_name = "explosion-remnants-particle",
						initial_height = 0.5,
						speed_from_center = 0.08,
						speed_from_center_deviation = 0.15,
						initial_vertical_speed = 0.08,
						initial_vertical_speed_deviation = 0.15,
						offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
						},
					  }
					}
                   }
end




function make_boss(k)
local scale = 1.5 + k/3
local base_resist = 17+k*2
local resistances =  
    {
      {
        type = "physical",
        decrease = k,
        percent = base_resist,
      },
      {
        type = "explosion",
        decrease = 50,
        percent = 90,
      },
      {
        type = "laser",
        percent = -330-k,
      },
      {
        type = "impact",
        decrease = k,
        percent = base_resist,
      },

      {
        type = "fire",
        percent = 100,
      },
      {
        type = "electric",
        percent = -40-k,
      },
      {
        type = "poison",
        decrease = k,
        percent = base_resist,
      },
      {
        type = "acid",
        decrease = k,
        percent = base_resist,
      },
    }
	
data:extend(
{
   {
    type = "unit",
    name='maf-boss-explosive-biter-'..k,
	localised_name =  {"",{"entity-name.maf-boss-explosive-biter"}," ",k},
    order="b-eb-e-BOSS"..k,
    icon = path .. "/graphics/explosive-biter-icon.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000 * k * HEALTH_S,
    subgroup="enemies",
    resistances = resistances,
    spawning_time_modifier = 12,
	collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{-3.4, -3.4}, {3.4, 3.4}},
    sticker_box = {{-1.2, -2}, {1.2, 0}},
    distraction_cooldown = 100,
	call_for_help_radius = 100+k*5,
	healing_per_tick = 0.1 + k/100,
	has_belt_immunity = true,
    loot =
    {
    },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      range = 1+k/5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = 
      {
        category = "melee",
        target_type = "entity",
        action =
        {
		   make_biter_area_damage((50+k*10)* DAMAGE_S,k+1),
          {
		  type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              {
                type = "damage",
                damage = { amount = 100+k*40 * DAMAGE_S, type = "physical"}
              },
            }
          }}
        }
      },
      sound =  sounds.biter_roars(0.9),
      animation = eb_biterattackanimation(scale, leviathan_tint, ebiter_tint2),
	  range_mode = "bounding-box-to-bounding-box"
    },
	vision_distance = 50+k, -- 30
	movement_speed = 0.06 + k/100,
    distance_per_frame = 0.3,
    -- in pu
    pollution_to_join_attack = 300,
    corpse = "corpse-maf-boss-explosive-biter-"..k,
    dying_explosion = "small-atomic-explosion",
    working_sound = sounds.biter_calls_big(1.4),
    dying_sound = sounds.biter_dying_big(1),
    walking_sound = sounds.biter_walk_big(1.2),
	running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
	water_reflection = biter_water_reflection(scale),	
    run_animation = eb_biterrunanimation(scale, leviathan_tint, ebiter_tint2),
	ai_settings = {destroy_when_commands_fail = false}
  },

  
  eb_add_biter_die_animation(scale, leviathan_tint, ebiter_tint2,
  {
    type = "corpse",
    name = "corpse-maf-boss-explosive-biter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-eb[biter]-ee[lev]-BOSS"..k,
	dying_speed = 0.01,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),



  {
    type = "unit",
    name = "maf-boss-explosive-spitter-"..k,
	localised_name =  {"",{"entity-name.maf-boss-explosive-spitter"}," ",k},
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health =  30000*k *HEALTH_S,
    order="b-es-e-BOSS"..k,
    subgroup="enemies",
	resistances = resistances,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
	collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{-3.4, -3.4}, {3.4, 3.4}},
	sticker_box = {{-0.4, -0.6}, {0.4, 0.2}},
    distraction_cooldown = 100,
    loot =  { },
	has_belt_immunity = true,
    min_pursue_time = 6 * 60,
    max_pursue_distance = 30,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = "eb-boss-fire-projectile-big" ,
      range=40+k*2,
      min_attack_distance=10,
      cooldown=130-k*3,
	  cooldown_deviation = 0.15,
      damage_modifier=12+k*4*DAMAGE_S,
      scale=scale,
      tint1=spit_tint1,
      tint2=spit_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
	call_for_help_radius = 150,
	vision_distance = 80+k,
    movement_speed = 0.07+ k/150,
    distance_per_frame = 0.04,
    pollution_to_join_attack = 300,
    corpse = "corpse-maf-boss-explosive-spitter-"..k,
    dying_explosion = "small-atomic-explosion",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale, spit_tint1, spit_tint2),
	ai_settings = {destroy_when_commands_fail = false}
  },



  add_spitter_die_animation(scale, spit_tint1, spit_tint2,
  {
    type = "corpse",
    name = "corpse-maf-boss-explosive-spitter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-es-e[leviathan]-BOSS"..k,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.01,
  }),   


  
})
end


for k=1,10 do make_boss(k) end