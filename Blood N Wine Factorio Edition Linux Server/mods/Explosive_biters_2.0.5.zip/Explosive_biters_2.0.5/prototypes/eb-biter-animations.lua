require ("util")

function eb_biterrunanimation(scale, tint1, tint2)
local anim =  
  {
    layers=
    {
      {
        filenames =
        {
          path .. "/graphics/biter/run/explosivebiter-run-01.png",
          path .. "/graphics/biter/run/explosivebiter-run-02.png",
          path .. "/graphics/biter/run/explosivebiter-run-03.png",
          path .. "/graphics/biter/run/explosivebiter-run-04.png"
        },
        slice = 8,
        lines_per_file = 8,
        line_length = 8,
        width = 3584/8,
        height = 3584/8,
        frame_count = 16,
        direction_count = 16,
     --   shift = util.mul_shift(util.by_pixel(-1, -5), scale),
        scale = 0.5 * scale,
      },
      {
        filenames =
        {
          path .. "/graphics/biter/run/explosivebiter-run-mask-01.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask-02.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask-03.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask-04.png"
        },
        slice = 8,
        lines_per_file = 8,
        flags = { "mask" },
        line_length = 8,
        width = 3584/8,
        height = 3584/8,
        frame_count = 16,
        direction_count = 16,
     --   shift = util.mul_shift(util.by_pixel(0, -4), scale),
        scale = 0.5 * scale,
        tint = tint1,
	--	draw_as_glow = true, blend_mode = "additive",
      },
	  
      {
        filenames =
        {
          path .. "/graphics/biter/run/explosivebiter-run-mask02-01.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask02-02.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask02-03.png",
          path .. "/graphics/biter/run/explosivebiter-run-mask02-04.png"
        },
        slice = 8,
        lines_per_file = 8,
        flags = { "mask" },
        line_length = 8,
        width = 3584/8,
        height = 3584/8,
        frame_count = 16,
        direction_count = 16,
     --   shift = util.mul_shift(util.by_pixel(0, -4), scale),
        scale = 0.5 * scale,
        tint = tint2,
      },
	  
      {
        filenames =
        {
          path .. "/graphics/biter/run/explosivebiter-run-shadow-01.png",
          path .. "/graphics/biter/run/explosivebiter-run-shadow-02.png",
          path .. "/graphics/biter/run/explosivebiter-run-shadow-03.png",
          path .. "/graphics/biter/run/explosivebiter-run-shadow-04.png"
        },
        slice = 8,
        lines_per_file = 8,
        line_length = 8,
        width = 3584/8,
        height = 3584/8,
        frame_count = 16,
     --   shift = util.mul_shift(util.by_pixel(8, -1), scale),
        direction_count = 16,
        scale = 0.5 * scale,
        draw_as_shadow = true,
      }
    }
  }
  
if not tint1 then anim.layers[2] = nil end
if not tint2 then anim.layers[3] = nil end
return anim 
end

function eb_biterattackanimation(scale, tint1, tint2)
local anim =  
  {
    layers=
    {
      {
        filenames =
        {
          path .. "/graphics/biter/attack/explosivebiter-attack-01.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-02.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-03.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-04.png"
        },
        slice = 11,
        lines_per_file = 4,
        line_length = 16,
        width = 4928/11,
        height = 1792/4,
        frame_count = 11,
        direction_count = 16,
        animation_speed = 0.4,
     --   shift = util.mul_shift(util.by_pixel(0, -25), scale),  --(-2, -26)
        scale = 0.5 *scale,
      },
      {
        filenames =
        {
          path .. "/graphics/biter/attack/explosivebiter-attack-mask-01.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask-02.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask-03.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask-04.png"
        },
        slice = 11,
        lines_per_file = 4,
        flags = { "mask" },
        line_length = 16,
        width = 4928/11,
        height = 1792/4,
        frame_count = 11,
        direction_count = 16,
        animation_speed = 0.4,
--shift = util.mul_shift(util.by_pixel(0, -4), scale), --0, -42
        scale = 0.5 * scale,
        tint = tint1,
      },

      {
        filenames =
        {
          path .. "/graphics/biter/attack/explosivebiter-attack-mask02-01.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask02-02.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask02-03.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-mask02-04.png"
        },
        slice = 11,
        lines_per_file = 4,
        flags = { "mask" },
        line_length = 16,
        width = 4928/11,
        height = 1792/4,
        frame_count = 11,
        direction_count = 16,
        animation_speed = 0.4,
--shift = util.mul_shift(util.by_pixel(0, -4), scale), --0, -42
        scale = 0.5 * scale,
        tint = tint2,
      },

      {
        filenames =
        {
          path .. "/graphics/biter/attack/explosivebiter-attack-shadow-01.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-shadow-02.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-shadow-03.png",
          path .. "/graphics/biter/attack/explosivebiter-attack-shadow-04.png"
        },
        slice = 11,
        lines_per_file = 4,
        line_length = 16,
        width = 4928/11,
        height = 1792/4,
        frame_count = 11,
     --   shift = util.mul_shift(util.by_pixel(31, -1), scale),  --(30, 0),
        direction_count = 16,
        animation_speed = 0.4,
        scale = 0.5 * scale,
        draw_as_shadow = true,
      }
    }
  }
if not tint1 then anim.layers[2] = nil end
if not tint2 then anim.layers[3] = nil end
return anim   
end


function eb_biterdieanimation(scale, tint1, tint2)
  return
  {
    layers=
    {
      {
        filenames =
        {
          path .. "/graphics/biter/die/explosivebiter-die-01.png",
          path .. "/graphics/biter/die/explosivebiter-die-02.png",
          path .. "/graphics/biter/die/explosivebiter-die-03.png",
          path .. "/graphics/biter/die/explosivebiter-die-04.png",
          path .. "/graphics/biter/die/explosivebiter-die-05.png",
          path .. "/graphics/biter/die/explosivebiter-die-06.png",
          path .. "/graphics/biter/die/explosivebiter-die-07.png",
          path .. "/graphics/biter/die/explosivebiter-die-08.png",
          path .. "/graphics/biter/die/explosivebiter-die-09.png",
          path .. "/graphics/biter/die/explosivebiter-die-10.png",
          path .. "/graphics/biter/die/explosivebiter-die-11.png",
          path .. "/graphics/biter/die/explosivebiter-die-12.png",
          path .. "/graphics/biter/die/explosivebiter-die-13.png",
          path .. "/graphics/biter/die/explosivebiter-die-14.png",
          path .. "/graphics/biter/die/explosivebiter-die-15.png",
          path .. "/graphics/biter/die/explosivebiter-die-16.png"
        },
        slice = 4,
        lines_per_file = 4,
        line_length = 4,
        width = 3840/4,
        height = 3840/4,
        frame_count = 16,
        direction_count = 16,
    --    shift= util.mul_shift(util.by_pixel(0, -4), scale),  --(-2, -4),
        scale = 0.5 * scale,
      },
      {
        filenames =
        {
          path .. "/graphics/biter/die/explosivebiter-die-mask-01.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-02.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-03.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-04.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-05.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-06.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-07.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-08.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-09.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-10.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-11.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-12.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-13.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-14.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-15.png",
          path .. "/graphics/biter/die/explosivebiter-die-mask-16.png"
        },
        slice = 4,
        lines_per_file = 4,
        flags = { "mask" },
        line_length = 4,
        width = 3840/4,
        height = 3840/4,
        frame_count = 16,
        direction_count = 16,
    --    shift = util.mul_shift(util.by_pixel(-1, -4), scale), --(0, -22)
        scale = 0.5 * scale,
        tint = tint1,

      },

      {
        filenames =
        {
          path .. "/graphics/biter/die/explosivebiter-die-shadow-01.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-02.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-03.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-04.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-05.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-06.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-07.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-08.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-09.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-10.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-11.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-12.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-13.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-14.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-15.png",
          path .. "/graphics/biter/die/explosivebiter-die-shadow-16.png"
        },
        slice = 4,
        lines_per_file = 4,
        line_length = 4,
        width = 3840/4,
        height = 3840/4,
        frame_count = 16,
      --  shift = util.mul_shift(util.by_pixel(4, 0), scale),  -- 4, 0)
        direction_count = 16,
        scale = 0.5 * scale,
        draw_as_shadow = true,

      }
    }
  }
end


function eb_add_biter_die_animation(scale, tint1, tint2, corpse)
  corpse.animation = eb_biterdieanimation(scale, tint1, tint2)
  corpse.dying_speed = 0.02
  corpse.time_before_removed = 15 * 60 * 60
  corpse.direction_shuffle = { { 1, 2, 3, 16 }, { 4, 5, 6, 7 }, { 8, 9, 10, 11 }, { 12, 13, 14, 15 } }
  corpse.shuffle_directions_at_frame = 7
  corpse.final_render_layer = "lower-object-above-shadow"

  corpse.ground_patch_render_layer = "decals" -- "transport-belt-integration"
  corpse.ground_patch_fade_in_delay = 1 / 0.02 --  in ticks; 1/dying_speed to delay the animation until dying animation finishes
  corpse.ground_patch_fade_in_speed = 0.002
  corpse.ground_patch_fade_out_start = 50 * 60
  corpse.ground_patch_fade_out_duration = 20 * 60

  local a = 1
  local d = 0.9
  corpse.ground_patch =
  {
    sheet =
    {
      filename = "__base__/graphics/entity/biter/blood-puddle-var-main.png",
      flags = { "low-object" },
      line_length = 4,
      variation_count = 4,
      frame_count = 1,
      width = 84,
      height = 68,
      shift = util.by_pixel(1, 0),
      tint = {r = 0.6 * d * a, g = 0.1 * d * a, b = 0.6 * d * a, a = a},
      scale = scale,
      hr_version =
      {
        filename = "__base__/graphics/entity/biter/hr-blood-puddle-var-main.png",
        flags = { "low-object" },
        line_length = 4,
        variation_count = 4,
        frame_count = 1,
        width = 164,
        height = 134,
        shift = util.by_pixel(-0.5,-0.5),
        tint = {r = 0.6 * d * a, g = 0.1 * d * a, b = 0.6 * d * a, a = a},
        scale = 0.5 * scale
      }
    }
  }
  return corpse
end
