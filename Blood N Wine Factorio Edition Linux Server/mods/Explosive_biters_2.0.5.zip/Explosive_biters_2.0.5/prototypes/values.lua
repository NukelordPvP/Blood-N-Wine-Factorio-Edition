eb_cooldown = 20


fire_resists =
    {
      {
        type = "explosion",
        decrease = 50,
        percent = 90,
      },
      {
        type = "fire",
        percent = 100,
      },
      {
        type = "acid",
        percent = 100,
      },
      {
        type = "laser",
        percent = -30,
      },
      {
        type = "electric",
        percent = -40,
      },

    }
	



leviathan_resists = 
    {
      {
        type = "physical",
        decrease = 12,
        percent = 75,
      },
      {
        type = "explosion",
        decrease = 50,
        percent = 90,
      },
      {
        type = "laser",
        percent = -330,
      },
      {
        type = "impact",
        percent = 50,
      },

      {
        type = "fire",
        percent = 100,
      },
      {
        type = "electric",
        percent = -40,
      },
      {
        type = "poison",
        decrease = 15,
        percent = 90,
      },
      {
        type = "acid",
        decrease = 15,
        percent = 90,
      },
    }

if data.raw["damage-type"]["bob-pierce"] then	
table.insert(leviathan_resists,	
      {
        type = "bob-pierce",
        decrease = 25,
        percent = 80,
      })
end

if data.raw["damage-type"]["cold"] then	
table.insert(leviathan_resists,	{type = "cold",percent = -100})
table.insert(fire_resists,	{type = "cold",percent = -100})
end




function make_unit_melee_attack_type(damagevalue)
  return
  {
    category = "melee",
    target_type = "entity",
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "damage",
          damage = { amount = damagevalue/2 , type = "physical"}
        },
        {
          type = "damage",
          damage = { amount = damagevalue/2 , type = "fire"}
        }		
      }
    }
  }
end
