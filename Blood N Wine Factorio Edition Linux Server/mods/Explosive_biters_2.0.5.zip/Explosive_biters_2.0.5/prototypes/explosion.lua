local DAMAGE_S = settings.startup["eb-DamageScaler"].value


data:extend({

   {
    type = "explosion",
    name = "small-atomic-explosion",
    flags = {"not-on-map"},
    animations = table.deepcopy(data.raw.explosion["nuke-explosion"].animations),
    light = {intensity = 1, size = 50, color = {r=1.0, g=1.0, b=1.0}},
    sound =
    {
      aggregation =
      {
        max_count = 1,
        remove = true
      },
      variations =
      {
        {
          filename = "__base__/sound/fight/large-explosion-1.ogg",
          volume = 1.25
        },
        {
          filename = "__base__/sound/fight/large-explosion-2.ogg",
          volume = 1.25
        }
      }
    },
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "nested-result",
            action =
            {
              type = "area",
              target_entities = false,
              trigger_from_target = true,
              repeat_count = 1000,
              radius = 8,
              action_delivery =
              {
                type = "projectile",
                projectile = "atomic-bomb-ground-zero-projectile",
                starting_speed = 0.6 * 0.8,
                starting_speed_deviation = nuke_shockwave_starting_speed_deviation,
              }
            }
          },		
          {
            type = "nested-result",
            action =
            {
              type = "area",
              target_entities = false,
              trigger_from_target = true,
              repeat_count = 1000,
              radius = 8,
              action_delivery =
              {
                type = "projectile",
                projectile = "atomic-bomb-wave",
                starting_speed = 0.5 * 0.7,
                starting_speed_deviation = nuke_shockwave_starting_speed_deviation,
              }
            }
          },		
          {
            type = "nested-result",
            action =
            {
              type = "area",
              show_in_tooltip = false,
              target_entities = false,
              trigger_from_target = true,
              repeat_count = 500,
              radius = 8,
              action_delivery =
              {
                type = "projectile",
                projectile = "atomic-bomb-wave-spawns-cluster-nuke-explosion",
                starting_speed = 0.5 * 0.7,
                starting_speed_deviation = nuke_shockwave_starting_speed_deviation,
              }
            }
          },	
		  {
            type = "nested-result",
            action =
            {
              type = "area",
              show_in_tooltip = false,
              target_entities = false,
              trigger_from_target = true,
              repeat_count = 10,
              radius = 8,
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                  {
                    type = "create-entity",
                    entity_name = "nuclear-smouldering-smoke-source",
                    tile_collision_mask = { "water-tile" }
                  }
                }
              }
            }
          },
		  {
            type = "create-entity",
            entity_name = "big-scorchmark",
            check_buildability = true
          },
		  
        }
      }
    }
  },



  
})


function eb_create_explosion(explosion_name,damage,radius)
data:extend({

   {
    type = "explosion",
    name = "eb-"..explosion_name,
    flags = {"not-on-map"},
    animations = table.deepcopy(data.raw.explosion[explosion_name].animations),
    light = {intensity = 0.7, size = radius * 10, color = {r=1.0, g=1.0, b=1.0}},
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "nested-result",
            action =
            {
              type = "area",
              radius = radius,
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                  {
                    type = "damage",
                    damage = {amount = damage*DAMAGE_S , type = "explosion"}
                  }
                }
              }
            }
          },		
	
          {
            type = "create-entity",
            entity_name = explosion_name
          },

          {
            type = "create-fire",
            entity_name = "explosive-biter-flame",
			initial_ground_flame_count = radius
          },
		  
        }
      }
    }
  }



})
end


eb_create_explosion("explosion",90,2)   -- eb-explosion
eb_create_explosion("medium-explosion",140,3) -- eb-medium-explosion
eb_create_explosion("big-explosion",190,4) -- eb-big-explosion
eb_create_explosion("big-artillery-explosion",250,5)  --  eb-big-artillery-explosion
