require ("prototypes.values")
local sounds = require("__base__/prototypes/entity/sounds.lua")


local ebiter_tint1 = {r=1, g=0.3, b=0.3, a=0.95}
local ebiter_tint2 = {r=0.88, g=0.94, b=0, a=0.9}

scale_spitter_small    = 0.5
scale_spitter_medium   = 0.7
scale_spitter_big      = 1.0
scale_spitter_behemoth = 1.2
leviathan_scale=2.5



local HEALTH_S = settings.startup["eb-HealthScaler"].value
local DAMAGE_S = settings.startup["eb-DamageScaler"].value

local stream_cluster_small = "eb-cluster-fire-projectile-small"
local stream_cluster_big = "eb-cluster-fire-projectile-big" 

if settings.startup["eb-disable-cluster-spit"].value then
	stream_cluster_small = "eb-fire-stream-small"
	stream_cluster_big = "eb-fire-stream-big"
	end



data:extend(
{

   {
    type = "unit",
    name = "small-explosive-spitter",
    icon = "__base__/graphics/icons/small-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 10*HEALTH_S,
    order="b-es-a",
    subgroup="enemies",
	resistances =fire_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
    attack_parameters = spitter_attack_parameters(
    {
      acid_stream_name = "eb-fire-stream-small",
      range=13,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=DAMAGE_S,
      scale=scale_spitter_small,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=0.4,
	  range_mode = "bounding-box-to-bounding-box"
    }),
    vision_distance = 30,
    movement_speed = 0.185,
    distance_per_frame = 0.04,
    -- in pu
    pollution_to_join_attack = 4,
    corpse = "small-explosive-spitter-corpse",
    dying_explosion = "eb-explosion",
    working_sound = sounds.spitter_calls(0.7),
    dying_sound = sounds.spitter_dying(0.4),
    walking_sound = sounds.spitter_walk(0.3),	
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['small-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_small),
    run_animation = spitterrunanimation(scale_spitter_small, ebiter_tint1, ebiter_tint2),
    ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "medium-explosive-spitter",
    icon = "__base__/graphics/icons/medium-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50*HEALTH_S,
    order="b-es-b",
    subgroup="enemies",
	resistances =fire_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.7}, {0.5, 0.7}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
    attack_parameters = spitter_mid_attack_parameters(
    {
      acid_stream_name = "eb-fire-stream-small",
      range=14,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=2*DAMAGE_S,
      scale=scale_spitter_medium,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=0.4,
	  range_mode = "bounding-box-to-bounding-box"
    }),
    vision_distance = 30,
    movement_speed = 0.165,
    distance_per_frame = 0.055,
    -- in pu
    pollution_to_join_attack = 12,
    corpse = "medium-explosive-spitter-corpse",
    dying_explosion = "eb-medium-explosion",
    working_sound = table.deepcopy(data.raw['unit']['medium-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['medium-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['medium-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['medium-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_medium),	
    run_animation = spitterrunanimation(scale_spitter_medium, ebiter_tint1, ebiter_tint2),
	ai_settings = biter_ai_settings
  },

  
  {
    type = "unit",
    name = "big-explosive-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 200*HEALTH_S,
    order="b-es-c",
    subgroup="enemies",
	resistances =fire_resists,
    spawning_time_modifier = 3,
    healing_per_tick = 0.01,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
    attack_parameters = spitter_big_attack_parameters(
    {
      acid_stream_name = stream_cluster_small,
      range=15,
      min_attack_distance=7,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=3*DAMAGE_S,
      scale=scale_spitter_big,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=0.6,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.07,
    -- in pu
    pollution_to_join_attack = 30,
    corpse = "big-explosive-spitter-corpse",
    dying_explosion = "eb-big-explosion",
    working_sound = table.deepcopy(data.raw['unit']['big-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['big-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['big-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = spitter_water_reflection(scale_spitter_big),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['big-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale_spitter_big, ebiter_tint1, ebiter_tint2),
	ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "behemoth-explosive-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 1500*HEALTH_S,
    order="b-es-d",
    subgroup="enemies",
	resistances =fire_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = stream_cluster_big,
      range=16,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=6*DAMAGE_S,
      scale=scale_spitter_behemoth,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=0.8,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.084,
    pollution_to_join_attack = 250,
    corpse = "behemoth-explosive-spitter-corpse",
    dying_explosion = "eb-big-artillery-explosion",
    working_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale_spitter_behemoth, ebiter_tint1, ebiter_tint2),
	ai_settings = biter_ai_settings
  },


  
  
  {
    type = "unit",
    name = "leviathan-explosive-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000*HEALTH_S,
    order="b-es-e",
    subgroup="enemies",
	resistances = leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.7, -2.4}, {1.7, 2.4}},
    sticker_box = {{-0.7, -1.2}, {0.7, 0.2}},
    distraction_cooldown = 300,
    loot =  { },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = stream_cluster_big,
      range=22,
      min_attack_distance=11,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=12*DAMAGE_S,
      scale=leviathan_scale,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=0.8,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 50,
    movement_speed = 0.15,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 800,
    corpse = "leviathan-explosive-spitter-corpse",
    dying_explosion = "small-atomic-explosion",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(0.9),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	
    run_animation = spitterrunanimation(leviathan_scale, ebiter_tint1, ebiter_tint2),
	ai_settings = biter_ai_settings
  },
  


  
  -- CORPSES  *********************************
  
  
  add_spitter_die_animation(leviathan_scale, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "leviathan-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-es-e[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.02,
  }),    
 
  add_spitter_die_animation(scale_spitter_small, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "small-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/small-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-es-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_medium, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "medium-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-es[spitter]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_big, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "big-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-es[spitter]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
  
  add_spitter_die_animation(scale_spitter_behemoth, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "behemoth-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-es[spitter]-d[behemoth]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
 
  
})



if not settings.startup["eb-disable-mother"].value then
data:extend(
{
 
  {
    type = "unit",
    name = "mother-explosive-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 100000*HEALTH_S,
    order="b-es-f",
    subgroup="enemies",
	resistances = leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-2, -2}, {2, 2}},
    selection_box = {{-2, -2}, {2, 2}},
    sticker_box = {{-1.5, -1.5}, {1.5, 1.5}},
    distraction_cooldown = 300,
    loot =
    {
    },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = "eb-cluster-firemother-projectile-big",
      range=35,
      min_attack_distance=11,
      cooldown=400,
	  cooldown_deviation = 0.15,
      damage_modifier=14*DAMAGE_S,
      scale=leviathan_scale +1,
      tint1=ebiter_tint1,
      tint2=ebiter_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 80,
    movement_speed = 0.10,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 1000,
    corpse = "mother-explosive-spitter-corpse",
    dying_explosion = "small-atomic-explosion",
    working_sound = sounds.spitter_calls_big(1.2),
    dying_sound = sounds.spitter_dying_big(1.2),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	
    run_animation = spitterrunanimation(leviathan_scale+1, ebiter_tint1, ebiter_tint2),
	ai_settings = biter_ai_settings
  },

  
  add_spitter_die_animation(leviathan_scale+1, ebiter_tint1, ebiter_tint2,
  {
    type = "corpse",
    name = "mother-explosive-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-es[spitter]-f[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.007,
  }),  
  
})
end