
local replaces = {
	['small-explosive-worm-turret']={'small-worm-turret'},
	['medium-explosive-worm-turret']={'medium-worm-turret'},
	['big-explosive-worm-turret']={'big-worm-turret'},
	['behemoth-explosive-worm-turret']={'behemoth-worm-turret'},
	['leviathan-explosive-worm-turret']={'behemoth-worm-turret'},
	['mother-explosive-worm-turret']={'behemoth-worm-turret'},
	['explosive-biter-spawner']={'biter-spawner','spitter-spawner'},
	}
	


local function GetLocalTemperature(surface,position)
local temperature
local calc = surface.calculate_tile_properties({'temperature'},{position}) 
if calc and calc.temperature then
	temperature = calc.temperature[1] end
return temperature
end


script.on_event(defines.events.on_biter_base_built, function(event)
if not global.disable_temperature_check then
local entity=event.entity
if replaces[entity.name] then
	local position=entity.position
	local surface=entity.surface
	local force=entity.force
	local temperature = GetLocalTemperature(surface,position) 
	if temperature then 
		if temperature > global.temp_max or temperature < global.temp_min then
			local name   = entity.name
			local replac = replaces[name][math.random(#replaces[name])]
			entity.destroy()
			surface.create_entity{name=replac, position=position, force=force} 
			end
		end
	end
end
end)


local function SetTemperatures()
global.disable_temperature_check=settings.startup["eb-disable-temperature-check"].value
global.temp_min = 20
global.temp_max = 60
if game.active_mods['alien-biomes']  then --Alien
	global.temp_min=50 
	global.temp_max=150  --volcanic areas
	end
end


local function on_configuration_changed(data)
SetTemperatures()
end

local function on_init()
SetTemperatures()
end

script.on_configuration_changed(on_configuration_changed)
script.on_init(on_init)





--[[

local names = {'small-explosive-biter',
'medium-explosive-biter',
'big-explosive-biter',
'behemoth-explosive-biter',
'explosive-leviathan-biter',
'small-explosive-spitter',
'medium-explosive-spitter',
'big-explosive-spitter',
'behemoth-explosive-spitter',
'leviathan-explosive-spitter',
'explosive-biter-spawner',
'mother-explosive-spitter',
'small-explosive-worm-turret',
'medium-explosive-worm-turret',
'big-explosive-worm-turret',
'behemoth-explosive-worm-turret',
'leviathan-explosive-worm-turret',
'mother-explosive-worm-turret'}


function On_Died(event)
local ent = event.entity
--ent.surface.create_entity{name="explosive-biter-flame", position=ent.position, force=ent.force}
end
local filters = {}
for n=1,#names do table.insert(filters, {filter = "name", name = names[n]}) end
script.on_event(defines.events.on_entity_died, On_Died, filters) 

]]