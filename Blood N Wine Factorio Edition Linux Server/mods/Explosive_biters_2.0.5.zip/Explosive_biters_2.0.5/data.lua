path = '__Explosive_biters__'
require ("prototypes.fire")
require ("prototypes.projectiles")
require ("prototypes.explosion")
require ("prototypes.spitters")
require ("prototypes.biters")
require ("prototypes.worms")
require ("prototypes.bosses")

local icon_tint = {r=0.88, g=0.94, b=0, a=0.8}


-- custom icons
function create_icons(t,name,s,tint)
local data = data.raw[t][name]
if data then 
	data.icons = {{icon=data.icon,tint=tint or icon_tint,icon_size=data.icon_size,scale=s}} 
	end
end

--create_icons('unit','small-explosive-biter',0.5)
--create_icons('unit','medium-explosive-biter',0.6)
--create_icons('unit','big-explosive-biter',0.7)
--create_icons('unit','behemoth-explosive-biter',0.8)
--create_icons('unit','explosive-leviathan-biter',0.9)

create_icons('unit','small-explosive-spitter',0.5)
create_icons('unit','medium-explosive-spitter',0.6)
create_icons('unit','big-explosive-spitter',0.7)
create_icons('unit','behemoth-explosive-spitter',0.8)
create_icons('unit','leviathan-explosive-spitter',0.9)
create_icons('unit','mother-explosive-spitter',1)

--create_icons("unit-spawner","explosive-biter-spawner",0.9)

create_icons("turret","small-explosive-worm-turret",0.5)
create_icons("turret","medium-explosive-worm-turret",0.6)
create_icons("turret","big-explosive-worm-turret",0.7)
create_icons("turret","behemoth-explosive-worm-turret",0.8)
create_icons("turret","leviathan-explosive-worm-turret",0.9)
create_icons("turret","mother-explosive-worm-turret",1)

--option to disable vanilla enemies
if settings.startup["eb-disable-vanilla"].value then
	data.raw['unit-spawner']['biter-spawner'].autoplace = nil
	data.raw['unit-spawner']['spitter-spawner'].autoplace = nil
	data.raw['turret']['small-worm-turret'].autoplace = nil
	data.raw['turret']['medium-worm-turret'].autoplace = nil
	data.raw['turret']['big-worm-turret'].autoplace = nil
	data.raw['turret']['behemoth-worm-turret'].autoplace = nil
	end