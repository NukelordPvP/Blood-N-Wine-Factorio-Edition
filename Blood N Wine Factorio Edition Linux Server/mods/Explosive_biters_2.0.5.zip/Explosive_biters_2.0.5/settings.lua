data:extend({

	{
	    type = "bool-setting",
	    name = "eb-disable-worms",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-k[trigger]",
	},

	{
	    type = "bool-setting",
	    name = "eb-disable-cluster-spit",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-k[trigger]",
	},
	{
	
	    type = "bool-setting",
	    name = "eb-disable-mother",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-k[trigger]",
	},	

	{
	
	    type = "bool-setting",
	    name = "eb-disable-temperature-check",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-k[trigger]",
	},	
		

	{
	    type = "double-setting",
	    name = "eb-HealthScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "p[modifier]-a[unit]",
	},

	{
	    type = "double-setting",
	    name = "eb-DamageScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "p[modifier]-a[unit]",
	},

   {
    type = "bool-setting",
    name = "eb-disable-vanilla",
    setting_type = "startup",
    default_value = false,
	order = "z"
   },  
		
	
})
