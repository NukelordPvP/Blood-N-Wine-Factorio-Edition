# Enemy Race Manager - Post Process
Add 2 indexes to run after ERM's init and on_configuration_change functions 