local data_util = require("data_util")

-- This source is dedicated to balancing the production of science in SE and K2

data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "wood", "wood", 50)
data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "se-space-water", "se-space-water", 20, true)

-- Biosluge balance
local biomass_recipe = table.deepcopy(data.raw.recipe["se-bio-sludge-from-wood"])
biomass_recipe.name = "se-bio-sludge-from-biomass"
biomass_recipe.icons = {
  { icon = data.raw.fluid[data_util.mod_prefix .. "bio-sludge"].icon, scale = 1, icon_size = 64  },
  { icon = data.raw.item["biomass"].icon, scale = 0.75/2, icon_size = 64  },
}
biomass_recipe.localised_name = {"recipe-name.se-bio-sludge-from-biomass"}
data:extend({biomass_recipe})
data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "wood", "biomass", 10)
--data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "se-space-water", "se-space-water", 10, true)
data_util.tech_lock_recipes("se-space-biochemical-laboratory", {"se-bio-sludge-from-biomass"})

-- Integrate Silicon into the Data Card recipe
data_util.replace_or_add_ingredient("se-data-storage-substrate", nil, "silicon", 2)

-- Create a recipe for Data Cards using Rare Metals
local adv_data_recipe = table.deepcopy(data.raw.recipe["se-data-storage-substrate"])
adv_data_recipe.name = "se-kr-rare-metal-substrate"
adv_data_recipe.energy_required = 10
adv_data_recipe.ingredients = {
  {"glass",2},
  {"iron-plate",2},
  {"silicon",2},
  {"rare-metals",2}
}
adv_data_recipe.results = {
  { "se-data-storage-substrate", 2},
  { name = "se-scrap", amount_min = 1, amount_max = 2, probability = 0.5 },
}
adv_data_recipe.icon = nil
adv_data_recipe.icons = data_util.add_icons_to_stack(
  nil, {
    {icon = data.raw.item["se-data-storage-substrate"], properties = {scale = 1, offset = {0,0}}},
    {icon = data.raw.item["rare-metals"], properties = {scale = 0.5, offset = {-0.3,-0.3}}}
  }
)
data:extend({adv_data_recipe})
data_util.allow_productivity("se-kr-rare-metal-substrate")

-- Create the Rare Metal Substrate technology
data:extend({
  {
    type = "technology",
    name = "se-kr-rare-metal-substrate",
    effects = {
      { type = "unlock-recipe", recipe = "se-kr-rare-metal-substrate"},
    },
    icons = {
      {icon = "__space-exploration-graphics__/graphics/technology/data-card.png", icon_size = 141},
      {icon = "__Krastorio2Assets__/icons/items-with-variations/rare-metals/rare-metals.png", icon_size = 64, shift = {-32, -32}}
    },
    order = "e-g",
    prerequisites = {
      "se-energy-science-pack-1",
      "kr-optimization-tech-card"
    },
    unit = {
      count = 100,
      time = 60,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"kr-optimization-tech-card", 1},
        {"space-science-pack", 1},
        {"utility-science-pack", 1},
        {"se-energy-science-pack-1", 1}
      }
    },
    check_science_packs_incompatibilities = false
  }
})