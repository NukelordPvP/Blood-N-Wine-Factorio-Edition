local data_util = require("data_util")

-- This source is dedicated to integrating K2 and SEs materials into each others intermediaries


-- Prepare for the removal of this recipe from K2, keep the name the same so that players keep it in their assemblers
if not data.raw.recipe["electronic-components-lithium"] then
  data:extend({
    {
      type = "recipe",
      name = "electronic-components-lithium",
      ingredients = {
        { name = "glass", amount = 3},
        { name = "plastic-bar", amount = 3},
        { name = "silicon", amount = 3},
        { name = "lithium", amount = 3},
      },
      results = {
        { name = "electronic-components", amount = 10}
      },
      energy_required = 10,
      main_product = "electronic-components",
      icons = {
        {icon = "__Krastorio2Assets__/icons/items-with-variations/electronic-components/electronic-components.png", icon_size = 64},
        {icon = "__Krastorio2Assets__/icons/items-with-variations/lithium/lithium.png", icon_size = 64, scale = 0.33, shift = {-8,-8}}
      },
      category = "crafting",
      enabled = false,
      always_show_made_in = false,
    }
  })
  data_util.allow_productivity("electronic-components-lithium")
end

-- Prepare for the removal of this tech from K2, keep the name the same so that players keep it researched
if not data.raw.technology["kr-efficient-fabrication"] then
  data:extend({
    {
      type = "technology",
      name = "kr-efficient-fabrication",
      effects = {
        { type = "unlock-recipe", recipe = "electronic-components-lithium"},
      },
      icons = {
        {icon = "__base__/graphics/technology/advanced-electronics.png", icon_size = 256},
        {icon = "__Krastorio2Assets__/icons/items-with-variations/lithium/lithium.png", icon_size = 64, scale = 1.5, shift = {-48, -48}}
      },
      order = "e-g",
      prerequisites = {
        "se-energy-science-pack-1",
        "kr-optimization-tech-card"
      },
      unit = {
        count = 100,
        time = 60,
        ingredients = {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"kr-optimization-tech-card", 1},
          {"space-science-pack", 1},
          {"utility-science-pack", 1},
          {"se-energy-science-pack-1", 1}
        }
      },
      check_science_packs_incompatibilities = false
    }
  })
end

-- AI Core
data_util.tech_remove_prerequisites("kr-ai-core", {"kr-quarry-minerals-extraction","utility-science-pack"})
data_util.tech_add_prerequisites("kr-ai-core",{"se-quantum-processor","se-biological-science-pack-3"})
data_util.tech_add_ingredients("kr-ai-core",{"se-energy-science-pack-3","se-biological-science-pack-3"})
table.insert(data.raw.recipe["ai-core"].ingredients, {type = "fluid", name = "se-neural-gel-2", amount = 20})
data_util.replace_or_add_ingredient("ai-core", "processing-unit", "se-quantum-processor", 2)
data_util.replace_or_add_ingredient("ai-core", "nitric-acid", "se-vitalic-reagent",4)
data_util.replace_or_add_ingredient("ai-core", nil, "se-bioelectrics-data", 2)

-- Integrate the K2 AI Core into the Naquium Processor recipe
data_util.replace_or_add_ingredient("se-naquium-processor","se-quantum-processor","ai-core",1)
data_util.replace_or_add_ingredient("se-naquium-processor-alt","se-quantum-processor","ai-core",1)

-- Nitric Acid has the nitrogen for Anion resin
data_util.replace_or_add_ingredient("se-cryonite-ion-exchange-beads","sulfuric-acid","nitric-acid",5,true)

-- Improved Pollution Filter
data.raw.technology["kr-improved-pollution-filter"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-improved-pollution-filter",{"kr-matter-tech-card"})
data_util.tech_remove_ingredients("kr-improved-pollution-filter",{"matter-tech-card","se-deep-space-science-pack-2"})
data_util.tech_add_prerequisites("kr-improved-pollution-filter",{"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-improved-pollution-filter",{"automation-science-pack","logistic-science-pack","chemical-science-pack","advanced-tech-card","se-energy-science-pack-3","se-material-science-pack-2"})

data_util.replace_or_add_ingredient("improved-pollution-filter",nil,"se-cryonite-ion-exchange-beads",1)
data_util.replace_or_add_ingredient("improved-pollution-filter",nil,"se-vulcanite-ion-exchange-beads",1)



---- Beryllium
-- Adjust Aeroframe Scaffold to use Imersium Plate
data_util.replace_or_add_ingredient("se-aeroframe-scaffold", nil, "imersium-plate", 1)

-- Adjust Aeroframe Bulkhead to use Imersium Plate
data_util.replace_or_add_ingredient("se-aeroframe-bulkhead", "se-beryllium-plate", "se-beryllium-plate", 2)
data_util.replace_or_add_ingredient("se-aeroframe-bulkhead", nil, "imersium-plate", 2)

---- Iridium
-- Adjust Heavy Composite item to require Rare Metals
data_util.replace_or_add_ingredient("se-heavy-composite",nil,"rare-metals",4)

-- Adjust Heavy Assembly item to require Imersium Beams
data_util.replace_or_add_ingredient("se-heavy-assembly",nil,"imersium-beam",2)

---- Holmium
-- Replace Holmium plate with Rare metals in Holmium solenoid recipe
data_util.replace_or_add_ingredient("se-holmium-solenoid", "se-holmium-plate", "rare-metals", 2)

-- Adjust Quantum processor to use Imersite crystal
data_util.replace_or_add_ingredient("se-quantum-processor", nil, "imersite-crystal", 2)

-- Adjust Dynamic Emitter item to require Imersite Crystals
data_util.replace_or_add_ingredient("se-dynamic-emitter",nil,"imersite-crystal",2)

---- Vitamelange
-- Replace Sulfuric acid with Nitric acid in Vitalic acid recipe
data_util.replace_or_add_ingredient("se-vitalic-acid", "sulfuric-acid", "nitric-acid", 2, true)

-- Adjust Vitalic reagent to use Lithium chloride
data_util.replace_or_add_ingredient("se-vitalic-reagent", nil, "lithium-chloride", 10)

---- Streams
-- Replace Battery with Lithium-Sulfur Battery in the Magnetic Canister recipe
data_util.replace_or_add_ingredient("se-magnetic-canister","battery","lithium-sulfur-battery",1)
data_util.replace_or_add_ingredient("se-magnetic-canister",nil,"rare-metals",1)

-- Replace Copper in Ion Stream recipe with Rare Metals
data_util.replace_or_add_ingredient("se-ion-stream","copper-plate","rare-metals",1)

-- Replace Stone in Plasma Stream recipe with Lithium
data_util.replace_or_add_ingredient("se-plasma-stream","stone","lithium",2)

-- Replace Iron in Proton Stream recipe with Lithium
data_util.replace_or_add_ingredient("se-proton-stream","iron-plate","lithium",2)

---- Lubricant alternate recipe
-- Lithium + Sulfuric Acid + Light Oil = Lubricant?

---- Biological Science
-- Adjust Nutrient gel to use fertilizer
data_util.replace_or_add_ingredient("se-nutrient-gel", nil, "fertilizer", 5)
data_util.replace_or_add_ingredient("se-nutrient-gel-methane", nil, "fertilizer", 5)

-- Adjust Genetic Data item to require Lithium Chloride
data_util.replace_or_add_ingredient("se-genetic-data",nil,"lithium-chloride",5)

---- Energy Science
-- Adjust Magnetic data packs to require Rare Metals
data_util.replace_or_add_ingredient("se-magnetic-monopole-data",nil,"rare-metals",1)
data_util.replace_or_add_ingredient("se-electromagnetic-field-data",nil,"rare-metals",5)

---- Material Science
-- Replace Stone in Material Testing Pack with Rare Metals
data_util.replace_or_add_ingredient("se-material-testing-pack","stone","rare-metals",1)

-- Adjust Material Testing Pack to require Imersite Crystals
data_util.replace_or_add_ingredient("se-material-testing-pack",nil,"imersite-crystal",1)

-- Replace Copper in Experimental Alloys Data with Rare Metals
data_util.replace_or_add_ingredient("se-experimental-alloys-data","copper-plate","rare-metals",1)

-- Include Rare Metal in scrap recycling
if data.raw.recipe["se-scrap-recycling"] then
  table.insert(data.raw.recipe["se-scrap-recycling"].results,
    {name = "raw-rare-metals", amount_min = 1, amount_max = 1, probability = 0.05}
  )
end

-- Adjust Holmium cable Processing Unit recipe to require Rare Metals
data.raw.recipe["se-processing-unit-holmium"].normal = nil
data.raw.recipe["se-processing-unit-holmium"].expensive = nil
data.raw.recipe["se-processing-unit-holmium"].ingredients = {
  {"advanced-circuit", 3},
  {"rare-metals", 2},
  {"se-holmium-cable", 8},
  {type = "fluid", name="sulfuric-acid", amount=4}
}
data.raw.recipe["se-processing-unit-holmium"].result_count = 2

-- Add Imersite Processing as a prerequisite to Energy Control Units
data_util.tech_add_prerequisites("kr-energy-control-unit", {"kr-quarry-minerals-extraction"})
data_util.tech_add_ingredients("kr-energy-control-unit", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack"})