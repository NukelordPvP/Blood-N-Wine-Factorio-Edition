local data_util = require("data_util")

-- Change the name of the K2 Antimatter to be K2 Singularity
data.raw.item["empty-antimatter-fuel-cell"].localised_name = {"item-name.empty-singularity-fuel-cell"}
data.raw.item["charged-antimatter-fuel-cell"].localised_name = {"item-name.charged-singularity-fuel-cell"}

-- Re-order K2 belts
data.raw.item["kr-advanced-splitter"].subgroup = "splitter"
data.raw.item["kr-advanced-transport-belt"].subgroup = "transport-belt"
data.raw.item["kr-advanced-underground-belt"].subgroup = "underground-belt"

data.raw.item["kr-superior-splitter"].subgroup = "splitter"
data.raw.item["kr-superior-transport-belt"].subgroup = "transport-belt"
data.raw.item["kr-superior-underground-belt"].subgroup = "underground-belt"

-- Labs ordering
data.raw.item["biusart-lab"].subgroup = "lab"
data.raw.item["kr-singularity-lab"].subgroup = "lab"

data.raw.item["se-space-science-lab"].order = "g[lab]-g3[kr-singularity-lab]"
data.raw.item["kr-singularity-lab"].order = "g[lab]-g4[kr-singularity-lab]"

-- Pipes ordering
data.raw.item["kr-steel-pipe"].subgroup = "pipe"
data.raw.item["kr-steel-pipe-to-ground"].subgroup = "pipe"
data.raw.item["kr-steel-pump"].subgroup = "pipe"

data.raw.item["se-space-pipe"].order = "a[pipe]-ab[se-space-pipe]"

if data.raw.capsule["first-aid-kit"] then
  data.raw.capsule["first-aid-kit"].capsule_action.attack_parameters.ammo_type.action.action_delivery.target_effects.damage =
    {
      type = "physical",
      amount = -50,
    }
end