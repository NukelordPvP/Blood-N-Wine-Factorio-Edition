local data_util = require("data_util")

data_util.tech_add_prerequisites("artillery-shell-range-1", {"utility-science-pack"})
data_util.tech_add_prerequisites("artillery-shell-speed-1", {"utility-science-pack"})
data_util.tech_add_prerequisites("inserter-capacity-bonus-6",{"se-material-science-pack-1"})
data_util.tech_add_prerequisites("inserter-capacity-bonus-7",{"se-material-science-pack-2"})

-- Advanced Fuel
data.raw.technology["kr-advanced-fuel"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-advanced-fuel",{"kr-fuel","production-science-pack"})
data_util.tech_remove_ingredients("kr-advanced-fuel",{"production-science-pack"})
data_util.tech_add_prerequisites("kr-advanced-fuel",{"kr-optimization-tech-card"})
data_util.tech_add_ingredients("kr-advanced-fuel",{"space-science-pack","kr-optimization-tech-card"})


data_util.tech_add_prerequisites("kr-military-5",{"utility-science-pack"})
data_util.tech_remove_ingredients("kr-optimization-tech-card",{"utility-science-pack"})
data_util.tech_remove_prerequisites("kr-superior-inserters",{"se-aeroframe-scaffold","se-heavy-bearing"})
data_util.tech_add_prerequisites("kr-superior-inserters",{"kr-advanced-tech-card"})
data_util.tech_add_prerequisites("military-4",{"se-rocket-science-pack"})
data_util.tech_add_prerequisites("se-space-platform-scaffold",{"kr-steel-fluid-handling"})

-- Remove "se-rocket-fuel-from-water" tech
data.raw.technology["se-rocket-fuel-from-water"] = nil

-- Add Advanced Tech Card tech as cost for Radar Construction Pylon
data.raw.technology["se-pylon-construction-radar"].check_science_packs_incompatibilities = false
data_util.tech_add_prerequisites("se-pylon-construction-radar",{"kr-advanced-tech-card"})
data_util.tech_add_ingredients("se-pylon-construction-radar",{"advanced-tech-card"})

-- Adapt techs that seem to be in the wrong place in the tech tree
-- Advanced Pickaxe Research
data_util.tech_remove_ingredients("kr-advanced-pickaxe",{"matter-tech-card"})
data_util.tech_add_ingredients("kr-advanced-pickaxe",{"kr-optimization-tech-card"})

data_util.tech_remove_prerequisites("se-space-decontamination-facility", {"space-science-pack"})

-- Energy Control Unit
data_util.tech_remove_ingredients("kr-energy-control-unit", {"matter-tech-card"})
data_util.tech_remove_prerequisites("kr-energy-control-unit", {"kr-matter-tech-card", "kr-singularity-lab"})
data_util.tech_add_ingredients("kr-energy-control-unit", {"se-energy-science-pack-1"})
data_util.tech_add_prerequisites("kr-energy-control-unit", {"se-energy-science-pack-1"})

-- This source is dedicated to harmonising the competing vision on how to handle prerequisites for non-infinite,
-- but leveled upgrade techs. Weapon Shooting Speed for example.

local function move_technology(tech_name, techs_to_add, ingredients_to_add, techs_to_remove, ingredients_to_remove)
  if ingredients_to_remove then
    data_util.tech_remove_ingredients(tech_name, ingredients_to_remove)
  end
  if techs_to_remove then
    data_util.tech_remove_prerequisites(tech_name, techs_to_remove)
  end
  if ingredients_to_add then
    data_util.tech_add_ingredients(tech_name, ingredients_to_add)
  end
  if techs_to_add then
    data_util.tech_add_prerequisites(tech_name, techs_to_add)
  end
end
