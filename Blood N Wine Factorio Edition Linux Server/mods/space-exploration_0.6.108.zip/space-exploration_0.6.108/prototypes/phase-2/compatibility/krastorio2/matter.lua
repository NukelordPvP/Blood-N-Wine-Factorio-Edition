local data_util = require("data_util")

local value_multiplier = 2
local k2_graphics_path = mods["Krastorio2Assets"] and "__Krastorio2Assets__" or "__Krastorio2__/graphics"

local matter = require("__Krastorio2__/lib/public/data-stages/matter-util")
--[[matter_func.createMatterRecipe(args) {
  item_name = a, -- (string) the name of raw product.
  minimum_conversion_quantity = b, -- (integer) the quantity of item necessary to make one conversion, is also the returned quantity from one deconversion.
  matter_value = c, -- (integer) how much matter is gained by conversion and necessary to create the item from matter(minimum_conversion_quantity corresponds to matter_value).
  conversion_matter_value = d, -- (optional)(integer) Different value from the matter_value of the item, that specify the matter gained by converting this item to matter (used when wanted different values on conversions).
  return_item = e, -- (optional)(string) if the return item from the decoversion(matter to item) is different from the first one.
  unlocked_by_technology = f, -- (optional)(string) what technology(the name) unlock the recipes, if isn't setted will be the first that make access to matter conversions.
  energy_required = g, -- (optional)(integer) how much time need the conversion.
  only_conversion = h, -- (optional)(boolean) if this param is true will be added only the recipe to get matter from the item, but not the deconversion from matter.
  only_deconversion = i, -- (optional)(boolean) if this param is true will be added only the recipe to get the item(or return_item) from matter, but not the conversion to matter.
  need_stabilizer = l, (optional)(boolean) if the item need stabilizer to be deconverted from matter to the original item(or return_item).
  allow_productivity = m, (optional)(boolean) if true, productivity modules can be used on de-conversion from matter (matter->item).
}
default values:
  wood 2
  iron ore 5
  raw rare metals 8
  stone 3.5
  water 0.5
  uranium ore 8
  copper plate 7.5
  rare metals 14
  plastic bar 6.6
  matter cube 1000
]]

-- matter has a similar role to the fusion-based matter fabricator,
-- but K2 matter is better in almost every way so is the clear upgrade
-- material fabricator is lat energy tech
-- matter system should be deep space tech (deep space tech needs some nice new toys anyway)
-- matter system also shouldn't be too early as it makes the resource logistic challenge much easier.
-- matter system fits well conceptually with deep space theme.

local make_tech = function(name, tech_image, item_name)
  data:extend({
    {
      type = "technology",
      name = data_util.mod_prefix .. "kr-matter-"..name.."-processing",
      mod = "space-exploration",
      icons = {
        { icon = k2_graphics_path .. "/technologies/backgrounds/matter.png", icon_size = 256},
        { icon = "__space-exploration-graphics__/graphics/technology/"..tech_image..".png", icon_size = 128}
      },
      effects = {},
      prerequisites = {"kr-matter-processing"},
      order = "g-e-e",
      unit =
      {
        count = 500,
        ingredients =
        {
          {"production-science-pack", 1},
          {"utility-science-pack", 1},
          {"matter-tech-card", 1}
        },
        time = 60
      },
      localised_name = {"technology-name.k2-conversion", {"item-name."..item_name}}
    }
  })
end

-- add as sand sink
krastorio.matter_func.createMatterRecipe({
  item_name = "sand",
  minimum_conversion_quantity = 10,
  matter_value = 1.5,
  conversion_matter_value = 1,
  energy_required = 0.5,
  need_stabilizer = false,
  unlocked_by_technology = "kr-matter-stone-processing"
})

make_tech("vulcanite", "vulcanite-processing", "se-vulcanite")
krastorio.matter_func.createMatterRecipe({
  item_name = data_util.mod_prefix .. "vulcanite",
  minimum_conversion_quantity = 10,
  matter_value = value_multiplier * 4*8, -- x8
  conversion_matter_value = value_multiplier * 4,
  energy_required = value_multiplier * 4,
  need_stabilizer = true,
  unlocked_by_technology = data_util.mod_prefix .. "kr-matter-vulcanite-processing"
})

make_tech("cryonite", "cryonite-processing", "se-cryonite")
krastorio.matter_func.createMatterRecipe({
  item_name = data_util.mod_prefix .. "cryonite",
  minimum_conversion_quantity = 10,
  matter_value = value_multiplier * 5*8, -- x8
  conversion_matter_value = value_multiplier * 5,
  energy_required = value_multiplier * 5,
  need_stabilizer = true,
  unlocked_by_technology = data_util.mod_prefix .. "kr-matter-cryonite-processing"
})

make_tech("beryllium", "beryllium-processing", "se-beryllium-ore")
krastorio.matter_func.createMatterRecipe({
  item_name = data_util.mod_prefix .. "beryllium-ore",
  minimum_conversion_quantity = 10,
  matter_value = value_multiplier * 6*8, -- x8
  conversion_matter_value = value_multiplier * 6,
  energy_required = value_multiplier * 6,
  need_stabilizer = true,
  unlocked_by_technology = data_util.mod_prefix .. "kr-matter-beryllium-processing"
})

make_tech("holmium", "holmium-processing", "se-holmium-ore")
krastorio.matter_func.createMatterRecipe({
  item_name = data_util.mod_prefix .. "holmium-ore",
  minimum_conversion_quantity = 10,
  matter_value = value_multiplier * 7*8, -- x8
  conversion_matter_value = value_multiplier * 7,
  energy_required = value_multiplier * 7,
  need_stabilizer = true,
  unlocked_by_technology = data_util.mod_prefix .. "kr-matter-holmium-processing"
})

make_tech("iridium", "iridium-processing", "se-iridium-ore")
krastorio.matter_func.createMatterRecipe({
  item_name = data_util.mod_prefix .. "iridium-ore",
  minimum_conversion_quantity = 10,
  matter_value = value_multiplier * 8*8, -- x8
  conversion_matter_value = value_multiplier * 8,
  energy_required = value_multiplier * 8,
  need_stabilizer = true,
  unlocked_by_technology = data_util.mod_prefix .. "kr-matter-iridium-processing"
})

local data_util = require("data_util")

-- This source is dedicated to integrating SE and K2's competing Matter and Antimater mechanics.
-- Progression philosophy is:
-- - SE Energy Science Pack 3
-- - SE Matter Fabricator
-- - SEK2 Matter Science Pack (Replaces K2 Matter Tech Card)
-- - SE Matter Fusion Tier 1 (Homeworld Resources)
-- - SE Energy Science Pack 4
-- - SE Matter Fusion Tier 2 (Offworld Resources)
-- - SE Deep Space Science Pack 1
-- - SE Antimatter Production / SE Matter Production (Making Particle Stream using raw materials) and Experimental Matter Processing (uses Matter Plant)
-- - SEK2 Matter Science Pack 2 (Unlocks Matter Assembler and Basic Matter Processing(Stone and Sand), and then Matter Processing (Homeworld resource ores to and from Matter))
-- - SE Deep Space Science Pack 2 (Unlocks Offworld Resources to and from Matter)
-- - SEK2 Advanced Matter Processing
-- - K2 Singularity Tech Card
-- - K2 Antimatter Reactor (Renamed to Singularity Reactor)

---- Matter
-- Break down ores into three tiers:
--  - Common: Iron, Copper, Rare Metals, Stone, Coal, Oil
--  - Rare: Holmium, Beryllium, Iridium, Uranium, Mineral Water
--  - Exotic: Vulcanite, Cryonite, Imersite
-- The Exotic tier materials never have efficient creation mechanisms, they are the resource cost for being
-- able to transition between the other materials.

-- SE Matter Costs
-- Requires 50 particle stream to make 10 common ore, costs 50 common ore to make 50 particle stream.
-- Requires 50 particle stream to make 5 rare ore, costs 50 rare ore to make 50 particle stream
-- Requires 50 particle stream to make 1 exotic ore, costs 100 exotic ore to make 50 particle stream.
-- Requires 50 particle stream to make 10 matter, this is not equivalence, this is so that the second tier of data cards for the Matter Science Pack can be made.
-- However this is a good guideline for the efficiencies of K2 matter conversion/deconversion

---- Entities
-- Convert pipe connections of the Matter Plant and Matter Assembler to non-"input-output" type to avoid player confusion due to added recipes.
local matter_plant = data.raw["assembling-machine"]["kr-matter-plant"]
local matter_assembler = data.raw["assembling-machine"]["kr-matter-assembler"]

for field, fluid_box in pairs(matter_plant.fluid_boxes) do
  if field ~= "off_when_no_fluid_recipe" then
    if fluid_box.production_type == "input" then
      for _, pipe_connection in pairs(fluid_box.pipe_connections) do
        pipe_connection.type = "input"
      end
    end
    if fluid_box.production_type == "output" then
      for _, pipe_connection in pairs(fluid_box.pipe_connections) do
        pipe_connection.type = "output"
      end
    end
  end
end

for field, fluid_box in pairs(matter_assembler.fluid_boxes) do
  if field ~= "off_when_no_fluid_recipe" then
    if fluid_box.production_type == "input" then
      for _, pipe_connection in pairs(fluid_box.pipe_connections) do
        pipe_connection.type = "input"
      end
    end
    if fluid_box.production_type == "output" then
      for _, pipe_connection in pairs(fluid_box.pipe_connections) do
        pipe_connection.type = "output"
      end
    end
  end
end

---- Technologies
-- Material Fabricator Tech adjustments
data_util.tech_remove_prerequisites("se-space-material-fabricator",{"se-energy-science-pack-4"})
data_util.tech_remove_ingredients("se-space-material-fabricator",{"se-energy-science-pack-1","se-material-science-pack-1"})
data_util.tech_add_prerequisites("se-space-material-fabricator",{"se-energy-science-pack-3"})
data_util.tech_add_ingredients("se-space-material-fabricator",{"se-energy-science-pack-3","se-material-science-pack-2"})

-- Add Matter Tech Card to Techs decending from Matter Fabricator Tech
data_util.tech_add_prerequisites("se-nanomaterial",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-nanomaterial",{"matter-tech-card"})

data_util.tech_remove_ingredients("se-space-matter-fusion",{"se-energy-science-pack-4"})
data_util.tech_add_prerequisites("se-space-matter-fusion",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-space-matter-fusion",{"production-science-pack","utility-science-pack","matter-tech-card","se-energy-science-pack-3"})

-- Duplicate Matter Fusion tech, splitting offworld materials into a second tier
local matter_fusion_2_tech = table.deepcopy(data.raw.technology["se-space-matter-fusion"])
matter_fusion_2_tech.name = "se-space-matter-fusion-2"
matter_fusion_2_tech.effects = {}
matter_fusion_2_tech.prerequisites = {
  "se-space-matter-fusion",
  "se-energy-science-pack-4"
}
data:extend({matter_fusion_2_tech})
data_util.tech_remove_ingredients("se-space-matter-fusion-2", {"se-energy-science-pack-3"})
data_util.tech_add_ingredients("se-space-matter-fusion-2", {"se-energy-science-pack-4"})
data_util.recipe_require_tech("se-matter-fusion-beryllium", "se-space-matter-fusion-2")
data_util.recipe_require_tech("se-matter-fusion-holmium", "se-space-matter-fusion-2")
data_util.recipe_require_tech("se-matter-fusion-iridium", "se-space-matter-fusion-2")
data_util.recipe_require_tech("se-matter-fusion-vulcanite", "se-space-matter-fusion-2")
data_util.recipe_require_tech("se-matter-fusion-cryonite", "se-space-matter-fusion-2")

-- Create a tech to introduce more efficient Particle Stream recipes
local adv_stream_production = table.deepcopy(data.raw.technology["se-space-matter-fusion-2"])
adv_stream_production.name = "se-kr-advanced-stream-production"
adv_stream_production.effects = {}
adv_stream_production.prerequisites = {
  "se-space-matter-fusion-2",
  "se-deep-space-science-pack-1"
}
adv_stream_production.unit = {
  count = 2000,
  time = 60,
  ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"se-rocket-science-pack", 1},
    {"space-science-pack", 1},
    {"production-science-pack", 1},
    {"utility-science-pack", 1},
    {"se-astronomic-science-pack-4", 1},
    {"se-energy-science-pack-4", 1},
    {"se-material-science-pack-4", 1},
    {"matter-tech-card", 1},
    {"se-deep-space-science-pack-1", 1},
  }
}
data:extend({adv_stream_production})

-- Create a tech to serve as a stepping stone between SE Matter Fusion and K2 Matter Processing
data:extend({
  {
    type = "technology",
    name = "se-kr-experimental-matter-processing",
    effects = {}, -- Matter Plant done by function after this creation
    icon = "__Krastorio2Assets__/icons/entities/matter-plant.png",
    icon_size = 128,
    order = "e-g",
    prerequisites = {
      "se-naquium-cube",
      "se-space-matter-fusion-2",
    },
    unit = {
      count = 200,
      time = 120,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"se-rocket-science-pack", 1},
        {"space-science-pack", 1},
        {"se-astronomic-science-pack-4", 1},
        {"se-energy-science-pack-4", 1},
        {"se-material-science-pack-4", 1},
        {"matter-tech-card", 1},
        {"se-deep-space-science-pack-1", 1},
      }
    },
    check_science_packs_incompatibilities = false
  }
})
data_util.tech_add_prerequisites("se-kr-space-catalogue-matter-2", {"se-kr-experimental-matter-processing"})

-- Unlock the K2 Matter Plant with Experimental Matter Processing
data_util.recipe_require_tech("kr-matter-plant", "se-kr-experimental-matter-processing")

-- Create a tech to introduce basic K2 Matter Processing
local basic_matter_tech = table.deepcopy(data.raw.technology["kr-matter-processing"])
basic_matter_tech.name = "se-kr-basic-matter-processing"
basic_matter_tech.effects = {}
basic_matter_tech.icon = "__Krastorio2Assets__/icons/entities/matter-assembler.png"
basic_matter_tech.icon_size = 128
basic_matter_tech.prerequisites = {
  "se-kr-matter-science-pack-2"
}
basic_matter_tech.unit = {
  count = 300,
  time = 120,
  ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"production-science-pack", 1},
    {"utility-science-pack", 1},
    {"se-rocket-science-pack", 1},
    {"space-science-pack", 1},
    {"se-astronomic-science-pack-4", 1},
    {"se-energy-science-pack-4", 1},
    {"se-material-science-pack-4", 1},
    {"se-kr-matter-science-pack-2", 1},
    {"se-deep-space-science-pack-1", 1},
  }
}
data:extend({basic_matter_tech})
data_util.recipe_require_tech("kr-matter-assembler", "se-kr-basic-matter-processing")
data_util.recipe_require_tech("stone-to-matter", "se-kr-basic-matter-processing")
data.raw.recipe["stone-to-matter"].category = "basic-matter-conversion"
data.raw.recipe["stone-to-matter"].subgroup = "basic-matter-conversion"
data_util.recipe_require_tech("sand-to-matter", "se-kr-basic-matter-processing")
data.raw.recipe["sand-to-matter"].category = "basic-matter-conversion"
data.raw.recipe["sand-to-matter"].subgroup = "basic-matter-conversion"

-- Add recipe categories to the machines
table.insert(data.raw["assembling-machine"]["se-space-material-fabricator"].crafting_categories, "advanced-particle-stream")
table.insert(data.raw["assembling-machine"]["kr-matter-plant"].crafting_categories, "basic-matter-conversion")
table.insert(data.raw["assembling-machine"]["kr-matter-plant"].crafting_categories, "advanced-matter-conversion")

-- Update Matter Processing Techs requirements
data_util.tech_remove_prerequisites("kr-matter-processing", {"kr-imersium-processing","kr-energy-control-unit"})
data_util.tech_remove_ingredients("kr-matter-processing", {"matter-tech-card"})
data_util.tech_add_prerequisites("kr-matter-processing",{"se-kr-basic-matter-processing"})
data_util.tech_add_ingredients("kr-matter-processing", {"automation-science-pack","logistic-science-pack","chemical-science-pack","se-astronomic-science-pack-4","se-material-science-pack-4","se-energy-science-pack-4","se-deep-space-science-pack-2", "se-kr-matter-science-pack-2"})

-- Create a tech for unlocking advanced matter processing
local adv_matter_processing = table.deepcopy(data.raw.technology["kr-matter-processing"])
adv_matter_processing.name = "se-kr-advanced-matter-processing"
adv_matter_processing.effects = {}
adv_matter_processing.prerequisites = {
  "kr-matter-processing",
  "se-naquium-tessaract"
}
data:extend({adv_matter_processing})
data_util.recipe_require_tech("matter-stabilizer", "se-kr-advanced-matter-processing")
data_util.recipe_require_tech("charge-stabilizer", "se-kr-advanced-matter-processing")

-- Alter Matter Processing tech icon
data.raw.technology["kr-matter-processing"].icon = "__Krastorio2Assets__/icons/entities/stabilizer-charging-station.png"
data.raw.technology["kr-matter-processing"].icon_size = 128

-- Basic Stabilizer
local basic_stabilizer = table.deepcopy(data.raw.item["matter-stabilizer"])
basic_stabilizer.name = "se-kr-basic-stabilizer"
basic_stabilizer.localised_name = {"item-name.se-kr-basic-stabilizer"}
basic_stabilizer.order = "w1[matter-stabilizers]-a1[basic-matter-stabilizer]"
basic_stabilizer.icons = {
  {icon = kr_items_icons_path .. "matter-stabilizer.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/compatability/icons/basic-matter-stabilizer-layer.png", icon_size = 64}
}
data:extend({basic_stabilizer})

local basic_stabilizer_charged = table.deepcopy(data.raw.item["charged-matter-stabilizer"])
basic_stabilizer_charged.name = "se-kr-charged-basic-stabilizer"
basic_stabilizer_charged.localised_name = {"item-name.se-kr-charged-basic-stabilizer"}
basic_stabilizer_charged.order = "w1[matter-stabilizers]-a2[charged-basic-matter-stabilizer]"
basic_stabilizer_charged.icons = {
  {icon = kr_items_icons_path .. "charged-matter-stabilizer.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/compatability/icons/basic-matter-stabilizer-layer.png", icon_size = 64}
}
basic_stabilizer_charged.pictures.layers = {
  {
    size = 64,
    filename = kr_items_icons_path .. "charged-matter-stabilizer.png",
    scale = 0.25,
  },
  {
    size = 64,
    filename = "__space-exploration-graphics__/graphics/compatability/icons/basic-matter-stabilizer-layer.png",
    scale = 0.25,
  }
}
data:extend({basic_stabilizer_charged})

-- Update Matter Conversion and De-Conversion recipe techs to have A4, E4, M4, Matter 2 and DSS2 in the cost
local cards_to_add = {
  "automation-science-pack",
  "logistic-science-pack",
  "chemical-science-pack",
  "se-astronomic-science-pack-4",
  "se-energy-science-pack-4",
  "se-material-science-pack-4",
  "se-deep-space-science-pack-2",
  "se-kr-matter-science-pack-2"
}

data_util.tech_remove_ingredients("kr-matter-coal-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-copper-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-iron-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-minerals-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-oil-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-rare-metals-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-stone-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-uranium-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("kr-matter-water-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("se-kr-matter-beryllium-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("se-kr-matter-cryonite-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("se-kr-matter-holmium-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("se-kr-matter-iridium-processing", {"matter-tech-card"})
data_util.tech_remove_ingredients("se-kr-matter-vulcanite-processing", {"matter-tech-card"})
data_util.tech_add_ingredients("kr-matter-coal-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-copper-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-iron-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-minerals-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-oil-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-rare-metals-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-stone-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-uranium-processing", cards_to_add)
data_util.tech_add_ingredients("kr-matter-water-processing", cards_to_add)
data_util.tech_add_ingredients("se-kr-matter-beryllium-processing", cards_to_add)
data_util.tech_add_ingredients("se-kr-matter-cryonite-processing", cards_to_add)
data_util.tech_add_ingredients("se-kr-matter-holmium-processing", cards_to_add)
data_util.tech_add_ingredients("se-kr-matter-iridium-processing", cards_to_add)
data_util.tech_add_ingredients("se-kr-matter-vulcanite-processing", cards_to_add)

-- Split the Conversion/De-conversion techs into raw material tier and processed material tier
local function extend_tech(name)
  if data.raw.technology[name] then
    local new_tech = table.deepcopy(data.raw.technology[name])
    new_tech.name = "se-" .. new_tech.name .. "-adv"
    new_tech.effects = {}
    new_tech.prerequisites = {
      name,
      "se-kr-advanced-matter-processing"
    }
    data:extend({new_tech})
  end
end
extend_tech("kr-matter-copper-processing")
data_util.recipe_require_tech("matter-to-copper-plate","se-kr-matter-copper-processing-adv")
extend_tech("kr-matter-iron-processing")
data_util.recipe_require_tech("matter-to-iron-plate","se-kr-matter-iron-processing-adv")
data_util.recipe_require_tech("matter-to-steel-plate","se-kr-matter-iron-processing-adv")
extend_tech("kr-matter-oil-processing")
data_util.recipe_require_tech("matter-to-sulfur","se-kr-matter-oil-processing-adv")
data_util.recipe_require_tech("matter-to-plastic-bar","se-kr-matter-oil-processing-adv")
extend_tech("kr-matter-rare-metals-processing")
data_util.recipe_require_tech("matter-to-rare-metals","se-kr-matter-rare-metals-processing-adv")
-- Stone
data_util.recipe_require_tech("matter-to-stone","kr-matter-processing")
data_util.recipe_require_tech("matter-to-sand","kr-matter-processing")
-- Move techs only the non-Basic matter stabilizer to need the advanced matter processing tech
-- Iridium
data_util.tech_remove_prerequisites("se-kr-matter-iridium-processing",{"kr-matter-processing"})
data_util.tech_add_prerequisites("se-kr-matter-iridium-processing",{"se-kr-advanced-matter-processing"})
-- Beryllium
data_util.tech_remove_prerequisites("se-kr-matter-beryllium-processing",{"kr-matter-processing"})
data_util.tech_add_prerequisites("se-kr-matter-beryllium-processing",{"se-kr-advanced-matter-processing"})
-- Holmium
data_util.tech_remove_prerequisites("se-kr-matter-holmium-processing",{"kr-matter-processing"})
data_util.tech_add_prerequisites("se-kr-matter-holmium-processing",{"se-kr-advanced-matter-processing"})
-- Cryonite
data_util.tech_remove_prerequisites("se-kr-matter-cryonite-processing",{"kr-matter-processing"})
data_util.tech_add_prerequisites("se-kr-matter-cryonite-processing",{"se-kr-advanced-matter-processing"})
-- Vulcanite
data_util.tech_remove_prerequisites("se-kr-matter-vulcanite-processing",{"kr-matter-processing"})
data_util.tech_add_prerequisites("se-kr-matter-vulcanite-processing",{"se-kr-advanced-matter-processing"})
-- Imersite
data_util.tech_remove_prerequisites("kr-matter-minerals-processing", {"kr-matter-processing"})
data_util.tech_add_prerequisites("kr-matter-minerals-processing", {"se-kr-advanced-matter-processing"})


-- SE Antimatter
-- Update SE Antimatter Production Tech to require Matter Fusion Tech
data_util.tech_add_prerequisites("se-antimatter-production",{"se-space-matter-fusion-2"})
data_util.tech_add_ingredients("se-antimatter-production",{"matter-tech-card"})

-- Add Matter Tech Card to Techs decending from SE Antimatter Production Tech
data_util.tech_add_ingredients("se-antimatter-reactor",{"matter-tech-card"})
data_util.tech_add_ingredients("se-antimatter-engine",{"matter-tech-card"})
data_util.tech_add_ingredients("se-spaceship-victory",{"matter-tech-card"})

-- Move K2 Antimatter Weaponry to SE Antimatter Reactor
if data.raw.technology["kr-antimatter-ammo"] then -- Can be disabled by some other mods e.g. "Realistic Fusion Weaponry"
  data.raw.technology["kr-antimatter-ammo"].check_science_packs_incompatibilities = false
  data_util.tech_remove_prerequisites("kr-antimatter-ammo",{"kr-antimatter-reactor"})
  data_util.tech_remove_ingredients("kr-antimatter-ammo",{"kr-optimization-tech-card","singularity-tech-card"})
  data_util.tech_add_prerequisites("kr-antimatter-ammo",{"se-antimatter-reactor", "kr-advanced-tech-card"})
  data_util.tech_add_ingredients("kr-antimatter-ammo",{"automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","se-astronomic-science-pack-4","se-energy-science-pack-4","se-material-science-pack-4","se-deep-space-science-pack-1"})
end

-- Add Matter Tech Card to Naquium processing
data_util.tech_add_prerequisites("se-processing-naquium",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-processing-naquium",{"matter-tech-card"})

-- Add Matter Tech Card to Nanomaterial requiring techs
data_util.tech_add_ingredients("se-adaptive-armour-5",{"matter-tech-card"})
data_util.tech_add_ingredients("se-big-heat-exchanger",{"matter-tech-card"})
data_util.tech_add_ingredients("se-big-turbine",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Cube requiring techs
data_util.tech_add_ingredients("se-naquium-cube",{"matter-tech-card"})
data_util.tech_add_ingredients("se-space-solar-panel-3",{"matter-tech-card"})
data_util.tech_add_ingredients("se-space-accumulator-2",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Tesseract requiring techs
data_util.tech_add_ingredients("se-naquium-tessaract",{"matter-tech-card"})
data_util.tech_add_ingredients("se-lifesupport-equipment-4",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Processor requiring techs
data_util.tech_add_ingredients("se-naquium-processor",{"matter-tech-card"})
data_util.tech_add_ingredients("se-thruster-suit-4",{"matter-tech-card"})
data_util.tech_add_ingredients("se-nexus",{"matter-tech-card"})

-- Nexus also needs basic cards adding
data_util.tech_add_ingredients("se-nexus",{"automation-science-pack","logistic-science-pack","chemical-science-pack"})

-- Add Matter Tech Card to Factory Spaceship
data_util.tech_add_ingredients("se-spaceship-integrity-7",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-1",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-2",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-3",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-4",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-5",{"matter-tech-card"})

-----------------
---- Recipes ----
-----------------
local raw_rare_metals_recipe = table.deepcopy(data.raw.recipe["se-matter-fusion-iron"])
raw_rare_metals_recipe.name = "se-matter-fusion-raw-rare-metals"
raw_rare_metals_recipe.icon = nil
raw_rare_metals_recipe.icons = data_util.transition_icons(
  {
    icon = data.raw.fluid["se-particle-stream"].icon,
    icon_size = data.raw.fluid["se-particle-stream"].icon_size, scale = 0.5
  },
  {
    icon = data.raw.item["raw-rare-metals"].icon,
    icon_size = data.raw.item["raw-rare-metals"].icon_size, scale = 0.5
  }
)
raw_rare_metals_recipe.results = {
  { name = "raw-rare-metals", amount = 10},
  { name = "se-contaminated-scrap", amount = 1},
  { name = "se-kr-matter-synthesis-data", amount_min = 1, amount_max = 1, probability = 0.99},
  { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.01},
  { type = "fluid", name = "se-space-coolant-hot", amount = 25},
}
raw_rare_metals_recipe.localised_name = {"recipe-name.se-matter-fusion-to", {"item-name.raw-rare-metals"}}
data:extend({raw_rare_metals_recipe})
data_util.replace_or_add_ingredient("se-matter-fusion-raw-rare-metals", "se-fusion-test-data", "se-kr-matter-synthesis-data", 1)
data_util.recipe_require_tech("se-matter-fusion-raw-rare-metals", "se-space-matter-fusion")

local raw_imersite_recipe = table.deepcopy(data.raw.recipe["se-matter-fusion-vulcanite"])
raw_imersite_recipe.name = "se-matter-fusion-raw-imersite"
raw_imersite_recipe.icon = nil
raw_imersite_recipe.icons = data_util.transition_icons(
  {
    icon = data.raw.fluid["se-particle-stream"].icon,
    icon_size = data.raw.fluid["se-particle-stream"].icon_size, scale = 0.5
  },
  {
    icon = data.raw.item["raw-imersite"].icon,
    icon_size = data.raw.item["raw-imersite"].icon_size, scale = 0.5
  }
)
raw_imersite_recipe.normal.results = {
  { name = "raw-imersite", amount = 1},
  { name = "se-contaminated-scrap", amount = 1},
  { name = "se-fusion-test-data", amount_min = 1, amount_max = 1, probability = 0.99},
  { name = "se-kr-matter-synthesis-data", amount_min = 1, amount_max = 1, probability = 0.99},
  { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.02},
  { type = "fluid", name = "se-space-coolant-hot", amount = 25},
}
raw_imersite_recipe.expensive.results = {
  { name = "raw-imersite", amount = 1},
  { name = "se-contaminated-scrap", amount = 1},
  { name = "se-fusion-test-data", amount_min = 1, amount_max = 1, probability = 0.99},
  { name = "se-kr-matter-synthesis-data", amount_min = 1, amount_max = 1, probability = 0.99},
  { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.02},
  { type = "fluid", name = "se-space-coolant-hot", amount = 25},
}
raw_imersite_recipe.localised_name = {"recipe-name.se-matter-fusion-to", {"item-name.raw-imersite"}}
data:extend({raw_imersite_recipe})
data_util.replace_or_add_ingredient("se-matter-fusion-raw-imersite", nil, "se-kr-matter-synthesis-data", 1)
data_util.recipe_require_tech("se-matter-fusion-raw-imersite", "se-space-matter-fusion-2")

-- Update 1st Tier Fusion recipes to use Matter Synthesis Data instead of Fusion Test Data
data_util.replace_or_add_ingredient("se-matter-fusion-iron", "se-fusion-test-data", "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-iron", "se-fusion-test-data", "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-iron", "se-junk-data", "se-broken-data", nil, nil, 1, 1, 0.01)

data_util.replace_or_add_ingredient("se-matter-fusion-copper", "se-fusion-test-data", "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-copper", "se-fusion-test-data", "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-copper", "se-junk-data", "se-broken-data", nil, nil, 1, 1, 0.01)

data_util.replace_or_add_ingredient("se-matter-fusion-stone", "se-fusion-test-data", "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-stone", "se-fusion-test-data", "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-stone", "se-junk-data", "se-broken-data", nil, nil, 1, 1, 0.01)

data_util.replace_or_add_ingredient("se-matter-fusion-uranium", "se-fusion-test-data", "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-uranium", nil, "uranium-ore", 5)
data_util.replace_or_add_result("se-matter-fusion-uranium", "se-fusion-test-data", "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-uranium", "se-junk-data", "se-broken-data", nil, nil, 1, 1, 0.01)

-- Update 2nd Tier Fusion recipes to use Matter Synthesis Data in addition to Fusion Test Data, and improve their material output
data_util.replace_or_add_ingredient("se-matter-fusion-beryllium", nil, "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-beryllium", nil, "se-beryllium-ore", 5)
data_util.replace_or_add_result("se-matter-fusion-beryllium", nil, "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-beryllium", "se-junk-data", "se-broken-data", nil ,nil, 1, 1, 0.02)

data_util.replace_or_add_ingredient("se-matter-fusion-holmium", nil, "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-holmium", nil, "se-holmium-ore", 5)
data_util.replace_or_add_result("se-matter-fusion-holmium", nil, "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-holmium", "se-junk-data", "se-broken-data", nil ,nil, 1, 1, 0.02)

data_util.replace_or_add_ingredient("se-matter-fusion-iridium", nil, "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-iridium", nil, "se-iridium-ore", 5)
data_util.replace_or_add_result("se-matter-fusion-iridium", nil, "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-iridium", "se-junk-data", "se-broken-data", nil ,nil, 1, 1, 0.02)

data_util.replace_or_add_ingredient("se-matter-fusion-vulcanite", nil, "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-vulcanite", nil, "se-vulcanite", 1)
data_util.replace_or_add_result("se-matter-fusion-vulcanite", nil, "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-vulcanite", "se-junk-data", "se-broken-data", nil ,nil, 1, 1, 0.02)

data_util.replace_or_add_ingredient("se-matter-fusion-cryonite", nil, "se-kr-matter-synthesis-data", 1)
data_util.replace_or_add_result("se-matter-fusion-cryonite", nil, "se-cryonite", 1)
data_util.replace_or_add_result("se-matter-fusion-cryonite", nil, "se-kr-matter-synthesis-data", nil, nil, 1, 1, 0.99)
data_util.replace_or_add_result("se-matter-fusion-cryonite", "se-junk-data", "se-broken-data", nil ,nil, 1, 1, 0.02)

-- Create a basic, ineffective recipes for SE Matter creation.
local function make_particle_stream_recipe(name, item_name, required_amount, bonus_particle_stream)
  data_util.make_recipe({
    type = "recipe",
    name = "se-kr-" .. name .. "-to-particle-stream",
    category = "space-materialisation",
    subgroup = "advanced-particle-stream",
    localised_name = {"recipe-name.se-kr-matter-liberation", {"item-name." .. item_name}},
    ingredients = {
      { name = item_name, amount = required_amount},
      { name = "se-kr-matter-liberation-data", amount = 1},
      { type = "fluid", name = "se-particle-stream", amount = 50},
    },
    results = {
      { name = "se-kr-matter-liberation-data", amount_min = 1, amount_max = 1, probability = 0.99},
      { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.01},
      { type = "fluid", name = "se-particle-stream", amount = 50 + bonus_particle_stream},
    },
    energy_required = 30,
    -- SE Definition
    icons = data_util.transition_icons(
      {
        icon = data.raw.item[item_name].icon,
        icon_size = data.raw.item[item_name].icon_size, scale = 0.5
      },
      {
        icon = data.raw.fluid["se-particle-stream"].icon,
        icon_size = data.raw.fluid["se-particle-stream"].icon_size, scale = 0.5
      }
    ),
    allow_as_intermediate = false,
    always_show_made_in = true,
    allow_decomposition = false,
  })
  data_util.recipe_require_tech("se-kr-".. name .. "-to-particle-stream", "se-kr-advanced-stream-production")
end
-- Requires 50 particle stream to make 10 common ore, costs 50 common ore to make 50 particle stream.
make_particle_stream_recipe("iron", "iron-ore", 10, 10)
make_particle_stream_recipe("copper", "copper-ore", 10, 10)
make_particle_stream_recipe("rare-metals", "raw-rare-metals", 10, 10)
make_particle_stream_recipe("stone", "stone", 10, 10)
-- Requires 50 particle stream to make 5 rare ore, costs 50 rare ore to make 50 particle stream
make_particle_stream_recipe("uranium", "uranium-ore", 10, 10)
make_particle_stream_recipe("beryllium", "se-beryllium-ore", 10, 10)
make_particle_stream_recipe("holmium", "se-holmium-ore", 10, 10)
make_particle_stream_recipe("iridium", "se-iridium-ore", 10, 10)
-- Requires 50 particle stream to make 1 exotic ore, costs 100 exotic ore to make 50 particle stream.
make_particle_stream_recipe("imersite", "raw-imersite", 10, 5)
make_particle_stream_recipe("vulcanite", "se-vulcanite", 10, 5)
make_particle_stream_recipe("cryonite", "se-cryonite", 10, 5)

---- K2 Matter Recipes
-- Remove biological matter recipes as conversion is not able to make "complex biochemistry"
krastorio.matter_func.removeMatterRecipe("wood")
krastorio.matter_func.removeMatterRecipe("biomass")
-- Remove imersite powder to bring in line with vulcanite and cryonite
krastorio.matter_func.removeMatterRecipe("imersite-powder")
-- Add missing matter to raw imersite recipe
krastorio.matter_func.createMatterRecipe({
  item_name = "raw-imersite",
  minimum_conversion_quantity = 10,
  matter_value = 10,
  energy_required = 1,
  only_deconversion = true,
  need_stabilizer = true,
  unlocked_by_technology = "kr-matter-minerals-processing"
})

-- Experimental Matter Processing
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-experimental-matter-processing",
  localised_name = {"recipe-name.se-kr-experimental-matter-processing"},
  category = "basic-matter-conversion",
  subgroup = "basic-matter-conversion",
  ingredients = {
    { name = "se-material-testing-pack", amount = 5},
    { name = "se-kr-matter-catalogue-1", amount = 1},
    { type = "fluid", name = "se-particle-stream", amount = 50},
  },
  results = {
    { name = "se-scrap", amount = 15},
    { type = "fluid", name = "matter", amount = 10}, -- amount can change if needed.
  },
  icons = {
    { icon = kr_arrows_icons_path .. "arrow-m.png", icon_size = 64},
  },
  main_product = "matter",
  allow_as_intermediate = false,
})
krastorio.icons.addOverlayIcons(data.raw.recipe["se-kr-experimental-matter-processing"], krastorio.icons.getIconsForOverlay(krastorio.items.getItem("se-particle-stream")), 64, 0.28, { -8, -6})
table.insert(data.raw.recipe["se-kr-experimental-matter-processing"].icons, {
  icon = kr_fluids_icons_path .. "matter.png",
  icon_size = 64,
  scale = 0.28,
  shift = { 4, 8},
})
data_util.recipe_require_tech("kr-matter-plant", "se-kr-experimental-matter-processing")
data_util.recipe_require_tech("se-kr-experimental-matter-processing", "se-kr-experimental-matter-processing")


-- Add Naquium Cube nad other SE Materials to K2 Matter buildings
data.raw.recipe["kr-matter-plant"].normal.ingredients = {
  { name = "imersium-beam", amount = 5},
  { name = "se-heat-shielding", amount = 10},
  { name = "se-heavy-assembly", amount = 4},
  { name = "ai-core", amount = 2},
  { name = "se-lattice-pressure-vessel", amount = 5},
  { name = "se-kr-matter-catalogue-1", amount = 1},
  { name = "se-naquium-cube", amount = 1},
  { name = "se-space-pipe", amount = 10},
}
data.raw.recipe["kr-matter-plant"].expensive.ingredients = data.raw.recipe["kr-matter-plant"].normal.ingredients

data.raw.recipe["kr-matter-assembler"].normal.ingredients = {
  { name = "imersium-beam", amount = 5},
  { name = "se-heat-shielding", amount = 10},
  { name = "se-heavy-assembly", amount = 4},
  { name = "ai-core", amount = 2},
  { name = "se-lattice-pressure-vessel", amount = 5},
  { name = "se-kr-matter-catalogue-2", amount = 1},
  { name = "se-naquium-cube", amount = 1},
  { name = "se-space-pipe", amount = 10},
}
data.raw.recipe["kr-matter-assembler"].expensive.ingredients = data.raw.recipe["kr-matter-assembler"].normal.ingredients

-- Make Basic Stabilizer recipes
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-basic-stabilizer",
  ingredients = {
    { name = "se-magnetic-canister", amount = 1},
    { name = "se-kr-matter-catalogue-2", amount = 1},
    { name = "se-lattice-pressure-vessel", amount = 1},
    { name = "energy-control-unit", amount = 2},
    { name = "ai-core", amount = 1},
  },
  results = {
    { name = "se-kr-basic-stabilizer", amount = 1},
  },
  icons = {
    {icon = kr_items_icons_path .. "matter-stabilizer.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/compatability/icons/basic-matter-stabilizer-layer.png", icon_size = 64}
  },
  main_product = "se-kr-basic-stabilizer",
  allow_as_intermediate = false,
  allow_productivity = true,
  energy_required = 5
})

data_util.make_recipe({
  type = "recipe",
  name = "se-kr-charge-basic-stabilizer",
  category = "stabilizer-charging",
  subgroup = "intermediate-product",
  ingredients = {
    { name = "se-kr-basic-stabilizer", amount = 1},
  },
  results = {
    { name = "se-kr-charged-basic-stabilizer", amount = 1},
  },
  icons = {
    {icon = kr_items_icons_path .. "charged-matter-stabilizer.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/compatability/icons/basic-matter-stabilizer-layer.png", icon_size = 64}
  },
  main_product = "se-kr-charged-basic-stabilizer",
  allow_as_intermediate = false,
  energy_required = 2,
})

data_util.recipe_require_tech("se-kr-basic-stabilizer", "kr-matter-processing")
data_util.recipe_require_tech("se-kr-charge-basic-stabilizer", "kr-matter-processing")

-- Require Naquium Cube and other SE Materials for the Stabilizer Charging Station
data_util.replace_or_add_ingredient("kr-stabilizer-charging-station", nil, "se-heavy-assembly", 2)
data_util.replace_or_add_ingredient("kr-stabilizer-charging-station", nil, "se-quantum-processor", 2)
data_util.replace_or_add_ingredient("kr-stabilizer-charging-station", nil, "se-dynamic-emitter", 1)
data_util.replace_or_add_ingredient("kr-stabilizer-charging-station", nil, "se-naquium-cube", 1)

-- Non-basic Stabiliser recipe
data_util.replace_or_add_ingredient("matter-stabilizer", "processing-unit", "se-kr-basic-stabilizer", 1)
data_util.replace_or_add_ingredient("matter-stabilizer", "energy-control-unit", "ai-core", 1)
data_util.replace_or_add_ingredient("matter-stabilizer", "imersium-plate", "se-quantum-processor", 2)
data_util.replace_or_add_ingredient("matter-stabilizer", nil, "se-naquium-tessaract", 1)

-- Introduce the basic stabilizer to the raw resource matter deconversion recipes.
local function add_basic_stabilizer(recipe)
  data_util.replace_or_add_ingredient(recipe, nil, "se-kr-charged-basic-stabilizer", 1)
  data_util.replace_or_add_result(recipe, nil, "se-kr-charged-basic-stabilizer", nil, nil, 1, 1, 0.199)
  data_util.replace_or_add_result(recipe, nil, "se-kr-basic-stabilizer", nil, nil, 1, 1, 0.8)
end

add_basic_stabilizer("matter-to-stone")
add_basic_stabilizer("matter-to-sand")
add_basic_stabilizer("matter-to-coal")
add_basic_stabilizer("matter-to-copper-ore")
add_basic_stabilizer("matter-to-iron-ore")
add_basic_stabilizer("matter-to-crude-oil")
add_basic_stabilizer("matter-to-raw-rare-metals")
add_basic_stabilizer("matter-to-uranium-ore")
add_basic_stabilizer("matter-to-uranium-238")
add_basic_stabilizer("matter-to-water")
add_basic_stabilizer("matter-to-mineral-water")

-- Replace Singularity Cells with Antimatter Canisters in Antimatter Weaponry
data_util.replace_or_add_ingredient("antimatter-turret-rocket", "charged-antimatter-fuel-cell", "se-antimatter-canister", 1)
data_util.replace_or_add_ingredient("antimatter-artillery-shell", "charged-antimatter-fuel-cell", "se-antimatter-canister", 3)
data_util.replace_or_add_ingredient("antimatter-rocket", "charged-antimatter-fuel-cell", "se-antimatter-canister", 2)
data_util.replace_or_add_ingredient("antimatter-railgun-shell", "charged-antimatter-fuel-cell", "se-antimatter-canister", 1)

data_util.replace_or_add_ingredient("antimatter-reactor-equipment", nil, "se-naquium-processor", 1)

-- Matter Cube Technology
data.raw.technology["kr-matter-cube"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-matter-cube",{"kr-optimization-tech-card","advanced-tech-card","matter-tech-card"})
data_util.tech_add_ingredients("kr-matter-cube",{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-energy-science-pack-4","se-material-science-pack-4","se-deep-space-science-pack-3","se-kr-matter-science-pack-2"})


-- reduce effectivness of matter deconversion
-- otherwise it is too easy to bypass planet resource restrictions.
for _, recipe in pairs(data.raw.recipe) do
  if recipe.subgroup == "matter-deconversion" then
    if recipe.ingredients then
      for _, ingredient in pairs(recipe.ingredients) do
        if ingredient.name == "matter" then
          ingredient.amount = ingredient.amount * 2
          if ingredient.catalyst_amount then
            ingredient.catalyst_amount = ingredient.catalyst_amount * 2
          end
        end
      end
    end
    if recipe.normal then
      for _, ingredient in pairs(recipe.normal.ingredients) do
        if ingredient.name == "matter" then
          ingredient.amount = ingredient.amount * 2
          if ingredient.catalyst_amount then
            ingredient.catalyst_amount = ingredient.catalyst_amount * 2
          end
        end
      end      
    end
    if recipe.expensive then
      for _, ingredient in pairs(recipe.expensive.ingredients) do
        if ingredient.name == "matter" then
          ingredient.amount = ingredient.amount * 2
          if ingredient.catalyst_amount then
            ingredient.catalyst_amount = ingredient.catalyst_amount * 2
          end
        end
      end
    end
  end
end
