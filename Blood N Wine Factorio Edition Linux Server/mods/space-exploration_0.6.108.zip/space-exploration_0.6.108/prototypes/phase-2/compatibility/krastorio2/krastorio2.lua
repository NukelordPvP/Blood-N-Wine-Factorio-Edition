local data_util = require("data_util")

if mods["Krastorio2"] then

  require("prototypes/phase-2/compatibility/krastorio2/categories")
  require("prototypes/phase-2/compatibility/krastorio2/equipment")
  require("prototypes/phase-2/compatibility/krastorio2/stack-sizes")
  require("prototypes/phase-2/compatibility/krastorio2/science-packs")
  require("prototypes/phase-2/compatibility/krastorio2/matter")
  require("prototypes/phase-2/compatibility/krastorio2/resources")
  require("prototypes/phase-2/compatibility/krastorio2/recipes")
  require("prototypes/phase-2/compatibility/krastorio2/resource-processing")
  require("prototypes/phase-2/compatibility/krastorio2/inserters")
  require("prototypes/phase-2/compatibility/krastorio2/technology")

  -- Bring Research Server closer to the Supercomputer 1
  data_util.remove_from_table(data.raw["assembling-machine"]["kr-research-server"].allowed_effects, "productivity")
  data.raw["assembling-machine"]["kr-research-server"].energy_source.emissions_per_minute = 4
  data.raw["assembling-machine"]["kr-research-server"].energy_usage = "1MW"
  data.raw["assembling-machine"]["kr-research-server"].se_allow_in_space = true
  data.raw["assembling-machine"]["kr-research-server"].collision_mask = {
    "water-tile",
    "ground-tile",
    "item-layer",
    "object-layer",
    "player-layer",
  }

  -- Bring Advanced Research Server closer to the Supercomputer 3
  data_util.remove_from_table(data.raw["assembling-machine"]["kr-quantum-computer"].allowed_effects, "productivity")
  data.raw["assembling-machine"]["kr-quantum-computer"].energy_usage = "6MW"
  data.raw["assembling-machine"]["kr-quantum-computer"].se_allow_in_space = true
  data.raw["assembling-machine"]["kr-quantum-computer"].collision_mask = {
    "water-tile",
    "ground-tile",
    "item-layer",
    "object-layer",
    "player-layer",
  }
  data.raw["assembling-machine"]["kr-matter-plant"].se_allow_in_space = true
  data.raw["assembling-machine"]["kr-matter-assembler"].se_allow_in_space = true
  data.raw.furnace["kr-stabilizer-charging-station"].se_allow_in_space = true

  if data.raw.beacon["kr-singularity-beacon"] then
    data.raw.beacon["kr-singularity-beacon"].se_allow_in_space = true
  end

  if data.raw["assembling-machine"]["kr-electrolysis-plant"] then
    data.raw["assembling-machine"]["kr-electrolysis-plant"].se_allow_in_space = true
  end

end
