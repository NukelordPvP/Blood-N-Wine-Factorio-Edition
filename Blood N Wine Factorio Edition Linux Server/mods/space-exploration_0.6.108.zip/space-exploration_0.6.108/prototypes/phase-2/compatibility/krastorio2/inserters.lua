local data_util = require("data_util")

-- This source is dedicated to integrating SE and K2's competing Inserter recipes.

-- Krastorio 2 overwrites these changes after this point and so they will be applied in space-exploration/prototypes/phase-3/compatibility/krastorio2/inserters
-- -- Burner Inserter 
-- if data.raw.recipe["burner-inserter"] then
--  -- 1 x Single Cylinder Engine
--  -- 1 x Inserter Parts
--  data_util.replace_or_add_ingredient("burner-inserter","iron-plate","motor",1)
-- end

-- -- Inserter
-- if data.raw.recipe["inserter"] then
--  -- 1 x Small Electric Motor
--  -- 1 x Burner Inserter
--  -- 1 x Automation Core
--  data_util.replace_or_add_ingredient("inserter","inserter-parts","burner-inserter",1)
--  data_util.replace_or_add_ingredient("inserter",nil,"electric-motor",1)
-- end

-- -- Long Handed Inserter
-- if data.raw.recipe["long-handed-inserter"] then
--  -- 2 x Iron Stick
--  -- 1 x Inserter
--  data_util.replace_or_add_ingredient("long-handed-inserter","inserter-parts","inserter",1)
--  data_util.remove_ingredient("long-handed-inserter","automation-core")
-- end

-- -- Fast Inserter
-- if data.raw.recipe["fast-inserter"] then
--  -- 2 x Electronic Circuit
--  -- 1 x Inserter
--  -- 1 x Steel Plate
--  data_util.replace_or_add_ingredient("fast-inserter","inserter-parts","inserter",1)
--  data_util.replace_or_add_ingredient("fast-inserter","electronic-circuit","electronic-circuit",2)
-- end

-- -- Filter Inserter
-- if data.raw.recipe["filter-inserter"] then
--  -- 2 x Electronic Circuit
--  -- 1 x Fast Inserter
--  -- 1 x Steel Plate
--  data_util.replace_or_add_ingredient("filter-inserter","inserter-parts","fast-inserter",1)
--  data_util.replace_or_add_ingredient("filter-inserter","electronic-circuit","electronic-circuit",2)
-- end

-- -- Stack Inserter
-- if data.raw.recipe["stack-inserter"] then
--  -- 2 x Advanced Circuit
--  -- 2 x Electronic Circuit
--  -- 4 x Inserter Parts
--  -- 1 x Fast Inserter
--  -- 2 x Steel Gear Wheel
--  data_util.replace_or_add_ingredient("stack-inserter","inserter-parts","inserter-parts",4)
--  data_util.replace_or_add_ingredient("stack-inserter","steel-plate","fast-inserter",1)
--  data_util.replace_or_add_ingredient("stack-inserter",nil,"electronic-circuit",2)
-- end

-- -- Stack Filter Inserter
-- if data.raw.recipe["stack-filter-inserter"] then
--  -- 2 x Advanced Circuits
--  -- 2 x Electronic Circuits
--  -- 1 x Stack Inserter
--  -- 2 x Steel Gear Wheel
--  data_util.replace_or_add_ingredient("stack-filter-inserter","inserter-parts","stack-inserter",1)
--  data_util.replace_or_add_ingredient("stack-filter-inserter","steel-plate","electronic-circuit",2)
--  data_util.replace_or_add_ingredient("stack-filter-inserter","advanced-circuit","advanced-circuit",2)
-- end

data.raw.technology["kr-superior-inserters"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-superior-inserters",{"advanced-tech-card"})
data_util.tech_remove_prerequisites("kr-superior-inserters",{"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-superior-inserters",{"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card","se-astronomic-science-pack-2","se-material-science-pack-2"})
data_util.tech_add_prerequisites("kr-superior-inserters",{"se-aeroframe-scaffold","se-heavy-bearing"})

-- Superior Inserter
if data.raw.recipe["kr-superior-inserter"] then
 -- 1 x Stack Inserter
 -- 1 x Processing Unit
 -- 1 x Imersium Plate
 -- 2 x Imersium Gear Wheel
 -- 2 x Heavy Bearing
 data_util.replace_or_add_ingredient("kr-superior-inserter","inserter-parts","stack-inserter",1)
 data_util.replace_or_add_ingredient("kr-superior-inserter","imersium-gear-wheel","imersium-gear-wheel",2)
 data_util.replace_or_add_ingredient("kr-superior-inserter",nil,"se-heavy-bearing",2)
end

-- Superior Long Inserter
if data.raw.recipe["kr-superior-long-inserter"] then
 -- 1 x Stack Inserter
 -- 1 x Processing Unit
 -- 1 x Imersium Plate
 -- 2 x Imersium Gear Wheel
 -- 1 x Heavy Bearing
 -- 1 x Aeroframe Scaffold
 data_util.replace_or_add_ingredient("kr-superior-long-inserter","inserter-parts","stack-inserter",1)
 data_util.replace_or_add_ingredient("kr-superior-long-inserter","imersium-gear-wheel","imersium-gear-wheel",2)
 data_util.replace_or_add_ingredient("kr-superior-long-inserter",nil,"se-heavy-bearing",1)
 data_util.replace_or_add_ingredient("kr-superior-long-inserter",nil,"se-aeroframe-scaffold",1)
end

-- Superior Filter Inserter
if data.raw.recipe["kr-superior-filter-inserter"] then
 -- 1 x Stack Inserter
 -- 2 x Processing Unit
 -- 1 x Imersium Plate
 -- 2 x Imersium Gear Wheel
 -- 2 x Heavy Bearing
 data_util.replace_or_add_ingredient("kr-superior-filter-inserter","inserter-parts","stack-inserter",1)
 data_util.replace_or_add_ingredient("kr-superior-filter-inserter","imersium-gear-wheel","imersium-gear-wheel",2)
 data_util.replace_or_add_ingredient("kr-superior-filter-inserter",nil,"se-heavy-bearing",2)
end

-- Superior Long Filter Inserter
if data.raw.recipe["kr-superior-long-filter-inserter"] then
 -- 1 x Stack Inserter
 -- 2 x Processing Unit
 -- 1 x Imersium Plate
 -- 2 x Imersium Gear Wheel
 -- 1 x Heavy Bearing
 -- 1 x Aeroframe Scaffold
 data_util.replace_or_add_ingredient("kr-superior-long-filter-inserter","inserter-parts","stack-inserter",1)
 data_util.replace_or_add_ingredient("kr-superior-long-filter-inserter","imersium-gear-wheel","imersium-gear-wheel",2)
 data_util.replace_or_add_ingredient("kr-superior-long-filter-inserter",nil,"se-heavy-bearing",1)
 data_util.replace_or_add_ingredient("kr-superior-long-filter-inserter",nil,"se-aeroframe-scaffold",1)
end