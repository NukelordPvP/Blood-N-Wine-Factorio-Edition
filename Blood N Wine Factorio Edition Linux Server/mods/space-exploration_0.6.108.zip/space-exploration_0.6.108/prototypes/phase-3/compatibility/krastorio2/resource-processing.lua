local data_util = require("data_util")

-- This source follows on from space-exploration/prototypes/phase-2/compatibility/krastorio2/resource-processing in making changes that cannot be made before this point.

-- This source is dedicated to maintaining compatability changes required for the K2 and SE resource processing steps.
-- E.G.
--  - Making sure K2 enrichment and SE molten metal casting are both available and the recipe amounts make sense as progressive levels of plate production efficiency
--  - Introducing changes to Iridium and Holomium to include the K2 Washing loop.

---- Copper Plates ----

-- SE
-- 1st Tier: 1 Copper Ore = 1 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 1.5 Copper Plate
--     24 Copper Ore processed with 10 Pyroflux to 900 Molten Copper
--     250 Molten Copper cast to 1 Copper Ingot
--     1 Copper Ingots processed to 10 Copper Plates

-- K2
-- 1st Tier: 1 Copper Ore = 0.5 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 0.667 Copper Plate
--     9 Copper Ore processed with 3 Sulfuric Acid to 6 Enriched Copper Ore
--     5 Enriched Copper Ore to 5 Copper Plates

-- SE-K2
-- 1st Tier: 1 Copper Ore = 0.75 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 1 Copper Plate
--     9 Copper Ore processed with 3 Sulfuric Acid to 9 Enriched Copper Ore
--     5 Enriched Copper Ore to 5 Copper Plates
-- 3rd Tier: 1 Copper Ore = 1.25 Copper Plate -- Less than SE efficiency due to additional productivity steps being possible
--     9 Copper Ore processed with 3 Sulfuric Acid to 9 Enriched Copper Ore
--     24 Enriched Copper Ore processed with 10 Pyroflux to 750 Molten Copper
--     250 Molten Copper cast to 1 Copper Ingot
--     1 Copper Ingot processed to 10 Copper Plates

-- Copper Ore smelting recipe
data_util.set_craft_time("copper-plate", 3.2*15)
data_util.replace_or_add_ingredient("copper-plate", "copper-ore", "copper-ore", 20)
data_util.replace_or_add_result("copper-plate", "copper-plate", "copper-plate", 15)

---- Iron Plates ----

-- SE
-- 1st Tier: 1 Iron Ore = 1 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 1.5 Iron Plate
--     24 Iron Ore processed with 10 Pyroflux to 900 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingots processed to 10 Iron Plates

-- K2
-- 1st Tier: 1 Iron Ore = 0.5 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 0.667 Iron Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 6 Enriched Iron Ore
--     5 Enriched Iron Ore to 5 Iron Plates

-- SE-K2
-- 1st Tier: 1 Iron Ore = 0.75 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 1 Iron Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     5 Enriched Iron Ore to 5 Iron Plates
-- 3rd Tier: 1 Iron Ore = 1.25 Iron Plate -- Less than SE efficiency due to additional productivity steps being possible
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates

-- Iron Ore smelting recipe
data_util.set_craft_time("iron-plate", 3.2*15)
data_util.replace_or_add_ingredient("iron-plate", "iron-ore", "iron-ore", 20)
data_util.replace_or_add_result("iron-plate", "iron-plate", "iron-plate", 15)

---- Steel Plates ----

-- SE
-- 1st Tier: 1 Iron Ore = 0.2 Steel Plate
--     1 Iron Ore smelted to 1 Iron Plate
--     5 Iron Plate smelted to 1 Steel Plate
-- 2nd Tier: 1 Iron Ore = 0.3 Steel Plate -- Possible unnecessary to consider given 3rd Tier is unlocked at the same time.
--     24 Iron Ore processed with 10 Pyroflux to 900 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates
--     5 Iron Plates smelted to 1 Steel Plate
-- 3rd Tier: 1 Iron Ore = 0.75 Steel Plate
--     24 Iron Ore processed with 10 Pyroflud to 900 Molten Iron
--     500 Molten Iron processed with 8 Coal into 1 Steel Ingot
--     1 Steel Ingot processed to 10 Steel Plate

-- K2
-- 1st Tier: 1 Iron Ore = 0.25 Steel Plate
--     10 Iron Ore Smelted to 5 Iron Plate
--     10 Iron Plate processed with 2 Coke to 5 Steel Plate
-- 2nd Tier: 1 Iron Ore = 0.33.. Steel Plate
--     9 Iron Ore Processed with 3 Sulfuric Acid to 6 Enriched Iron Ore
--     5 Enriched Iron Ore smelted to 5 Iron Plate
--     10 Iron Plate processed with 2 Coke to 5 Steel Plate

-- SE-K2
-- 1st Tier: 1 Iron Ore = 0.25 Steel Plate
--     20 Iron Ore smelted to 15 Iron Plates
--     15 Iron Plates processed with 3 Coke to 5 Steel Plates
-- 2nd Tier: 1 Iron Ore = 0.33.. Steel Plate?
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     5 Enriched Iron Ore smelted to 5 Iron Plate
--     15 Iron Plate processed with 3 Coke to 5 Steel Plate
-- 3rd Tier: 1 Iron Ore = 0.4166.. Steel Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates
--     15 Iron Plates processed with 3 Coke to 5 Steel Plates
-- 4th Tier: 1 Iron Ore = 0.625 Steel Plate -- Less than SE Efficiency due to additional Productivity steps being possible
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     500 Molten Iron processed with 6 Coke into 1 Steel Ingot
--     1 Steel Ingot processed into 10 Steel Plate

-- Steel Plate from Iron Plate
data_util.replace_or_add_ingredient("steel-plate","iron-plate","iron-plate",15)
data_util.replace_or_add_ingredient("steel-plate","coke","coke",3)

-- Steel Ingot to Steel Plate
-- Icon update due to K2 changing the Steel Plate icon drastically
data.raw.recipe["se-steel-ingot-to-plate"].icons = data_util.sub_icons(data.raw.item["steel-plate"].icon, data.raw.item[data_util.mod_prefix .. "steel-ingot"].icon)