local LandingpadGUI = {}

LandingpadGUI.name_rocket_landing_pad_gui_root = mod_prefix .. "rocket-landing-pad-gui"

function LandingpadGUI.gui_close(player)
  RelativeGUI.gui_close(player, LandingpadGUI.name_rocket_landing_pad_gui_root)
end

--- Create the landing pad gui for a player
---@param player LuaPlayer
---@param landing_pad RocketLandingPadInfo landing pad data
function LandingpadGUI.gui_open(player, landing_pad)
  LandingpadGUI.gui_close(player)
  if not landing_pad then Log.trace('LandingpadGUI.gui_open landing_pad not found') return end

  local gui = player.gui.relative
  local anchor = {gui=defines.relative_gui_type.container_gui, position=defines.relative_gui_position.left}
  local container = gui.add {
    type = "frame",
    name = LandingpadGUI.name_rocket_landing_pad_gui_root,
    style = "space_platform_container",
    direction = "vertical",
    anchor = anchor,
    -- use gui element tags to store a reference to what landing pad this gui is displaying/controls
    tags = {
      unit_number = landing_pad.unit_number
    }
  }

  local titlebar_flow = container.add{
    type="flow",
    direction="horizontal",
    style="se_relative_titlebar_flow"
  }

  titlebar_flow.add{  -- GUI label
    type="label",
    caption={"space-exploration.relative-window-settings"},
    style="frame_title"
  }

  local landingpad_gui_inner = container.add{ type="frame", name="landingpad_gui_inner", direction="vertical", style="b_inner_frame"}
  landingpad_gui_inner.style.padding = 10

  local name_flow = landingpad_gui_inner.add {
    type = "flow",
    name = "name-flow",
    direction = "vertical"
  }
  LandingpadGUI.make_change_name_button_flow(landing_pad, name_flow)

  landingpad_gui_inner.add {type = "label", name = "cargo_capacity", caption = {"space-exploration.label_cargo", ""}}
  local bar = landingpad_gui_inner.add {
    type = "progressbar",
    name = "cargo_capacity_progress",
    size = 300,
    value = 0,
    style = "space_platform_progressbar_cargo"
  }
  bar.style.horizontally_stretchable = true

  landingpad_gui_inner.add {type = "label", name = "status", caption = {"space-exploration.label_status", ""}}

  LandingpadGUI.gui_update(player)
end

function LandingpadGUI.gui_update(player)
  local root = player.gui.relative[LandingpadGUI.name_rocket_landing_pad_gui_root]
  if not (root and root.tags and root.tags.unit_number) then return end

  local struct = Landingpad.from_unit_number(root.tags.unit_number)
  if not (struct and struct.container and struct.container.valid) then return Landingpad.destroy(struct) end

  local inv = struct.container.get_inventory(defines.inventory.chest)
  local inv_used = count_inventory_slots_used(inv)

  local cargo_capacity_text = Util.find_first_descendant_by_name(root, "cargo_capacity")
  local cargo_capacity_progress = Util.find_first_descendant_by_name(root, "cargo_capacity_progress")
  local status_text = Util.find_first_descendant_by_name(root, "status")

  if cargo_capacity_text then
    cargo_capacity_text.caption = {"space-exploration.label_cargo", {"space-exploration.simple-a-b-divide", math.min(inv_used, #inv), #inv}}
  end
  if cargo_capacity_progress then
    cargo_capacity_progress.value = math.min(inv_used, #inv) / #inv
  end
  if status_text then
    local message = ""
    if inv_used > 0 then
      message = {"space-exploration.landingpad_unloading_required"}
    else
      message = {"space-exploration.landingpad_ready"}
    end
    if struct.inbound_rocket then 
      message = {"space-exploration.landingpad_rocket_inboud"}
    end
    status_text.caption = {"space-exploration.label_status", message}
  end
end

function LandingpadGUI.make_change_name_button_flow(struct, name_flow)
  name_flow.clear()
  local name_horizontal_flow = name_flow.add{type="flow",direction="horizontal"}
  local name_label = name_horizontal_flow.add {
    type = "label",
    name = "show-name",
    caption = struct.name,
    style = "space_platform_title_short"
  }
  local rename_button = name_horizontal_flow.add {
    type = "sprite-button",
    name = "rename",
    sprite = "utility/rename_icon_normal",
    tooltip = {
      "space-exploration.rename-something", {"entity-name." .. Landingpad.name_rocket_landing_pad}
    },
    style = "space_platform_sprite_button_medium"
  }
  local list, selected_index, values = Landingpad.dropdown_list_force_landing_pad_names(struct.force_name, struct.name)
   -- there is a default value at the start of the list, we don't want it here since landing pads always have a valid name
  table.remove(list, 1)
  table.remove(values, 1)
  local landingpads_dropdown = name_flow.add{ type="drop-down", name="change_name_dropdown", items=values, selected_index=selected_index-1}
end

function LandingpadGUI.make_change_name_confirm_flow(struct, name_flow)
  name_flow.clear()
  local name_horizontal_flow = name_flow.add{type="flow",direction="horizontal"}
  local name_label = name_horizontal_flow.add {
    type = "textfield",
    name = "write-name",
    text = struct.name,
    style = "space_platform_textfield_short",
    clear_and_focus_on_right_click = true
  }
  name_label.select_all()
  name_label.focus()
  local choose_button = name_horizontal_flow.add {
    type = "choose-elem-button",
    elem_type = "signal",
    signal = {
      type = "virtual",
      name = mod_prefix .. "select-icon"
    },
    name = "insert-icon",
    style = "space_platform_sprite_button_medium"
  }
  choose_button.style.padding = 0
  choose_button.style.top_margin = 1
  local rename_button = name_horizontal_flow.add {
    type = "sprite-button",
    name = "rename-confirm",
    sprite = "utility/enter",
    tooltip = {
      "space-exploration.rename-something", {"entity-name." .. Landingpad.name_rocket_landing_pad}
    },
    style = "item_and_count_select_confirm"
  }
end

function LandingpadGUI.gui_selection_state_changed(event)
  if not (event.element and event.element.valid and event.element.name == "change_name_dropdown") then return end
  local element = event.element
  local player = game.get_player(event.player_index)
  local root = player.gui.relative[LandingpadGUI.name_rocket_landing_pad_gui_root]
  if not (root and root.tags and root.tags.unit_number) then return end
  local struct = Landingpad.from_unit_number(root.tags.unit_number)
  if not (struct and struct.container and struct.container.valid) then return Landingpad.destroy(struct) end

  local name_text = struct.name
  local new_name_text = element.get_item(element.selected_index)
  if new_name_text ~= "" and new_name_text ~= name_text then
    --do change name stuff
    Landingpad.rename(struct, new_name_text)
  end

  -- gui rebuild
  LandingpadGUI.make_change_name_button_flow(struct, element.parent)
end
Event.addListener(defines.events.on_gui_selection_state_changed, LandingpadGUI.gui_selection_state_changed)

function LandingpadGUI.on_gui_elem_changed(event)
  if not (event.element and event.element.valid and event.element.name == "insert-icon") then return end
  local element = event.element
  local root = gui_element_or_parent(element,
                               LandingpadGUI.name_rocket_landing_pad_gui_root)
  if not root then return end
  local struct = Landingpad.from_unit_number(root and root.tags and root.tags.unit_number)
  if not struct then return end
  
  local name_label = element.parent["write-name"]
  if name_label then
    name_label.text = name_label.text .. Pin.signal_to_rich_text(element.elem_value)
    name_label.focus()
  end
  element.elem_value = {
    type = "virtual",
    name = mod_prefix .. "select-icon"
  }
end
Event.addListener(defines.events.on_gui_elem_changed, LandingpadGUI.on_gui_elem_changed)

function LandingpadGUI.on_gui_click(event)
  if not (event.element and event.element.valid) then return end
  local element = event.element
  local player = game.get_player(event.player_index)
  local root = player.gui.relative[LandingpadGUI.name_rocket_landing_pad_gui_root]
  if not (root and root.tags and root.tags.unit_number) then return end
  local struct = Landingpad.from_unit_number(root.tags.unit_number)
  if not (struct and struct.container and struct.container.valid) then return Landingpad.destroy(struct) end

  if element.name == "rename" then
    local name_flow = element.parent.parent
    LandingpadGUI.make_change_name_confirm_flow(struct, name_flow)
  elseif element.name == "rename-confirm" or (element.name == "write-name" and not event.button) then -- don't confirm by clicking the textbox
    local name_flow = element.parent.parent
    local new_name = string.trim(element.parent["write-name"].text)
    if new_name ~= "" and new_name ~= struct.name then
      -- do change name stuff
      Landingpad.rename(struct, new_name)
    end
    LandingpadGUI.make_change_name_button_flow(struct, name_flow)
  end
end
Event.addListener(defines.events.on_gui_click, LandingpadGUI.on_gui_click)
Event.addListener(defines.events.on_gui_confirmed, LandingpadGUI.on_gui_click)

function LandingpadGUI.on_tick(event)
  if event.tick % 60 == 0 then
    for _, player in pairs(game.connected_players) do
      LandingpadGUI.gui_update(player)
    end
  end
end
Event.addListener(defines.events.on_tick, LandingpadGUI.on_tick)

RelativeGUI.register_relative_gui(
  LandingpadGUI.name_rocket_landing_pad_gui_root,
  Landingpad.name_rocket_landing_pad,
  LandingpadGUI.gui_open,
  Landingpad.from_entity
)

return LandingpadGUI
