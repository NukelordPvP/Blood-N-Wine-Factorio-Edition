MLC = {

	Math=true,
	Timers=true,
	Misc=true,
	Entity=true,
	Debug=false

}

require "mologiccore.base" 

ModInterface,MoConfig = {},{}
require "config"

-------------- Data Saving/Setup -----------------

MoWeatherSaved = {Surfaces={}}

function LoadSurfaceConfig(surf,cfg)

	MoWeatherSaved.Surfaces[surf]=cfg
	local LT = MoWeatherSaved.Surfaces[surf]
	
	LT.ID = surf
	LT.Time = {Override=false,DayStart=0,DayTurn=0,DayEnd=0,Light=100,Name="Day"}
	LT.Weather = {Override=false,Name="Clear",CoolDown=0,Data={}}
	LT.Wind = {Override=false,Wind=0.02,Rate=0.018}
	LT.Data = {DayFroze=false,NoWeather=false,IgnoreLight=false,LightOver=false,WindOver=false,ModLight={Generic=0}}

end

for i,d in pairs(MoConfig.Surfaces) do

	LoadSurfaceConfig(i,d)

end

RegisterSaveTable("MoWeather",MoWeatherSaved,function(Dat) MoWeatherSaved=Dat end)

--------------------------------------------------

require "scripts.day-night"
require "scripts.wind"
require "scripts.weathers"

require "weather.weather" -- Contains The Data That Makes Up The Weather.
	
function MoManageWeather()

	for i,d in pairs(MoConfig.Surfaces) do

		local SurfaceData = MoWeatherSaved.Surfaces[i]
		DayNightCycle(SurfaceData) ManageWind(SurfaceData) ManageWeather(SurfaceData)
		
		local Wind,Sun = CalculateValues(SurfaceData)
		
		local Surface = game.surfaces[i]

		if not d.Data.WindOver then Surface.wind_speed = MoMath.Approach(Surface.wind_speed,Wind,0.001) end

		if not d.Data.LightOver then Surface.daytime = MoMath.Approach(Surface.daytime,Sun,(d.TimeSettings.DayLength/d.TimeSettings.TransitionMult)) end

	end
	
	return true

end

HookTick("MoWeatherManage",MoManageWeather)

function Intialize()

	for i,d in pairs(MoConfig.Surfaces) do

		if d.ManageTime == true then

			local Surface = game.surfaces[i]
			Surface.daytime=0.99
			--Surface:freeze_daytime(false) -- Fixes Saves That Are Broken.

		end

	end

end

HookInitialize(Intialize)

function CalculateValues(Dat)

	local W = Dat.Weather.Data
	
	--if Dat.Data.IgnoreLight then W = 0 end -- No Weather Lighting Wanted...
	
	local ModLighting = 0
	for i,d in pairs(Dat.Data.ModLight or {}) do

		ModLighting = ModLighting+d

	end
	
	local Wind = (Dat.Wind.Wind+W.W)/2
	local Sun = ((MoMath.Clamp((Dat.Time.Light-W.L)+ModLighting,0,100)/100)/2)+0.49
	return Wind,Sun

end


ModInterface.PrintLogs = function() PrintLogs() end
ModInterface.ScanDat = function() DebugLog("Scanned: "..CountTable(global.MoLogicCore,true),true) end
ModInterface.DumpDat = function() DumpGlobalDat() end
ModInterface.DumpTableLog = function() DumpTableLog() end

commands.add_command("dumpsettings","",function() game.write_file("MLCDump.txt", DumpScan(settings.runtime,0), false) end)

remote.add_interface("MoWeather", ModInterface)

--[[
script.on_event(defines.events.on_tick,

	function(event)

		local player = game.get_player(1)
		--player.print(game.surfaces)

		for name in pairs(game.surfaces) do

			player.print(name)

		end

	end

)
--]]
