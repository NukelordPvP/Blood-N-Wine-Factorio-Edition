GetTable=function()
	MoTimers=MoTimers or {}
	return MoTimers
end

local function Load(Dat) Timers = Dat end
Timers = RegisterSaveTable("MoTimers",{},Load) --Localise for speed.
if MLC.Debug then Debug.RegisterTable("Timers",Timers) end
local Functions = {}

--Caches a function so it doesnt error out while loading a save.
FuncRegister("CacheFunction",function(Name,Function)
	Functions["CB"..Name]=Function
end)

--Attempts to get the tick the games currently on
local function CheckTick()
	local CurTick = 0
	if game then 
		CurTick = game.tick
	else
		if MoLogicCore~=nil and MoLogicCore.Tick~=nil then
			CurTick = MoLogicCore.Tick
		end
	end
	return CurTick
end

--This creates a timer, which calls a function after a defined time.
FuncRegister("CreateTimer",function(Name,Length,Repeat,Over,CallBack,Data)
	local Tick = CheckTick()
	if Timers[Name]~=nil and Over then return end --If we are given the dont overwrite flag, dont continue.
	Timers[Name]={
		Name=Name, --Timer name/ID
		Repeat=Repeat, --How many times the timer repeats.
		Nxt=Tick+(Length*60), --When the timer is called again.
		Dur=Length, --Internal Value for timer length.
		Del=false, --Internal Value for trash management.
		CallBack="CB"..Name, --CallBack Function.
		Data=Data --Extra Data to pass onto the callback.
	}
	Functions["CB"..Name]=CallBack
	DebugLog("Created Timer "..Name,false)
end)

--Deletes a timer before it finishs and calls its function.
FuncRegister("DeleteTimer",function(Name)
	DebugLog("Deleting Timer... "..Name,false)
	Timers[Name]=nil
end)

--Returns how much time is left in a timer.
FuncRegister("TimerTimeLeft",function(Name) 
	if Timers[Name] ~= nil then
		local Return = (Timers[Name].Nxt-game.tick)/60
		--if Return > 0 then
			return Return
		--end
	end
	return 0
end)

--Returns all active timers.
FuncRegister("GetTimers",function() return Timers end)

function RunTimerModule()--The function that powers the timers.
	for i,d in pairs(Timers) do
		if game.tick >= d.Nxt then --Do we run this timer?
			if d.Repeat > 1 or d.Repeat == 0 then
				if d.Repeat>1 then d.Repeat = d.Repeat-1 end
				d.Nxt = game.tick+(d.Dur*60)--It keeps going... and going.
			else
				d.Del=true--Set the timer to be deleted.
			end
			if Functions["CB"..d.Name] ==nil then
				d.Del = true
				DebugLog("Warning: "..d.Name.." doesnt have a function!",true)
			else
				Functions["CB"..d.Name](d.Data) --Call The function we were told to.
			end
		end
		if d.Del == true then
			MoTimers.DeleteTimer(d.Name)
		end
	end
	MoLogicCore.Tick = game.tick + 1
	--DebugLog("Timering.... "..CountTable(Timers,false),true)
	
	return true
end
HookInitLoad(function() 
	HookTick("MoTimer",RunTimerModule)
	DebugLog("TimerModule Started!: "..CountTable(Timers),false)
end)








