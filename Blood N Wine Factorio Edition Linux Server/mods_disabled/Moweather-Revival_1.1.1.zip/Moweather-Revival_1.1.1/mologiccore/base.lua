--[[--------------------------------------------------------------------
___  ___      _                 _      _____                
|  \/  |     | |               (_)    /  __ \               
| .  . | ___ | |     ___   __ _ _  ___| /  \/ ___  _ __ ___ 
| |\/| |/ _ \| |    / _ \ / _` | |/ __| |    / _ \| '__/ _ \
| |  | | (_) | |___| (_) | (_| | | (__| \__/\ (_) | | |  __/
\_|  |_/\___/\_____/\___/ \__, |_|\___|\____/\___/|_|  \___|
                           __/ |                            
                          |___/                             
------------------------------------------------------------------------
MoLogicCore was developed by Ludsoe, you may use and modify the code in
MoLogicCore to your hearts content. Please provide info below if you 
modify and redistribute this folder and its contents.
------------------------------------------------------------------------ 
This Version of MoLogicCore is: 
Version: 3.5 UnModdified
Author: Ludsoe
ExtraInfo: None
--]]--------------------------------------------------------------------

local MLCDataVers = 3.5
local LastCompatable = 1.38

MoLogicCore = {Vers = MLCDataVers,Tick = 0} --Save related Stuff
local LoadData = {}
function RegisterSaveTable(Name,Table,func)
	if MoLogicCore[Name] == nil then MoLogicCore[Name] = Table end
	LoadData[Name]=func
	return MoLogicCore[Name]
end

function RestoreData()
	for i,d in pairs(LoadData) do
		d(MoLogicCore[i])
		DebugLog("Restored Data: "..tostring(i),false)
	end
end

require 'util'
require 'logging' --Got tired of not being able to debug startup functions properly.
require 'eventmanage'

--This automatically sorts all the functions into their respective tables.
function FuncRegister(Name,Function)
	local Table=GetTable()
	Table[Name]=Function
end
function GetTable() end

function TableCopy(Table)
	local NewTable = {}
	for i,d in pairs(Table) do
		local T = type(d)
		if T=="table" then
			NewTable[i]=TableCopy(d)
		else
			NewTable[i]=d
		end
	end
	return NewTable
end

function CountTable(Table,Depth)
	local Counted = 0
	if type(Table)~="table" then error("Table is not Table!: "..tostring(Table)) end
	for i,d in pairs(Table) do
		if type(d) == "table" and Depth == true then
			Counted=Counted+CountTable(Table[i],Depth) 
		end
		Counted = Counted + 1
	end 
	return Counted
end

if MLC ~= nil then
	PostInit = {} --Create a table to store post lua load functions.
	
	if MLC.Debug then
		require "scripts.debug"
	end
	if MLC.Math then
		require "scripts.math"
	end
	if MLC.Timers then
		require "scripts.timer"
	end
	if MLC.Misc then
		require "scripts.misc"
	end
	if MLC.Entity then
		require "scripts.entity"
	end
	
	for i,d in pairs(PostInit) do d() end PostInit = nil
end