----MoLogicCore EventManager Module
--We handle all the event based hooks here.

Subscribed = {Built={},Death={},PlyCreated={},PlyDeath={},Removed={}}
if MLC.Debug then Debug.RegisterTable("Subscribed",Subscribed) end

local EventFuncs = {}
EventFuncs["Built"] = function(event)
	local ent = event.created_entity
	if ent == nil or not ent.valid then return end -- nil entity don't run it.
	
	--DebugLog("Build Caught: "..tostring(ent.name),false)
	
	local Name = ent.name
	if Subscribed.Built[Name] then
		for i,d in pairs(Subscribed.Built[Name]) do
			d.Func(ent)
		end
	end	
end

EventFuncs["PlyBuilt"] = function(event)
	local index = event.player_index
	local ent = game.players[index]
	if ent == nil or not ent.valid then return end -- nil player don't run it.
	
	for i,d in pairs(Subscribed.PlyCreated) do
		d.Func(index,ent)
	end
end

EventFuncs["Death"] = function(event)
	local ent = event.entity
	if ent == nil or not ent.valid then return end -- nil entity don't run it.
	
	local Name = ent.name
	if Subscribed.Death[Name] then
		for i,d in pairs(Subscribed.Death[Name]) do
			d.Func(ent)
		end
	end	
end

EventFuncs["PlyDeath"] = function(event)
	local ent,index
	for i,v in ipairs(game.players) do
		if v.connected then
			if event.entity == v.character or not v.character then
				ent = v
				index = i
			end
		end
	end

	if ent == nil or not ent.valid then return end -- nil entity don't run it.
	
	for i,d in pairs(Subscribed.PlyDeath) do
		d.Func(index,ent,event.entity)
	end
end

EventFuncs["Removed"] = function(event)
	local ent = event.entity
	if ent == nil or not ent.valid then return end -- nil entity don't run it.
	
	local Name = ent.name
	if Subscribed.Removed[Name] then
		for i,d in pairs(Subscribed.Removed[Name]) do
			d.Func(ent)
		end
	end	
end

local EventTypes = {}
EventTypes[defines.events.on_built_entity] = {"Built"}
EventTypes[defines.events.on_robot_built_entity] = {"Built"}
EventTypes[defines.events.on_player_created] = {"PlyBuilt"}
EventTypes[defines.events.on_entity_died] = {"PlyDeath","Death","Removed"}
EventTypes[defines.events.on_pre_player_mined_item] = {"Removed"}
EventTypes[defines.events.on_robot_pre_mined] = {"Removed"}

--This does all the hard work.
local function EventHandler(event)
	local Event = event.name
	for i,d in pairs(EventTypes[Event]) do
		EventFuncs[d](event)
	end
end

script.on_event(defines.events.on_built_entity, EventHandler)
script.on_event(defines.events.on_robot_built_entity, EventHandler)
script.on_event(defines.events.on_entity_died, EventHandler)
script.on_event(defines.events.on_player_created, EventHandler)
script.on_event(defines.events.on_pre_player_mined_item, EventHandler)
script.on_event(defines.events.on_robot_pre_mined, EventHandler)

local TickHooks = {}

function OnTickManage()
	for i,d in pairs(TickHooks) do
		if d()~= true then--Check if the hook wants to stay
			TickHooks[i]=nil--remove the hook
		end
	end
end

function HookTick(Name,func)
	TickHooks[Name]=func
end

script.on_event(defines.events.on_tick,OnTickManage) 

local InitCached = {}
local LoadCached = {}

function MLCInit()
	global.MoLogicCore = MoLogicCore
	
	for I=1,#InitCached do InitCached[I]() end	
	
	DebugLog("Initalized!",false)
end

function MLCLoad()
	MoLogicCore = global.MoLogicCore
	
	RestoreData() --Since restoring the table doesnt setup the data directly.
	
	for I=1,#LoadCached do LoadCached[I]() end	
	
	DebugLog("Loaded Data! "..global.MoLogicCore.Vers,false)
end

function HookInitialize(func) InitCached[#InitCached+1]=func end
function HookLoad(func) LoadCached[#LoadCached+1]=func end
function HookInitLoad(func) HookInitialize(func) HookLoad(func) end --Saves time

script.on_init(MLCInit)
script.on_load(MLCLoad)
