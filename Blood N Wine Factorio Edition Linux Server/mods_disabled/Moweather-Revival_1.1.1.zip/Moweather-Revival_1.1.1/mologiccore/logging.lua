----MoLogicCore Logging Module
--This module is designed to catch debug messages and log them down to make debugging certain parts of MLC easier.
--It is also meant to displace the now defunc debug module.

local Logged = {}
if MLC.PersistLog == true then
	Logged = RegisterSaveTable("Logging",{})
end

local function Print(Text)
	for i,d in pairs(game.players) do
		if d and d.valid then
			d.print(""..Text)
		end
	end
end

function DebugLog(Log,Display)
	if type(Log)~="string" then Log = tostring(Log) end --Make sure all logs are defined as strings. (If needed implement better system to setup strings.)
	local Time = 0 if game then Time = Round(game.tick/60,2) end
	Logged[#Logged+1] = {Time=Time,Log=Log}

	if Display==true and game then
		Print(Log)
	end
end

function Round(N1,N2)
    local mult = 10^(N2 or 0)
    if N1 >= 0 then return math.floor(N1 * mult + 0.5) / mult
    else return math.ceil(N1 * mult - 0.5) / mult end
end

function DumpLogs()
	local Dump = ""
	for I=1,#Logged do
		local Log = Logged[I]		
		Dump=Dump.."\n".."["..Log.Time.."]: "..Log.Log
	end	
	
	game.write_file("MLCLogs.txt", Dump, false)
end

function AddTabs(Num)
	local TabChar = "	"
	if Num>0 then 
		local Return = ""
		for I=1,Num do
			Return = Return..TabChar
		end
		return Return
	else
		return ""
	end
end

function DumpScan(Table,Depth)
	local Dump = ""
	if type(Table)~="table" then error("Table is not Table!: "..tostring(Table)) end
	for i,d in pairs(Table) do
		if type(d) == "table" then
			Dump=Dump.."\n"..AddTabs(Depth).."Table: "..tostring(i) 
			Dump=Dump..DumpScan(Table[i],Depth+1) 
		else
			Dump=Dump.."\n"..AddTabs(Depth)..tostring(i).." : "..tostring(d).." : "..type(d)
		end
	end 
	return Dump
end

function DumpGlobalDat()
	game.write_file("MLCDump.txt", DumpScan(global.MoLogicCore,0), false)
end

local TableLog=""
function LogTableData(Table) TableLog=DumpScan(Table,0) end
function DumpTableLog() game.write_file("MLCDump.txt", TableLog, false) end

function PrintLogs()
	if game == nil then return end --Cant print now.
	
	Print("Printing Logs....")
	Print("-----------------------------")
	
	for I=1,#Logged do
		local Log = Logged[I]		
		Print("["..Log.Time.."]: "..Log.Log)
	end
	
	Print("- - - - - - - - - - - - - - - -")
	Print("Logs Finished!")
end