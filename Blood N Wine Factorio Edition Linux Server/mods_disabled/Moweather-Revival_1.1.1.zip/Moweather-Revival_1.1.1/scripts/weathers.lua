WeatherFuncs = {}
WeatherTables = {}
WeatherChain = {}

function CreateWeather(Name,EndFunc,StartFunc,ThinkFunk,NextWeather,locale,WindSpeed,LightDimper,DurHigh,DurLow,CoolDown,Chance)
	WeatherTables[Name]={

		Name=Name,
		EF=EndFunc,
		SF=StartFunc,
		TF=ThinkFunk,
		NT=NextWeather,
		locale=locale,
		W=WindSpeed,
		L=LightDimper,
		DH=DurHigh,
		DL=DurLow,
		C=CoolDown,
		R=Chance

	}	

end

function WeatherChainConstruct(name,data)

	WeatherChain[name] = data

end

function AnnounceWeather(Weather)

	for i,d in pairs(game.players) do

		if d and d.valid then

			local Setting = settings.get_player_settings(d)["weatherannounce"].value

			if Setting == true then

				d.print({"weatherannounce."..string.lower(Weather)})

			end

		end

	end

end

function SetWeather(dat,Weather)

	if Weather == nil then

		return -- Error Call To Set The Weather, Didnt Provide A New Weather To Set To.

	end
	
	local W = dat.Weather

	if W.Name ~= Weather.Name then

		if W.Data.EF then WeatherFuncs[W.Data.EF]() end

		W.Name = Weather.Name
		W.Data = Weather
		WeatherFuncs[W.Data.SF]()
		AnnounceWeather(Weather.Name)

	end
	
	W.Data = Weather
	W.WeatherEnd = game.tick+((math.random(Weather.DL,Weather.DH)*60)*settings.global["weatherlength"].value)
	DebugLog("Weather Set to : "..Weather.Name,false)

end

function PickWeather(dat)

	if dat.Data.NoWeather or dat.ManageWeather == false then

		SetWeather(dat,WeatherTables["Clear"])
		return

	end
		
	-- Obtain The Preset That Was Selected In The Settings.
	local Chain = WeatherChain[settings.global["presetconfig"].value]
	local Probabilities = Chain[(dat.Weather.Name) or "Clear"] -- We Take Into Account Our Current Weather When Picking A New One.
	
	local Percents = {}
	local Total = 0

	for i,d in pairs(Probabilities) do -- First Pass Generates The Chain Of Probabilities.

		Percents[i]={Total,Total+d} Total=Total+d

	end
	
	-- Actually Spin The Wheel And Pick Our Weather.
	local Draw = math.random(1,Total)
	
	for i,d in pairs(Percents) do -- Second Pass Detirmine What We Spun.

		if Draw > d[1] and Draw < d[2] then

			SetWeather(dat,WeatherTables[i]) -- Set The Weather Accordingly.
			return

		end

	end
	
	--SetWeather(dat,WeatherTables[dat.Weather.Data.NT] or WeatherTables["Clear"])

end

function ManageWeather(dat)

	local WeatherDat = dat.Weather

	if game.tick>=(WeatherDat.WeatherEnd or 0) or (dat.Data.NoWeather and not WeatherDat.Name~= "Clear") then

		PickWeather(dat)

	else

		if WeatherFuncs[WeatherDat.Data.TF] then

			WeatherFuncs[WeatherDat.Data.TF](dat)

		end

	end

end

ModInterface.weathertimeleft = function(surf)

	if surf == nil then surf = 1 end

	local SurfDat = MoConfig.Surfaces[surf]
	return (SurfDat.Weather.WeatherEnd-game.tick) or 0

end

ModInterface.forceweather = function(surf,Want)

	if surf == nil then surf = 1 end

	local Surface = MoConfig.Surfaces[surf]

	if not Surface or Surface == nil then return false end

	if Surface.ManageWeather == true then

		if WeatherTables[Want] ~= nil then

			SetWeather(Surface,WeatherTables[Want])
			return true

		end

	end

	return false	

end