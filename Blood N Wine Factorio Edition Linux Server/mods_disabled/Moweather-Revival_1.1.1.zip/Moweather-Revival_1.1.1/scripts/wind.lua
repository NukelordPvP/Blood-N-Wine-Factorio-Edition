function HeadWinds(dat)

	local W = dat.Wind

	if dat.Time.Name == "Day" then

		W.Rate=0.024

	else

		W.Rate=0.018

	end

end

-- Handles The Random Wind Fluxs.
function ManageWind(dat)

	local W = dat.Wind
	HeadWinds(dat)
	
	if math.random(1,20)>10 then X=0.001 else X=-0.001 end

	W.Wind = MoMath.Clamp(math.abs(W.Rate+(math.random(1,20)*X)),W.Rate-0.1,W.Rate+0.1)

end