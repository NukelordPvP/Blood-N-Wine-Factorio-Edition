local Scopes = {"startup", "runtime-global", "runtime-per-user"}

function CompileSetting(Name, Value, Scope, Data)

	Data.name = Name
	Data.default_value = Value
	Data.setting_type = Scopes[Scope]
	data:extend({Data})

end

function AddBool(Name,Scope,Value,Order)

	local Table = {type="bool-setting",order=""}
	
	if Order~=nil then Table.order = Order end
	
	Table.localised_name = {"modsettings_name."..string.lower(Name)}
	Table.localised_description = {"modsettings_desc."..string.lower(Name)}
	
	CompileSetting(Name,Value,Scope,Table)

end

function AddInt(Name,Scope,Values,Order)

	local Table = {type="int-setting",order=""}
	
	if Order~=nil then Table.order = Order end
	
	Table.localised_name = {"modsettings_name."..string.lower(Name)}
	Table.localised_description = {"modsettings_desc."..string.lower(Name)}
	
	local Value = Values[1] 
	Table.minimum_value = Values[2]
	Table.maximum_value = Values[3]
	Table.allowed_values = Values[4]
	
	CompileSetting(Name,Value,Scope,Table)

end

function AddDouble(Name,Scope,Values,Order)

	local Table = {type="double-setting",order=""}
	
	if Order~=nil then Table.order = Order end
	
	Table.localised_name = {"modsettings_name."..string.lower(Name)}
	Table.localised_description = {"modsettings_desc."..string.lower(Name)}
	
	local Value = Values[1] 
	Table.minimum_value = Values[2]
	Table.maximum_value = Values[3]
	Table.allowed_values = Values[4]
	
	CompileSetting(Name,Value,Scope,Table)

end

function AddString(Name,Scope,Values,Order)

	local Table = {type="string-setting",order=""}
	
	if Order~=nil then Table.order = Order end
	
	Table.localised_name = {"modsettings_name."..string.lower(Name)}
	Table.localised_description = {"modsettings_desc."..string.lower(Name)}
	
	local Value = Values[1] Table.allowed_values = Values
	CompileSetting(Name,Value,Scope,Table)

end

-- Startup.
--settings.startup[<SettingName>].value

-- Runtime Global.
--settings.global[<SettingName>].value

-- Runtime PerPlayer.
--settings.get_player_settings(<LuaPlayer>)[<SettingName>].value

-- Time Configs.
AddInt("daylength",2,{7,1},"a")
AddInt("nightper",2,{50,1,100},"ab")

-- Weather Configs.
AddString("presetconfig",2,{"Default","None","RainWorld"},"b")
AddBool("weatherannounce",3,false,"ba") --This is clientside.
AddDouble("weatherlength",2,{1,0.1},"bb")

--AddBool("customsets",2,false,"bc")

-- Gonna Allow Players To Setup A Custom Weather Table, To Control The Probabilties Themselves.
local WeatherTypes = {"Clear","Cloudy","Windy","ThunderStorm","RainStorm"}