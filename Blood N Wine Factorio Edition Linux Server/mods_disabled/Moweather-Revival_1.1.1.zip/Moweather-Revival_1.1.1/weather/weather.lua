-- Rain Code.
local WeatherSave = {RainAnimation={}}
RegisterSaveTable("WeatherData",WeatherSave)

-- All Objects Capable Of Making Metalic Rain Dinging Noises.
LargeMetalObjects = {"furnace", "boiler", "container", "electric-pole", "generator", "offshore-pump", "pipe", "radar", "pipe-to-ground", "assembling-machine", "mining-drill", "turret", "ammo-turret", "car", "solar-panel", "locomotive", "cargo-wagon", "fluid-wagon", "artillery-wagon", "lab", "logistic-container", "rocket-silo", "roboport", "storage-tank", "pump", "accumulator", "beacon", "reactor", "artillery-turret", "electric-turret", "fluid-turret"}

function CleanupStrayBits()

	for i,d in pairs(WeatherSave.RainAnimation) do

		if not d.B or not d.B.valid then

			if d.A and d.A.valid then

				d.A.destroy()
				d.B.destroy()

                if not WeatherSave.RainAnimation[i].C == nil then

                    WeatherSave.RainAnimation[i].C.destroy()
                    WeatherSave.RainAnimation[i].D.destroy()

                end

			end

			WeatherSave.RainAnimation[i] = nil

		end

	end

end

function HandleRainSound(dat)

	MoEntity.loopplayers(function(i,d)

		local Surface = d.surface
        local MetalObjects = game.surfaces[dat.ID].find_entities_filtered{position = MoEntity.getplayerpos(i), radius = 5, type = LargeMetalObjects}

		if not WeatherSave.RainAnimation[i] or not WeatherSave.RainAnimation[i].A or not WeatherSave.RainAnimation[i].A.valid then

			if Surface == game.surfaces[dat.ID] then

				local Rain = Surface.create_entity{name = "rain-loop-v2",position=MoEntity.getplayerpos(i)}
				Rain.energy = 5*MoMath.GetMJ()
				local RainB = Surface.create_entity{name = "rain-power-pole",position=MoEntity.getplayerpos(i)}

                WeatherSave.RainAnimation[i] = {A=Rain,B=RainB}

			end

		else

			if Surface == game.surfaces[dat.ID] then

				WeatherSave.RainAnimation[i].A.teleport(MoEntity.getplayerpos(i))
				WeatherSave.RainAnimation[i].B.teleport(MoEntity.getplayerpos(i))

			else

				WeatherSave.RainAnimation[i].A.destroy()
				WeatherSave.RainAnimation[i].B.destroy()

                if WeatherSave.RainAnimation[i].C ~= nil then

                    WeatherSave.RainAnimation[i].C.destroy()
                    WeatherSave.RainAnimation[i].D.destroy()

                end

			end

		end

        if  WeatherSave.RainAnimation[i] and not WeatherSave.RainAnimation[i].C then

            if  MetalObjects[#MetalObjects] then

                local RainMetal = Surface.create_entity{name = "rain-on-metal",position=MetalObjects[#MetalObjects].position}
                        RainMetal.energy = 5*MoMath.GetMJ()
                local RainMetalB = Surface.create_entity{name = "rain-power-pole",position=MetalObjects[#MetalObjects].position}
                WeatherSave.RainAnimation[i].C = RainMetal
                WeatherSave.RainAnimation[i].D = RainMetalB

            end

        elseif WeatherSave.RainAnimation[i] and WeatherSave.RainAnimation[i].C and WeatherSave.RainAnimation[i].C.valid then

            if MetalObjects[1] then

                WeatherSave.RainAnimation[i].C.teleport(MetalObjects[#MetalObjects].position)
                WeatherSave.RainAnimation[i].D.teleport(MetalObjects[#MetalObjects].position)

            end

        end

	end)

	CleanupStrayBits()

end

local RainRenderDist = MoConfig.RainRenderDist

function WeatherFuncs.RainThink(dat)

	HandleRainSound(dat)

	if (dat.Weather.Data.NextRDrops or 0)<=game.tick then

		dat.Weather.Data.NextRDrops = game.tick+(0.4*60)
		local Rains = {}
		local CellSize,CellDist = RainRenderDist,6
		
		MoEntity.loopplayers(function(i,d)

			local Surface = d.surface

			if Surface == game.surfaces[dat.ID] then -- Only Animate Rain For Players On The Rainy Surface.

				-- Localise The Players Position To Weather Grid.
				local PPos = game.players[(i or 1)].position
				local PPGrid = {x=MoMath.Round(PPos.x/CellDist)*CellDist,y=MoMath.Round(PPos.y/CellDist)*CellDist}

				for X=1, CellSize do

					for Y=1, CellSize do

						local RainPos = {x=PPGrid.x+((X-(CellSize/2))*CellDist),y=PPGrid.y+((Y-(CellSize/2))*CellDist)}
						local Key = tostring(dat.ID)..tostring(RainPos.x)..tostring(RainPos.y)

						if not Rains[Key] then -- This Is So Players Close To Each Other Don't Overlap Rain Effects.

							Rains[Key] = true
							Surface.create_entity{name = "rain-drops", position=RainPos}

						end

					end

				end

			end

		end)

		Rains = nil -- Empty The Table As We Don't Need It Anymore.

	end

end

function WeatherFuncs.RainStart() end

function WeatherFuncs.RainEnd()

	for i,d in pairs(WeatherSave.RainAnimation) do

		if d.A ~= nil then

            local RainSounds = game.surfaces[1].find_entities_filtered{name = "rain-loop-v2"}

            for t,y in pairs(RainSounds) do

                y.destroy()

            end

			local RainPowerPoles = game.surfaces[1].find_entities_filtered{name = "rain-power-pole"}

            for u,o in pairs(RainPowerPoles) do

                o.destroy()

            end

            local RainOnMetalObjects = game.surfaces[1].find_entities_filtered{name = "rain-on-metal"}

            for e,q in pairs(RainOnMetalObjects) do

                q.destroy()

            end

            local ElectricPoles = game.surfaces[1].find_entities_filtered{name = "rain-power-pole"}

            for r,w in pairs(ElectricPoles) do

                w.destroy()

            end

		end

		WeatherSave.RainAnimation[i] = nil

	end

end

-- ThunderStorm Code.
function WeatherFuncs.StormThink(dat)

	WeatherFuncs.RainThink(dat)
	local DataTable = dat.Weather.Data

	if game.tick>=(DataTable.StormThink or 0) then

		DataTable.StormThink = game.tick+(10*60)

		if(math.random(1,30)<4)then	

			MoEntity.loopplayers(function(i,d)

				if d.surface == game.surfaces[dat.ID] then

					MoMisc.PlaySound("thunder-roll",MoEntity.getplayerpos(i),d.surface)

				end

			end)
			
			if not dat.Data.IgnoreLight then

				DataTable.LightningReset = game.surfaces[dat.ID].daytime
				DataTable.LightningFlash = true
				DataTable.LightningEnd = game.tick+(0.2*60)
				game.surfaces[dat.ID].daytime = 0.99	

			end

		end

	end
	
	if DataTable.LightningFlash == true then

		if game.tick>=DataTable.LightningEnd then

			DataTable.LightningFlash = false
			game.surfaces[dat.ID].daytime = DataTable.LightningReset

		end

	end

end

-- Empty Function Thats Empty.
function WeatherFuncs.EmptyFunc() end
local EF = "EmptyFunc"

-- The Base Settings For Each Weather Type.
CreateWeather("Clear",EF,EF,EF,"Clear","clear",0,0,31,30,0,50)
CreateWeather("Cloudy",EF,EF,EF,"Clear","cloudy",0.010,60,400,150,240,5)
CreateWeather("Windy",EF,EF,EF,"Clear","windy",0.053,10,300,250,180,3)
CreateWeather("ThunderStorm","RainEnd","RainStart","StormThink","Clear","thunder",0.043,80,300,250,300,3)
CreateWeather("RainStorm","RainEnd","RainStart","RainThink","Clear","rain",0.043,60,300,250,300,3)

-- No Weather Here, Just A Recurring Clear State!
WeatherChainConstruct("None",{Clear = {Clear=10}})

--[[
Note: The Chance Format Is A Ratio.
Example: Clear = {Clear=70,Cloudy=10,Windy=10,ThunderStorm=0,RainStorm=5}
Means: 7:1:1:0:0.5
Ratio To Percentage: M:N M/(M+N)*100
Percentage Chance: %73.68, %10.53, %10.53, %0, %5.26
--]]

-- The ""Default"" Settings
WeatherChainConstruct("Default",{
	Clear = {Clear=70,Cloudy=10,Windy=10,ThunderStorm=0,RainStorm=5},
	Cloudy = {Clear=30,Cloudy=20,Windy=10,Thunderstorm=5,RainStorm=30},
	Windy = {Clear=40,Cloudy=10,Windy=20,Thunderstorm=5,RainStorm=20},
	RainStorm = {Clear=20,Cloudy=25,Windy=10,Thunderstorm=20,RainStorm=30},
	ThunderStorm = {Clear=5,Cloudy=20,Windy=5,Thunderstorm=30,RainStorm=20},
})

WeatherChainConstruct("RainWorld",{
	Clear = {Clear=50,Cloudy=5,Windy=5,ThunderStorm=20,RainStorm=20},
	Cloudy = {Clear=5,Cloudy=20,Windy=5,Thunderstorm=20,RainStorm=30},
	Windy = {Clear=5,Cloudy=30,Windy=5,Thunderstorm=30,RainStorm=30},
	RainStorm = {Clear=5,Cloudy=20,Windy=5,Thunderstorm=40,RainStorm=60},
	ThunderStorm = {Clear=5,Cloudy=10,Windy=5,Thunderstorm=50,RainStorm=20},
})

--WeatherChainConstruct("None",{})

--[[
script.on_event(defines.events.on_player_changed_surface,

	function(event)

		local player = game.get_player(1)
		CleanupStrayBits()
		player.print("Changed Surface")

	end
)
--]]
