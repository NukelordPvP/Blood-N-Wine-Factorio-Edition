local M = MoConfig

M.Surfaces 	= {}
local S 	= M.Surfaces

-----------------------------Surface Define----------------------------------
--Define How Moweather Should Treat Each Surface.

--The Starter Surface (Nauvis).
S[1] = {

	ManageTime 		= false,
	TimeSettings = {

		DayLength		= settings.global["daylength"].value, -- 7
		DayNightRatio	= settings.global["nightper"].value, -- 50
		TransitionMult 	= 6000 -- No Settings Variant Of This Yet.

	},
	
	ManageWeather 	= true,
	WeatherSettings = {}

}

local WeatherPreset 	= settings.global["presetconfig"].value

if WeatherPreset == "None" then

	S[1].ManageWeather 	= false

end

-----------------------------Global Settings---------------------------------

-----------------------------Weather Systems---------------------------------

--[[
The Amount Of "Tiles" Rain Renders From Players.
Higher Numbers Increase CPU Time (Standard 12).
*Aka Might Cause Lag.*
--]]
M.RainRenderDist = 24