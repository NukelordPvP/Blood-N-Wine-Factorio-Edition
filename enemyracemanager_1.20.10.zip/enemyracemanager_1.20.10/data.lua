require "prototypes.extend-collision"
require "prototypes.extend-types"

require "prototypes.extend-bitters"
require "prototypes.extend-spawners"

require "prototypes.base-units.defender"
require "prototypes.base-units.destroyer"
require "prototypes.base-units.distractor"
require "prototypes.base-units.construction"
require "prototypes.base-units.logistic"

require "prototypes.base-spawner.roboport"

if settings.startup['enemyracemanager-enable-bitters'].value then
    -- This set of data is used for set up default autoplace calculation.
    data.erm_registered_race = data.erm_registered_race or {}
    data.erm_registered_race[MOD_NAME] = true
    data.erm_spawn_specs = data.erm_spawn_specs or {}
    table.insert(data.erm_spawn_specs, {
        mod_name = MOD_NAME,
        force_name = FORCE_NAME,
        moisture = 2, -- 1 = Dry and 2 = Wet
        aux = 1, -- 1 = red desert, 2 = sand
        elevation = 1, --1,2,3 (1 low elevation, 2. medium, 3 high elavation)
        temperature = 2, --1,2,3 (1 cold, 2. normal, 3 hot)
    })

    require('prototypes/compatibility/BobsEnemies/spawn_spec')
    require('prototypes/compatibility/NaturalEvolutionEnemies/spawn_spec')
end