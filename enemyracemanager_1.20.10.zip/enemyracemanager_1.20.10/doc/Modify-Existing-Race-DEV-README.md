## Modifying exist race guideline

This doc provide basic guideline on modify the existing race's data and adding new functionality.

### Change attack parameters.

### Introducing new attacks

### Changing Spawn Table

### Changing reciepe data




