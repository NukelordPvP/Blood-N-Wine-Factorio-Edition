
data:extend{{
    type = 'custom-input',
    name = "ss-spidertron-dock-toggle",
    key_sequence = "R",
    enabled_while_spectating = true,
    order = "a-e",
}}