data:extend({

	{
	    type = "bool-setting",
	    name = "cb-disable-worms",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-a[trigger]",
	    per_user = false
	},

	{
	    type = "bool-setting",
	    name = "cb-disable-cluster-spit",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-b[trigger]",
	    per_user = false
	},
	{
	
	    type = "bool-setting",
	    name = "cb-disable-mother",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-c[trigger]",
	    per_user = false
	},	
	
	{
	
	    type = "bool-setting",
	    name = "cb-disable-temperature-check",
	    setting_type = "startup",
	    default_value = false,
	    order = "c[modifier]-d[trigger]",
	    per_user = false
	},	
	
	{
	    type = "bool-setting",
	    name = "cb-enable-cold-warfare",
	    setting_type = "startup",
	    default_value = true,
	    order = "c[modifier]-e[trigger]",
	    per_user = false
	},	


	{
	    type = "double-setting",
	    name = "cb-HealthScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "p[modifier]-a[unit]",
	    per_user = false
	},

	{
	    type = "double-setting",
	    name = "cb-DamageScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "p[modifier]-a[unit]",
	    per_user = false
	},

	
	
})
