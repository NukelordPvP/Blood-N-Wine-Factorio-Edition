if settings.startup["cb-enable-cold-warfare"].value then

ICONPATH = "__Cold_biters__/graphics/icon/"
TECHPATH = "__Cold_biters__/graphics/technology/"
CAPSULEPATH = "__Cold_biters__/graphics/entity/cold_capsule/"

data:extend({

-- ITEMS
 {
    type = "item",
    name = "cb_alien_cold_gland",
    icon = ICONPATH .. "alien_cold_gland.png",
	  icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-material",
    order = "a-l-a",
    stack_size = 50,
  },



 {
    type = "item",
    name = "cb_alien_cold_artifact",
    icon = ICONPATH .. "alien_cold_artifact.png",
	  icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-material",
    order = "a-l-b",
    stack_size = 50,
  },


-- weapon


    {
        type = "gun",
        name = "cold-jetthrower-rifle",
        icon = ICONPATH .. "cold_rifle.png",
        icon_size = 64, icon_mipmaps = 4,
        flags = {"hidden"},
        subgroup = "gun",
        order = "e-c",
        attack_parameters =
        {
          type = "stream",
          ammo_category = "coldjet-ammo",
          cooldown = 1,
          movement_slow_down_factor = 0.6,
          projectile_creation_distance = 0.2,
          gun_barrel_length = 0.1,
          gun_center_shift = { 0, -0.8 },
          range = 15,
          min_range = 1,
          cyclic_sound =
          {
            begin_sound =
            {
              {
                filename = "__base__/sound/fight/flamethrower-start.ogg",
                volume = 0.7
              }
            },
            middle_sound =
            {
              {
                filename = "__base__/sound/fight/flamethrower-mid.ogg",
                volume = 0.7
              }
            },
            end_sound =
            {
              {
                filename = "__base__/sound/fight/flamethrower-end.ogg",
                volume = 0.7
              }
            }
          }
        },
        stack_size = 1
    },



-- ammo
  {
    type = "ammo-category",
    name = "coldjet-ammo"
  },

  
-- capsule

 {
    type = "capsule",
    name = "cold-capsule",
    icon = ICONPATH .. "cold_capsule.png",
    icon_size = 64, icon_mipmaps = 4,
    capsule_action =
    {
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 30,
        projectile_creation_distance = 0.6,
        range = 25,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "cold-capsule",
              starting_speed = 0.3
            }
          }
        }
      }
    },
    subgroup = "capsule",
    order = "b[poison-capsule]",
    stack_size = 100
   },



  {
    type = "projectile",
    name = "cold-capsule",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "create-entity",
          show_in_tooltip = true,
          entity_name = "cold-cloud-2"
        }
      }
    },
    light = {intensity = 0.5, size = 4},
    animation =
    {
      filename = CAPSULEPATH .. "cold-capsule.png",
      draw_as_glow = true,
      frame_count = 16,
      line_length = 8,
      animation_speed = 0.250,
      width = 29,
      height = 29,
      shift = util.by_pixel(1, 0.5),
      priority = "high",
      hr_version =
      {
        filename = CAPSULEPATH .. "hr-cold-capsule.png",
        draw_as_glow = true,
        frame_count = 16,
        line_length = 8,
        animation_speed = 0.250,
        width = 58,
        height = 59,
        shift = util.by_pixel(1, 0.5),
        priority = "high",
        scale = 0.5
      }

    },
    shadow =
    {
      filename = CAPSULEPATH .. "cold-capsule-shadow.png",
      frame_count = 16,
      line_length = 8,
      animation_speed = 0.250,
      width = 27,
      height = 21,
      shift = util.by_pixel(1, 2),
      priority = "high",
      draw_as_shadow = true,
      hr_version =
      {
        filename = CAPSULEPATH .. "hr-cold-capsule-shadow.png",
        frame_count = 16,
        line_length = 8,
        animation_speed = 0.250,
        width = 54,
        height = 42,
        shift = util.by_pixel(1, 2),
        priority = "high",
        draw_as_shadow = true,
        scale = 0.5
      }
    },



    smoke = capsule_smoke
  },



-- FLUID
  {
    type = "fluid",
    name = "cb_alien_cold_extract",
    icon = ICONPATH .. "alien_cold_fluid.png",
    icon_size = 64, icon_mipmaps = 4,
    default_temperature = -1,
    max_temperature = 2,
    heat_capacity = "0.1KJ",
    base_color = {r=0, g=0.10, b=0.8},
    flow_color = {r=0.9, g=0.9, b=0.9},
    order = "a[fluid]-a[alien]"
  },


-- ARMORS

  {
    type = "armor",
    name = "cb-modular-armor",
    icon = ICONPATH .. "cb-modular-armor.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "cold",
        decrease = 0,
        percent = 40
      },	
      {
        type = "physical",
        decrease = 6,
        percent = 30
      },
      {
        type = "acid",
        decrease = 0,
        percent = 50
      },
      {
        type = "explosion",
        percent = -35
      },
      {
        type = "fire",
        percent = -50
      }
    },
    subgroup = "armor",
    order = "c[modular-armor]-b",
    stack_size = 1,
    infinite = true,
    equipment_grid = "small-equipment-grid",
    inventory_size_bonus = 10
  },
  {
    type = "armor",
    name = "cb-power-armor",
    icon = ICONPATH .. "cb-power-armor.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {     
	  {
        type = "cold",
        decrease = 0,
        percent = 60
      },	
      {
        type = "physical",
        decrease = 8,
        percent = 30
      },
      {
        type = "acid",
        decrease = 0,
        percent = 60
      },
      {
        type = "explosion",
        percent = -40
      },
      {
        type = "fire",
        decrease = 0,
        percent = -60
      }
    },
    subgroup = "armor",
    order = "d[power-armor]-b",
    stack_size = 1,
    infinite = true,
    equipment_grid = "medium-equipment-grid",
    inventory_size_bonus = 20
  },
  {
    type = "armor",
    name = "cb-power-armor-mk2",
    icon = ICONPATH .. "cb-power-armor-mk2.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
	  {
        type = "cold",
        decrease = 0,
        percent = 70
      },	
      {
        type = "physical",
        decrease = 10,
        percent = 40
      },
      {
        type = "acid",
        decrease = 0,
        percent = 70
      },
      {
        type = "explosion",
        percent = -50
      },
      {
        type = "fire",
        decrease = 0,
        percent = -70
      }
    },
    subgroup = "armor",
    order = "e[power-armor-mk2]-b",
    stack_size = 1,
    infinite = true,
    equipment_grid = "large-equipment-grid",
    inventory_size_bonus = 30
  },




-- RECIPES
  {
    type = "recipe",
    name = "cb-clean-gland",
    category = "chemistry",
    energy_required = 25,
    enabled = false,
    ingredients =
    {
      {type="item",  name="cb_alien_cold_gland",  amount=1},
      {type="fluid", name="sulfuric-acid", amount=10},
	  {type="fluid", name="water", amount=500},
    },
    results=
    {
	  {type="fluid", name="water", amount=300},
	  {type="item",  name="cb_alien_cold_artifact", amount=1},
    },
	main_product= "cb_alien_cold_artifact",
    subgroup = "fluid-recipes",
	always_show_made_in = true,
    crafting_machine_tint =
    {
      primary = {r = 0.875, g = 0.735, b = 0.000, a = 0.000}, -- #dfbb0000
      secondary = {r = 0.103, g = 0.940, b = 0.000, a = 0.000}, -- #1aef0000
      tertiary = {r = 0.564, g = 0.795, b = 0.000, a = 0.000}, -- #8fca0000
    }
  },



  {
    type = "recipe",
    name = "cb-cold-extract",
    category = "chemistry",
    energy_required = 30,
    enabled = false,
    ingredients =
    {
      {type="item",  name="cb_alien_cold_artifact",  amount=1},
      {type="fluid", name="petroleum-gas", amount=30},
	  {type="fluid", name="lubricant", amount=20},
    },
    results=
    {
	  {type="fluid", name="cb_alien_cold_extract", amount=50},
    },
	main_product= "cb_alien_cold_extract",
    subgroup = "fluid-recipes",
	always_show_made_in = true,
    crafting_machine_tint =
    {
      primary = {r = 0.875, g = 0.735, b = 0.000, a = 0.000}, -- #dfbb0000
      secondary = {r = 0.103, g = 0.940, b = 0.000, a = 0.000}, -- #1aef0000
      tertiary = {r = 0.564, g = 0.795, b = 0.000, a = 0.000}, -- #8fca0000
    }
  },


  {
    type = "recipe",
    name = "cb-coldjet-ammo",
    category = "chemistry",
    enabled = false,
    energy_required = 6,
    ingredients =
    {
      {type="item", name="steel-plate", amount=3},
      {type="fluid", name="cb_alien_cold_extract", amount=10},
    },
    result = "cb-coldjet-ammo",
    crafting_machine_tint =
    {
      primary = {r = 0, g = 0.533, b = 0.800, a = 0.000}, -- #d7870000
      secondary = {r = 0, g = 0.000, b = 0.600, a = 0.4}, -- #a7000000
      tertiary = {r = 1, g = 1, b = 1, a = 0.5}, -- #ae530000
    }
  },


  {
    type = "recipe",
    name = "cb-modular-armor",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {"modular-armor", 1},
      {"cb_alien_cold_artifact", 2}
    },
    result = "cb-modular-armor",
	requester_paste_multiplier = 1
  },
  {
    type = "recipe",
    name = "cb-power-armor",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"power-armor", 1},
      {"cb_alien_cold_artifact", 4}
    },
    result = "cb-power-armor",
    requester_paste_multiplier = 1
  },
  {
    type = "recipe",
    name = "cb-power-armor-mk2",
    enabled = false,
    energy_required = 25,
    ingredients =
    {
      {"power-armor-mk2", 1},
      {"cb_alien_cold_artifact", 6}
    },
    result = "cb-power-armor-mk2",
    requester_paste_multiplier = 1
  },
  {
    type = "recipe",
    name = "cold-capsule",
	category = "crafting-with-fluid",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {type="item", name="grenade", amount=3},
      {type="fluid", name="cb_alien_cold_extract", amount=5},
    },
    result = "cold-capsule"
  },


  
   {
    type = "recipe",
    name = "cold-jetthrower-rifle",
    enabled = false,
    energy_required = 30,
    ingredients =
    {
      {"steel-plate", 10},
	  {"plastic-bar", 10},
      {"speed-module", 5},
      {"cb_alien_cold_artifact", 5},
	  {"battery", 10}
    },
    result = "cold-jetthrower-rifle"
  },


-- TECHS

  {
    type = "technology",
    name = "cb-cold-alien-tech",
    icon_size = 256, icon_mipmaps = 4,
    icon = TECHPATH .. "cold_alien_tech.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "cb-clean-gland"
      },
      {
        type = "unlock-recipe",
        recipe = "cb-cold-extract"
      },	  
    },
    prerequisites = {"chemical-science-pack"},
    unit =
    {
      count = 50,
      ingredients = {{"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}},
      time = 30
    },
    order = "c-d"
  },



  {
    type = "technology",
    name = "cb-cold-alien-warfare",
    icon_size = 256, icon_mipmaps = 4,
    icon = TECHPATH .. "cold_alien_warfare.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "cb-coldjet-ammo"
      },
      {
        type = "unlock-recipe",
        recipe = "cold-capsule"
      },	
      {
        type = "unlock-recipe",
        recipe = "cold-jetthrower-rifle"
      },
    },
    prerequisites = {"cb-cold-alien-tech"},{"military-3"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 2},
        --{"utility-science-pack", 1}
      },
      time = 30
    },
    order = "e-d"
  },



  {
    type = "technology",
    name = "cb-modular-armor",
    icon_size = 256, icon_mipmaps = 4,
    icon = TECHPATH .. "cb-modular-armor.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "cb-modular-armor"
      }
    },
    prerequisites = {"modular-armor", "cb-cold-alien-tech"},
    unit =
    {
      count = 100,
      ingredients = {{"automation-science-pack", 1}, {"logistic-science-pack", 1},{"chemical-science-pack", 1}},
      time = 30
    },
    order = "g-a-d"
  },
  {
    type = "technology",
    name = "cb-power-armor",
    icon_size = 256,
    icon = TECHPATH .. "cb-power-armor.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "cb-power-armor"
      }
    },
    prerequisites = {"power-armor",  "cb-cold-alien-tech"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "g-c-b"
  },
  {
    type = "technology",
    name = "cb-power-armor-mk2",
    icon_size = 256, icon_mipmaps = 4,
    icon = TECHPATH .. "cb-power-armor-mk2.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "cb-power-armor-mk2"
      }
    },
    prerequisites = {"power-armor-mk2", "cb-cold-alien-tech"},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30
    },
    order = "g-c-c"
  },





  {
    type = "technology",
    name = "cb-coldjet-ammo-damage-1",
    icons = {
      {icon = TECHPATH .. "cold_damage_tech.png", icon_size = 256, icon_mipmaps = 4},
      {icon = "__core__/graphics/icons/technology/constants/constant-damage.png", icon_size = 128, icon_mipmaps = 2, shift = {100, 100}},
    },
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "coldjet-ammo",
        modifier = 0.2,
        icons = {
          {icon = ICONPATH .. "coldjet_ammo.png", icon_size = 64, icon_mipmaps = 4,},
          {icon = "__core__/graphics/icons/technology/effect-constant/effect-constant-damage.png", icon_size = 64, icon_mipmaps = 1,},
        }
      }
    },
    prerequisites = {"cb-cold-alien-warfare","military-4"},
    unit =
    {
      count = 400,
      ingredients =
      {
	    {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
		{"chemical-science-pack", 1},
		{"utility-science-pack", 1},
        {"military-science-pack", 2},
      },
      time = 30
    },
    upgrade = true,
    order = "e-n-a"
  },

  {
    type = "technology",
    name = "cb-coldjet-ammo-damage-2",
    icons = {
      {icon = TECHPATH .. "cold_damage_tech.png", icon_size = 256, icon_mipmaps = 4},
      {icon = "__core__/graphics/icons/technology/constants/constant-damage.png", icon_size = 128, icon_mipmaps = 2, shift = {100, 100}},
    },
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "coldjet-ammo",
        modifier = 0.2,
        icons = {
          {icon = ICONPATH .. "coldjet_ammo.png", icon_size = 64, icon_mipmaps = 4},
          {icon = "__core__/graphics/icons/technology/effect-constant/effect-constant-damage.png", icon_size = 64, icon_mipmaps = 1},
        }
      }
    },
    prerequisites = {"cb-coldjet-ammo-damage-1","rocket-silo"},
    unit =
    {
      count = 700,
      ingredients =
      {
	    {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
		{"chemical-science-pack", 1},
		{"utility-science-pack", 1},
        {"military-science-pack", 2},
		{"space-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "p-n-a"
  },



})




local coldjet = table.deepcopy(data.raw.ammo["flamethrower-ammo"])
coldjet.name = "cb-coldjet-ammo"
coldjet.icon = ICONPATH .. "coldjet_ammo.png"
coldjet.icon_size = 64
coldjet.icon_mipmaps = 4
coldjet.ammo_type = {
  consumption_modifier = 1.125,
  category = "coldjet-ammo",
  target_type = "position",
  clamp_position = true,
  action =
  {
    type = "direct",
    action_delivery =
    {
      type = "stream",
      stream = "cb-jetthrower-cold-stream",
      max_length = 9,
      duration = 160,
    }
  }
}
data:extend({coldjet})


local LOW_LOOT_PROBABILITY = 0.33
local MEDIUM_LOOT_PROBABILITY = 0.66
local HIGH_LOOT_PROBABILITY = 0.9
local Low_Loot = { item = "cb_alien_cold_gland", probability = LOW_LOOT_PROBABILITY, count_min = 1, count_max = 2}
local Medium_Loot = { item = "cb_alien_cold_gland", probability = MEDIUM_LOOT_PROBABILITY, count_min = 1, count_max = 5 }
local Mother_Loot = { item = "cb_alien_cold_gland", probability = HIGH_LOOT_PROBABILITY, count_min = 5, count_max = 10 }


table.insert(data.raw["unit-spawner"]["cb-cold-spawner"].loot, Medium_Loot)
if data.raw["turret"]["big-cold-worm-turret"] then table.insert(data.raw["turret"]["big-cold-worm-turret"].loot,Low_Loot) end
if data.raw["turret"]["behemoth-cold-worm-turret"] then table.insert(data.raw["turret"]["behemoth-cold-worm-turret"].loot,Medium_Loot) end
if data.raw["turret"]["leviathan-cold-worm-turret"] then table.insert(data.raw["turret"]["leviathan-cold-worm-turret"].loot,Medium_Loot) end
if data.raw["turret"]["mother-cold-worm-turret"] then table.insert(data.raw["turret"]["mother-cold-worm-turret"].loot,Mother_Loot) end
if data.raw["unit"]["mother-cold-spitter"] then table.insert(data.raw["unit"]["mother-cold-spitter"].loot,Mother_Loot) end
end
