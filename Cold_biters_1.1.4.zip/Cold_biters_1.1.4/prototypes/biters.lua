require ("prototypes.values")
local sounds = require("__base__/prototypes/entity/sounds.lua")
COLDENTITY = "__Cold_biters__/graphics/entity/cold_spawner/"


local cb_enemy_autoplace
local autoplace_vanilla = enemy_autoplace
local autoplace_temperature = require ("prototypes.enemy-autoplace")
if settings.startup["cb-disable-temperature-check"].value then
cb_enemy_autoplace = autoplace_vanilla
else
cb_enemy_autoplace = autoplace_temperature
end



local small_biter_scale = 0.5
local medium_biter_scale = 0.7
local big_biter_scale = 1.0
local behemoth_biter_scale = 1.2
local leviathan_scale=2.5

local biter_tint1 = {r=0, g=0.1, b=0.9, a=1}
local biter_tint2 = {r=1, g=1, b=1, a=0.9}

local HEALTH_S = settings.startup["cb-HealthScaler"].value
local DAMAGE_S = settings.startup["cb-DamageScaler"].value


local function make_biter_area_damage(damage,radius)
return  {
					type = "area",
					radius = radius,
					force = "enemy",
					ignore_collision_condition = true,
					action_delivery =
					{
					  type = "instant",
					  target_effects =
					  {
						{
						  type = "damage",
						  damage = {amount = damage, type = "physical"}
						},
						{
						type = "create-particle",
						repeat_count = 5,
						particle_name = "explosion-remnants-particle",
						initial_height = 0.5,
						speed_from_center = 0.08,
						speed_from_center_deviation = 0.15,
						initial_vertical_speed = 0.08,
						initial_vertical_speed_deviation = 0.15,
						offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
						},
					  }
					}
      }
end



function cold_spawner_integration()
return
  {
    filename = COLDENTITY .. "cold-spawner-idle-integration.png",
    variation_count = 4,
    width = 258,
    height = 188,
    shift = util.by_pixel(2, -2),
    frame_count = 1,
    line_length = 1,
    hr_version =
    {
      filename = COLDENTITY .. "hr-cold-spawner-idle-integration.png",
      variation_count = 4,
      width = 522,
      height = 380,
      shift = util.by_pixel(3, -3),
      frame_count = 1,
      line_length = 1,
      scale = 0.5
    }
  }
end





data:extend(
{

 {
    type = "unit",
    name = "small-cold-biter",
    icon = "__base__/graphics/icons/big-biter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 15*HEALTH_S,
    order = "b-fb-a",
    subgroup="enemies",
    resistances =cold_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.7}, {0.7, 0.4}},
    attack_parameters =
    {
      type = "projectile",
      range = 0.5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(8*DAMAGE_S),
      sound = sounds.biter_roars(0.4),
      animation = biterattackanimation(small_biter_scale, biter_tint1, biter_tint2),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.2,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 4,
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    corpse = "small-cold-biter-corpse",
    dying_explosion = "cb-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['small-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['small-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['small-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(small_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['small-biter'].damaged_trigger_effect),

    run_animation = biterrunanimation(small_biter_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },

  
  add_biter_die_animation(small_biter_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "small-cold-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-fb[biter]-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
	dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
  }),
	  
  
  
  {
    type = "unit",
    name = "medium-cold-biter",
    icon = "__base__/graphics/icons/big-biter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 75*HEALTH_S,
    order="b-fb-b",
    subgroup="enemies",
    resistances =cold_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(16*DAMAGE_S),
      range = 1,
      cooldown = 35,
      sound = sounds.biter_roars(0.5),
      animation = biterattackanimation(medium_biter_scale, biter_tint1, biter_tint2),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.185,
    distance_per_frame = 0.15,
    -- in pu
    pollution_to_join_attack = 20,
    corpse = "medium-cold-biter-corpse",
    dying_explosion = "cb-medium-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['medium-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['medium-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['medium-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(medium_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['medium-biter'].damaged_trigger_effect),

    run_animation = biterrunanimation(medium_biter_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings,
  },

  {
    type = "unit",
    name = "big-cold-biter",
    order="b-fb-c",
    icon = "__base__/graphics/icons/big-biter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 375*HEALTH_S,
    subgroup="enemies",
    resistances =cold_resists,
    spawning_time_modifier = 3,
    healing_per_tick = 0.02,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.6, -0.8}, {0.6, 0}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      range = 1.5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(30*DAMAGE_S),
      sound =  sounds.biter_roars(0.6),
      animation = biterattackanimation(big_biter_scale, biter_tint1, biter_tint2),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 80,
    corpse = "big-cold-biter-corpse",
    dying_explosion = "cb-big-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['big-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['big-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['big-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(big_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['big-biter'].damaged_trigger_effect),
    run_animation = biterrunanimation(big_biter_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings,
  },

  {
    type = "unit",
    name = "behemoth-cold-biter",
    order="b-fb-d",
    icon = "__base__/graphics/icons/big-biter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 3000*HEALTH_S,
    subgroup="enemies",
    resistances =cold_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.6, -0.8}, {0.6, 0}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
                {
                    type = "projectile",
                    range = 1.6,
                    cooldown = 50,
                    sound =  sounds.biter_roars_behemoth(0.8),
                    animation = biterattackanimation(behemoth_biter_scale, biter_tint1, biter_tint2),
					range_mode = "bounding-box-to-bounding-box",
					ammo_type = {
							  category = "melee",
							  target_type = "entity",
								action = {
								  {
								  action_delivery = {
									target_effects = {
									  damage = {
										amount = (100*DAMAGE_S),
										type = "physical"
									  },
									  type = "damage",
									  show_in_tooltip = true
									},
									type = "instant"
								  },
								  type = "direct"
								  },
								  make_biter_area_damage(50*DAMAGE_S,1),
								  },
							}		
                },		
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 400,
    corpse = "behemoth-cold-biter-corpse",
    dying_explosion = "cb-big-artillery-cold-explosion",
    working_sound = sounds.biter_calls_big(1.0),
    dying_sound = sounds.biter_dying_big(0.7),
    walking_sound = sounds.biter_walk_big(0.8),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(behemoth_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
    run_animation = biterrunanimation(behemoth_biter_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings,
  },
 
  add_biter_die_animation(medium_biter_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "medium-cold-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-fb[biter]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
  }),  
  
  add_biter_die_animation(big_biter_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "big-cold-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-fb[biter]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
  }),  
  
  
  add_biter_die_animation(behemoth_biter_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "behemoth-cold-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-fb[biter]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
  }),  
  
   {
    type = "unit",
    name = "leviathan-cold-biter",
    order="b-fb-g",
    icon ="__base__/graphics/icons/big-biter.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 80000*HEALTH_S,
    subgroup="enemies",
    resistances = cold_leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.2, -2.4}, {1.2, 0.9}},
    sticker_box = {{-1.2, -2}, {1.2, 0}},
    distraction_cooldown = 300,
    loot =
    {
    },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      range = 1,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = 
      {
        category = "melee",
        target_type = "entity",
        action =
        {
		   make_biter_area_damage(100*DAMAGE_S,3),
          {
		  type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              {
                type = "damage",
                damage = { amount = 130 * DAMAGE_S, type = "physical"}
              },
              {
                type = "damage",
                damage = { amount = 70* DAMAGE_S , type = "cold"}
              }
            }
          }}
        }
      },
      sound =  sounds.biter_roars(0.9),
      animation = biterattackanimation(leviathan_scale, biter_tint1, biter_tint2),
	  range_mode = "bounding-box-to-bounding-box"
    },	

    vision_distance = 50,
    movement_speed = 0.2,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 1000,
    corpse = "explosive-leviathan-biter-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    working_sound = sounds.biter_calls_big(1.4),
    dying_sound = sounds.biter_dying_big(1),
    walking_sound = sounds.biter_walk_big(1.2),
	running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
	water_reflection = biter_water_reflection(leviathan_scale),	
    run_animation = biterrunanimation(leviathan_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings,
  },

  
  add_biter_die_animation(leviathan_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "explosive-leviathan-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-fb[biter]-g[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
  }),  
    
 
 
 
  
  --------------
  --- NEST
 
  {
    type = "unit-spawner",
    name = "cb-cold-spawner",
    icon = "__base__/graphics/icons/biter-spawner.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "not-repairable"},
    max_health = 800*HEALTH_S,
    order="b-fb-s",
    subgroup="enemies",
    resistances = cold_resists,
    working_sound = {
      sound =
      {
        {
          filename = "__base__/sound/creatures/spawner.ogg",
          volume = 1.0
        }
      },
      apparent_volume = 2
    },
    dying_sound =
    {
      {
        filename = "__base__/sound/creatures/spawner-death-1.ogg",
        volume = 1.0
      },
      {
        filename = "__base__/sound/creatures/spawner-death-2.ogg",
        volume = 1.0
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-3.2, -2.2}, {2.2, 2.2}},
    map_generator_bounding_box = {{-4.2, -3.2}, {3.2, 3.2}},
    selection_box = {{-3.5, -2.5}, {2.5, 2.5}},
    -- in ticks per 1 pu
    pollution_absorption_absolute = 20,
    pollution_absorption_proportional = 0.01,	
    corpse = "cb-cold-spawner-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    max_count_of_owned_units = 10,
    max_friends_around_to_spawn = 7,
    animations =
    {
      spawner_idle_animation(0, biter_tint1),
      spawner_idle_animation(1, biter_tint1),
      spawner_idle_animation(2, biter_tint1),
      spawner_idle_animation(3, biter_tint1)
    },
    integration = cold_spawner_integration(),
    result_units = (function()
                     local res = {}
                     res[1] = {"small-cold-biter", {{0.0, 0.3}, {0.6, 0.0}}}
					 res[2] = {"medium-cold-biter", {{0.2, 0.0}, {0.6, 0.3}, {0.7, 0.1}}}
                     res[3] = {"small-cold-spitter", {{0.25, 0.0}, {0.5, 0.3}, {0.7, 0.0}}}
					 res[4] = {"medium-cold-spitter", {{0.4, 0.0}, {0.7, 0.3}, {0.9, 0.1}}}
                     res[5] = {"big-cold-biter", {{0.5, 0.0}, {1.0, 0.4}}}
					 res[6] = {"big-cold-spitter", {{0.5, 0.0}, {1.0, 0.4}}}
                     res[7] = {"behemoth-cold-biter", {{0.9, 0.0}, {1.0, 0.3}}}
					 res[8] = {"behemoth-cold-spitter", {{0.9, 0.0}, {1.0, 0.3}}}
					 res[9] = {"leviathan-cold-biter", {{0.965, 0.0}, {1.0, 0.03}}}
					 res[10]= {"leviathan-cold-spitter", {{0.965, 0.0}, {1.0, 0.03}}}
					 if not settings.startup["cb-disable-mother"].value then
						res[11]= {"mother-cold-spitter", {{0.98, 0.0}, {1.0, 0.02}}} end
                    return res
                   end)(),
    -- With zero evolution the spawn rate is 6 seconds, with max evolution it is 2.5 seconds
    spawning_cooldown = {360, 150},
    spawning_radius = 10,
    spawning_spacing = 3,
    max_spawn_shift = 0,
    max_richness_for_spawn_shift = 100,
    autoplace = cb_enemy_autoplace.enemy_spawner_autoplace(0),
    call_for_help_radius = 50,
    loot = {},	
  },

  {
    type = "corpse",
    name = "cb-cold-spawner-corpse",
    flags = {"placeable-neutral", "placeable-off-grid", "not-on-map"},
    icon = "__base__/graphics/icons/biter-spawner-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    collision_box = {{-2, -2}, {2, 2}},
    selection_box = {{-2, -2}, {2, 2}},
    selectable_in_game = false,
    dying_speed = 0.04,
    time_before_removed = 15 * 60 * 60,
    subgroup="corpses",
    order = "c[corpse]-fb[spawner]-s",
    final_render_layer = "remnants",
    animation =
    {
      spawner_die_animation(0, biter_tint1),
      spawner_die_animation(1, biter_tint1),
      spawner_die_animation(2, biter_tint1),
      spawner_die_animation(3, biter_tint1)
    },
    ground_patch =
    {
      sheet = cold_spawner_integration()
    }	
  },
 
  
 
  
	}
)