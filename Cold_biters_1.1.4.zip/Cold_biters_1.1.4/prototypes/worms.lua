require ("prototypes.values")
local sounds = require("__base__/prototypes/entity/sounds.lua")
local hit_effects = require ("__base__/prototypes/entity/hit-effects")

local cb_enemy_autoplace
local autoplace_vanilla = enemy_autoplace
local autoplace_temperature = require ("prototypes.enemy-autoplace")
if settings.startup["cb-disable-temperature-check"].value then
cb_enemy_autoplace = autoplace_vanilla
else
cb_enemy_autoplace = autoplace_temperature
end


if not settings.startup["cb-disable-worms"].value then

local biter_tint1 = {r=0, g=0.1, b=0.9, a=1}
local leviathan_scale=2.5

local HEALTH_S = settings.startup["cb-HealthScaler"].value
local DAMAGE_S = settings.startup["cb-DamageScaler"].value

local stream_cluster_small = "cb-cluster-cold-projectile-small-t"
local stream_cluster_big = "cb-cluster-cold-projectile-big-t"

if settings.startup["cb-disable-cluster-spit"].value then
	stream_cluster_small = "cb-cold-stream-small-t"
	stream_cluster_big = "cb-cold-stream-big-t"
	end


data:extend(
{

  {
    type = "turret",
    name = "small-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    order="b-ft-a",
    max_health = 200 *HEALTH_S,
    subgroup="enemies",
    resistances = cold_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.9, -0.8 }, {0.9, 0.8}},
    map_generator_bounding_box = {{-1.9, -1.8}, {1.9, 1.8}},
    selection_box = {{-0.9, -0.8 }, {0.9, 0.8}},
    damaged_trigger_effect = hit_effects.biter(),
    shooting_cursor_size = 3,
    corpse = "small-cold-worm-corpse",
    dying_explosion = "cb-cold-explosion",
    dying_sound = sounds.worm_dying(0.8),
    loot = {},	
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_small, biter_tint1),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_small, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup_small(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_sound = sounds.worm_breath(0.6),
    prepared_animation = worm_prepared_animation(scale_worm_small, biter_tint1),
    prepared_alternative_speed = 0.024,
    prepared_alternative_speed_secondary = 0.018,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_small, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.64),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_small, biter_tint1),
    starting_attack_sound = sounds.worm_roars(0.62),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_small, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_small, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    integration = worm_integration(scale_worm_small),
    prepare_range = range_worm_small + prepare_range_worm_small,
    allow_turning_when_starting_attack = true,
	
    attack_parameters =
    {
      type = "stream",
      cooldown = eb_cooldown + 5,
      range = range_worm_small,--defined in demo-spitter-projectiles.lua
      damage_modifier = DAMAGE_S*damage_modifier_worm_small,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_medium, scale_worm_medium * scale_worm_stream),
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 *1.5, -- this is same as particle horizontal speed of flamethrower fire stream
      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "cb-cold-stream-small-t",
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },	
     autoplace = cb_enemy_autoplace.enemy_worm_autoplace(0),
    call_for_help_radius = 40,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 0,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 1,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 0,
        spawn_max_radius = 1
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 2,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      }
    }	
  },



  {
    type = "turret",
    name = "medium-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    order="b-ft-b",
    subgroup="enemies",
    max_health = 400*HEALTH_S,
    resistances = cold_resists,
    healing_per_tick = 0.015,
    collision_box = {{-1.1, -1.0}, {1.1, 1.0}},
    map_generator_bounding_box = {{-2.1, -2.0}, {2.1, 2.0}},
    selection_box = {{-1.1, -1.0}, {1.1, 1.0}},
    damaged_trigger_effect = hit_effects.biter(),
    shooting_cursor_size = 3.5,
    rotation_speed = 1,
    corpse = "medium-cold-worm-corpse",
    dying_explosion = "cb-medium-cold-explosion",
    dying_sound = sounds.worm_dying(1),
    loot = {},	
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_medium, biter_tint1),
    preparing_speed = 0.024,
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    preparing_animation = worm_preparing_animation(scale_worm_medium, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_medium, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    prepared_animation = worm_prepared_animation(scale_worm_medium, biter_tint1),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_medium, biter_tint1),
    starting_attack_sound = sounds.worm_roars(0.8),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_medium, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_medium, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    integration = worm_integration(scale_worm_medium),
    prepare_range = range_worm_medium + prepare_range_worm_medium,
    allow_turning_when_starting_attack = true,

    attack_parameters =
    {
      type = "stream",
      cooldown = eb_cooldown + 5,
      range = range_worm_medium,--defined in demo-spitter-projectiles.lua
      damage_modifier = DAMAGE_S*damage_modifier_worm_medium,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_medium, scale_worm_medium * scale_worm_stream),

      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 *1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_cluster_small,
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.3,
    autoplace = cb_enemy_autoplace.enemy_worm_autoplace(2),
    call_for_help_radius = 40,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 3
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 3,
        spawn_min_radius = 0,
        spawn_max_radius = 3
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 2,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 3
      }
    }	
  },


  {
    type = "turret",
    name = "big-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 750*HEALTH_S,
    order="b-ft-c",
    subgroup="enemies",
    resistances = cold_resists,
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    damaged_trigger_effect = hit_effects.biter(),
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "big-cold-worm-corpse",
    dying_explosion = "cb-big-cold-explosion",
    dying_sound = sounds.worm_dying(1.0),
    loot = {},	
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_big, biter_tint1),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_big, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_big, biter_tint1),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_big, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, biter_tint1),
    starting_attack_sound = sounds.worm_roars(0.95),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(1),
    integration = worm_integration(scale_worm_big),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = range_worm_big + prepare_range_worm_big,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      damage_modifier = DAMAGE_S*damage_modifier_worm_big,
      cooldown = eb_cooldown + 5,
      range = range_worm_big,--defined in demo-spitter-projectiles.lua
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_big, scale_worm_big * scale_worm_stream),

      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_cluster_small,
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.5,
    autoplace = cb_enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 3
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 3,
        spawn_max = 5,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      }
    }	
  },
  
  {
    type = "turret",
    name = "behemoth-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 1000*HEALTH_S,
    order="b-ft-d",
    subgroup="enemies",
    resistances = cold_resists,
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    damaged_trigger_effect = hit_effects.biter(),
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "behemoth-cold-worm-corpse",
    dying_explosion = "cb-big-artillery-cold-explosion",
    dying_sound = sounds.worm_dying(1.0),
    inventory_size = 2,
    loot = {},	
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth, biter_tint1),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth, biter_tint1),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth, biter_tint1),
    starting_attack_sound = sounds.worm_roars(0.95),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(1),
    integration = worm_integration(scale_worm_behemoth),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = range_worm_behemoth + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = DAMAGE_S*damage_modifier_worm_behemoth,
      cooldown = eb_cooldown + 5,
      range = range_worm_behemoth,--defined in demo-spitter-projectiles.lua
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth, scale_worm_behemoth * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_cluster_big,
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.9,
    autoplace = cb_enemy_autoplace.enemy_worm_autoplace(8),
    call_for_help_radius = 80,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 1,
        spawn_max = 3,
        spawn_min_radius = 1,
        spawn_max_radius = 5
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 3,
        spawn_max = 5,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      }
    }	
  },

  
  {
    type = "turret",
    name = "leviathan-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 1500*HEALTH_S,
    order="b-ft-g",
    subgroup="enemies",
    resistances = cold_resists,
    healing_per_tick = 0.02,
    collision_box = {{-2, -2}, {2, 2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-2, -2}, {2, 2}},
    damaged_trigger_effect = hit_effects.biter(),
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "leviathan-cold-worm-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    dying_sound = sounds.worm_dying(2.0),
    inventory_size = 2,
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth+1, biter_tint1),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth+1, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth+1, biter_tint1),
    prepared_sound = sounds.worm_breath(2),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth+1, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth+1, biter_tint1),
    starting_attack_sound = sounds.worm_roars(2),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth+1, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth+1, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(2),
    integration = worm_integration(scale_worm_behemoth+1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,
    loot = {},	
    prepare_range = 60  + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = DAMAGE_S*120,
      cooldown = eb_cooldown + 6,
      range = 60,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth+1, (scale_worm_behemoth+1) * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_cluster_big,
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.94,
    autoplace = cb_enemy_autoplace.enemy_worm_autoplace(8),
    call_for_help_radius = 100,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 1,
        spawn_max = 3,
        spawn_min_radius = 1,
        spawn_max_radius = 5
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 3,
        spawn_max = 5,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      }
    }	
  },
  
  
  
  
 


---- corpses

  {
    type = "corpse",
    name = "small-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_small, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_small)}
  },

  {
    type = "corpse",
    name = "medium-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_medium, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_medium)}
  },
  {
    type = "corpse",
    name = "big-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_big, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_big)}
  },
  {
    type = "corpse",
    name = "behemoth-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-d[behemoth]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth)}
  },
  {
    type = "corpse",
    name = "leviathan-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-g[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth+1, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth+1)}
  },


  
})




if not settings.startup["cb-disable-mother"].value then
data:extend(
{
  
  {
    type = "turret",
    name = "mother-cold-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 2000*HEALTH_S,
    order="b-ft-m",
    subgroup="enemies",
    resistances = cold_resists,
    healing_per_tick = 0.02,
    collision_box = {{-2, -2}, {2, 2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-2, -2}, {2, 2}},
    shooting_cursor_size = 4,
    damaged_trigger_effect = hit_effects.biter(),
    rotation_speed = 1,
    corpse = "mother-cold-worm-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    dying_sound = sounds.worm_dying(2.0),
    inventory_size = 2,
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth+2, biter_tint1),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth+2, biter_tint1, "forward"),
    preparing_sound = sounds.worm_standup(2),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth+2, biter_tint1),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth+2, biter_tint1),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth+2, biter_tint1),
    starting_attack_sound = sounds.worm_roars(2),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth+2, biter_tint1),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth+2, biter_tint1, "backward"),
    folding_sound = sounds.worm_fold(2),
    integration = worm_integration(scale_worm_behemoth+2),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,
    loot = {},	
    prepare_range = 70  + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = DAMAGE_S*150,
      cooldown = eb_cooldown + 300,
      range = 70,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth+2, (scale_worm_behemoth+2) * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "cb-cluster-coldmother-projectile-big-t",
            --duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.97,
    autoplace = cb_enemy_autoplace.enemy_worm_autoplace(14),
    call_for_help_radius = 100,
    spawn_decorations_on_expansion = true,
    spawn_decoration =
    {
      {
        decorative = "worms-decal",
        spawn_min = 1,
        spawn_max = 3,
        spawn_min_radius = 1,
        spawn_max_radius = 5
      },
      {
        decorative = "shroom-decal",
        spawn_min = 1,
        spawn_max = 2,
        spawn_min_radius = 1,
        spawn_max_radius = 2
      },
      {
        decorative = "enemy-decal",
        spawn_min = 1,
        spawn_max = 4,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      },
      {
        decorative = "enemy-decal-transparent",
        spawn_min = 3,
        spawn_max = 5,
        spawn_min_radius = 1,
        spawn_max_radius = 4
      }
    }	
  },


  {
    type = "corpse",
    name = "mother-cold-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
	icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-ft[worm]-m[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth+2, biter_tint1),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth+2)}
  },
})
end



end