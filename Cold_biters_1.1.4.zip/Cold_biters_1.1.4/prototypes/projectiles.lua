local math3d = require "math3d"
local cold_tint = { r = 0.75, g = 0.75, b = 1, a=0.85}
local small_scale =0.6
local big_scale = 1.1
local stream_worm_scale = 1.3
ENTITYPATH = "__Cold_biters__/graphics/entity/"
SOUNDPATH = "__Cold_biters__/sound/"
local ice_sounds={
              type = "play-sound",
              sound =
              {
                {
                  filename = SOUNDPATH .. "ice_crack1.ogg",
                  volume = 0.8
                },
                {
                  filename = SOUNDPATH .. "ice_crack2.ogg",
                  volume = 0.8
                },
                {
                  filename = SOUNDPATH .. "ice_crack3.ogg",
                  volume = 0.8
                },
                {
                  filename = SOUNDPATH .. "ice_crack4.ogg",
                  volume = 0.8
                },
                {
                  filename = SOUNDPATH .. "ice_crack5.ogg",
                  volume = 0.8
                },
                {
                  filename = SOUNDPATH .. "ice_crack6.ogg",
                  volume = 0.8
                },
              }
            }


function cold_sticker(data)
  return{
    type = "sticker",
    name = data.name,
    flags = {"not-on-map"},

    animation =
    {
      filename = ENTITYPATH .. "jetthrower-cold-explosion.png",
      line_length = 8,
      width = 64,
      height = 64,
      frame_count = 32,
      axially_symmetrical = false,
      direction_count = 1,
      blend_mode = "additive",
      animation_speed = 1,
      scale = 0.4,
      tint = data.tint,
      shift = math3d.vector2.mul({-0.078125, -1.8125}, 0.1)
    },

    duration_in_ticks = data.slow_seconds * 60,
    target_movement_modifier_from = data.slow_player_movement,
    target_movement_modifier_to = 1,
    vehicle_speed_modifier_from = data.slow_vehicle_speed,
    vehicle_speed_modifier_to = 1,
    vehicle_friction_modifier_from = data.slow_vehicle_friction,
    vehicle_friction_modifier_to = 1,
    --damage_per_tick = { amount = 100 / 60, type = "fire" }
  }
end




function cold_stream(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 6}, -----
--    ground_light = {intensity = 0.8, size = 6}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 10, type = "cold"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
		type = "instant",
          target_effects =
          {
			ice_sounds,
            {
              type = "create-fire",
              entity_name = data.splash_fire_name
            },
			{
			  type = "create-entity",
			  entity_name = data.cloud_name,
			},			
          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "cold"}
            }
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end

function cold_stream_cluster(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 4}, -----
--    ground_light = {intensity = 0.8, size = 4}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 20, type = "cold"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
			ice_sounds,
            {
              type = "create-fire",
              entity_name = data.splash_fire_name
            },
			{
			  type = "create-entity",
			  entity_name = data.cloud_name,
			},			
			{
				type = "nested-result",
				action =
						{
							type = "cluster",
							cluster_count = data.cluster,
							distance = 5,
							distance_deviation = 8,
							action_delivery =
							{
								type = "stream",
								stream = data.child_stream,
								starting_speed = 0.1,
								max_range = 8
							},
						}
			},
          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "cold"}
            }
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end


function coldmother_stream(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 6}, -----
--    ground_light = {intensity = 0.8, size = 6}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 100, type = "cold"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
		type = "instant",
          target_effects =
          {
			ice_sounds,
            {
              type = "create-fire",
              entity_name = data.splash_fire_name
            },
			{
			  type = "create-entity",
			  entity_name = data.cloud_name,
			},
			 {
			 type = "create-entity",
			 entity_name = "behemoth-cold-biter"   -- "behemoth-cold-spitter"
			 },

          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        force = "enemy",
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "cold"}
            }
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end

function coldmother_stream_cluster(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 4}, -----
--    ground_light = {intensity = 0.8, size = 4}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 150, type = "cold"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
			ice_sounds,
            {
              type = "create-fire",
              entity_name = data.splash_fire_name
            },
			{
			  type = "create-entity",
			  entity_name = data.cloud_name,
			},
			 {
			 type = "create-entity",
			 entity_name = "behemoth-cold-biter"
			 },	
			{
				type = "nested-result",
				action =
						{
							type = "cluster",
							cluster_count = data.cluster,
							distance = 10,
							distance_deviation = 16,
							action_delivery =
							{
								type = "stream",
								stream = data.child_stream,
								starting_speed = 0.1,
								max_range = 16
							},
						}
			},
          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "cold"}
            }
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end




data:extend(
{

  cold_sticker({
    name = "cb-cold-sticker",
    tint = cold_tint,
    slow_player_movement = 0.3,
    slow_vehicle_speed = 0.3,
    slow_vehicle_friction = 1.5,
    slow_seconds = 5
  }),
  
  acid_splash_fire({
    name = "cb-cold-splash-small",
    scale = small_scale,
    tint = cold_tint,
    ground_patch_scale = small_scale * ground_patch_scale_modifier,
    patch_tint_multiplier = patch_opacity,
    splash_damage_per_tick = 1,
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream({
    name = "cb-cold-stream-small",
    scale = small_scale,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-small",
	cloud_name = "cold-cloud-1",
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream_cluster({
    name = "cb-cluster-cold-projectile-small",
    scale = small_scale,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-small",
    sticker_name = "cb-cold-sticker",
	cloud_name = "cold-cloud-1",
	cluster =2,
	child_stream = 'cb-cold-stream-small'	
  }),

  ---big-
  
  acid_splash_fire({
    name = "cb-cold-splash-big",
    scale = big_scale,
    tint = cold_tint,
    ground_patch_scale = big_scale * ground_patch_scale_modifier,
    patch_tint_multiplier = patch_opacity,
    splash_damage_per_tick = 2,
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream({
    name = "cb-cold-stream-big",
    scale = big_scale,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
	cloud_name = "cold-cloud-2",
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream_cluster({
    name = "cb-cluster-cold-projectile-big",
    scale = big_scale,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
	cloud_name = "cold-cloud-2",
    sticker_name = "cb-cold-sticker",
	cluster =3,
	child_stream = 'cb-cold-stream-big'
  }),

  cold_stream_cluster({
    name = "cb-cluster-cold-projectile-boss",
    scale = 3.2,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
	cloud_name = "cold-cloud-2",
    sticker_name = "cb-cold-sticker",
	cluster =3,
	child_stream = 'cb-cold-stream-big'
  }),


-- mother

  coldmother_stream({
    name = "cb-coldmother-stream-big",
    scale = big_scale+ 0.5,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
	cloud_name = "cold-cloud-2",
    sticker_name = "cb-cold-sticker"
  }),

  coldmother_stream_cluster({
    name = "cb-cluster-coldmother-projectile-big",
    scale = big_scale  + 1,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
    sticker_name = "cb-cold-sticker",
	cloud_name = "cold-cloud-2",
	cluster =2,
	child_stream =  'cb-cold-stream-big' 
	--  'cb-coldmother-stream-big'
  }),


  
  
  
  

  
  
  
  ---  WORMS 
  
  
  
    cold_stream({
    name = "cb-cold-stream-small-t",
    scale = stream_worm_scale,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-t",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-small",
	cloud_name = "cold-cloud-1",
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream_cluster({
    name = "cb-cluster-cold-projectile-small-t",
    scale = stream_worm_scale+0.5,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-t",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-small",
    sticker_name = "cb-cold-sticker",
	cloud_name = "cold-cloud-1",
	child_stream = "cb-cold-stream-small-t",
	cluster =2
  }),

  ---big-

  cold_stream({
    name = "cb-cold-stream-big-t",
    scale = stream_worm_scale+1,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
	cloud_name = "cold-cloud-2",
    splash_fire_name = "cb-cold-splash-big",
    sticker_name = "cb-cold-sticker"
  }),

  cold_stream_cluster({
    name = "cb-cluster-cold-projectile-big-t",
    scale = stream_worm_scale+1.1,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "cb-cold-splash-big",
    sticker_name = "cb-cold-sticker",
	cloud_name = "cold-cloud-2",
	child_stream = "cb-cold-stream-big-t",
	cluster =4
  }),

-- mother

  coldmother_stream({
    name = "cb-coldmother-stream-big-t",
    scale = stream_worm_scale+1.4,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
	cloud_name = "cold-cloud-2",
    splash_fire_name = "cb-cold-splash-big",
    sticker_name = "cb-cold-sticker"
  }),

  coldmother_stream_cluster({
    name = "cb-cluster-coldmother-projectile-big-t",
    scale =  stream_worm_scale+1.5,
    tint = cold_tint,
    corpse_name = "cb-cold-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
	cloud_name = "cold-cloud-2",
    splash_fire_name = "cb-cold-splash-big",
    sticker_name = "cb-cold-sticker",
	cluster =2,
	child_stream = 'cb-coldmother-stream-big-t'
  }),
  
  
  
 
  
  
  
  
  
  
  
  
    {
    type = "stream",
    name = "cb-jetthrower-cold-stream",
    flags = {"not-on-map"},

    smoke_sources =
    {
      {
        name = "soft-fire-smoke",
        frequency = 0.05, --0.25,
        position = {0.0, 0}, -- -0.8},
        starting_frame_deviation = 60
      }
    },

    stream_light = {intensity = 1, size = 4 * 0.8},
    ground_light = {intensity = 0.8, size = 4 * 0.8},

    particle_buffer_size = 65,
    particle_spawn_interval = 2,
    particle_spawn_timeout = 2,
    particle_vertical_acceleration = 0.005 * 0.3,
    particle_horizontal_speed = 0.45,
    particle_horizontal_speed_deviation = 0.0035,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_start_scale = 0.5,
    particle_loop_frame_count = 3,
    particle_fade_out_threshold = 0.9,
    particle_loop_exit_threshold = 0.25,
    action =
    {
      {
        type = "area",
        radius = 4,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = 'cb-cold-sticker'
            },
            {
              type = "damage",
              damage = { amount = 7, type = "cold" },
              apply_damage_to_trees = false
            }
          }
        }
      }
    },




    spine_animation =
    {
      filename = ENTITYPATH .. "jetthrower-cold-stream-spine.png",
      blend_mode = "additive",
      --tint = {r=1, g=1, b=1, a=0.5},
      line_length = 4,
      width = 32,
      height = 18,
      frame_count = 32,
      axially_symmetrical = false,
      direction_count = 1,
      animation_speed = 2,
      scale = 1.40625,
      shift = {0, 0}
    },

    shadow =
    {
      filename = "__base__/graphics/entity/acid-projectile/projectile-shadow.png",
      line_length = 5,
      width = 28,
      height = 16,
      frame_count = 33,
      priority = "high",
      scale = 0.9375,
      shift = {-0.09 * 0.5, 0.395 * 0.5}
    },

    particle =
    {
      filename = ENTITYPATH .. "jetthrower-cold-explosion.png",
      priority = "extra-high",
      width = 64,
      height = 64,
      frame_count = 32,
      line_length = 8,
      scale = 1.5
    }
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
})