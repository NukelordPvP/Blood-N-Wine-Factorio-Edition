--luacheck: ignore

local Ingredients = {
    _class = 'Ingredients'
}

--Gets a single ingredient
function Ingredients.get(ingredient)
end

return Ingredients
