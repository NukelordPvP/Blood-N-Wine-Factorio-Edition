# factorio-helicopters
"HelicopterRevival" mod for factorio. Actually interesting stuff is in logic/.

Original (Helicopters) by [Kumpu](https://github.com/kumpuu/factorio-helicopters)

[Mod Portal](https://mods.factorio.com/mods/twilightthepony/HelicopterRevival)

