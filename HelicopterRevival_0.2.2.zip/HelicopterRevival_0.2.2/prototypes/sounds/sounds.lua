data:extend({
	{
		type = "sound",
		name = "heli-fuel-warning",
		filename = "__HelicopterRevival__/sound/fuel_warning.ogg",
		volume = 0.5,
	},
})