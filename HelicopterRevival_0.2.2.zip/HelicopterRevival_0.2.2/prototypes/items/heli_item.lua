data:extend({
	{
		type = "item-with-entity-data",
		name = "heli-item",
		icon = "__HelicopterRevival__/graphics/icons/heli.png",
		icon_size = 64,
		flags = {},
		subgroup = "transport",
		order = "b[personal-transport]-c[heli]",
		place_result = "heli-placement-entity-_-",
		stack_size = 1
	}
})