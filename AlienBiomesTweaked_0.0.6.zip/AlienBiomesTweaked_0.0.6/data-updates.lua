-- revert tile pollution absorption changes
if settings.startup["alienbiomestweaked_tilepollutionmodifier"].value then
	AlienBiomesTweaked = {}
	AlienBiomesTweaked.TilePollutionModifiers = {}
	for _, tile in pairs(data.raw.tile) do
		AlienBiomesTweaked.TilePollutionModifiers[tile.name] = tile.pollution_absorption_per_second
	end
end