data:extend({
	{
		type = "bool-setting",
		name = "alienbiomestweaked_playertreecollision",
		description = "alienbiomestweaked_playertreecollision",
		setting_type = "startup",
		default_value = true,
		order = "a"
	},
	{
		type = "bool-setting",
		name = "alienbiomestweaked_treeresourcelayer",
		description = "alienbiomestweaked_treeresourcelayer",
		setting_type = "startup",
		default_value = true,
		order = "a-a"
	},
	{
		type = "bool-setting",
		name = "alienbiomestweaked_resourcelandfillcollision",
		description = "alienbiomestweaked_resourcelandfillcollision",
		setting_type = "startup",
		default_value = true,
		order = "b"
	},
	{
		type = "bool-setting",
		name = "alienbiomestweaked_tilepollutionmodifier",
		description = "alienbiomestweaked_tilepollutionmodifier",
		setting_type = "startup",
		default_value = true,
		order = "c"
	},
	{
		type = "bool-setting",
		name = "alienbiomestweaked_treeemissionspersecond",
		description = "alienbiomestweaked_treeemissionspersecond",
		setting_type = "startup",
		default_value = true,
		order = "d"
	},
	{
		type = "double-setting",
		name = "alienbiomestweaked_rockcoveragemultiplier",
		description = "alienbiomestweaked_rockcoveragemultiplier",
		setting_type = "startup",
		default_value = 1,
		minimum_value = 0,
		maximum_value = 10,
		order = "e-a"
	},
	{
		type = "double-setting",
		name = "alienbiomestweaked_rockmaxprobmultiplier",
		description = "alienbiomestweaked_rockmaxprobmultiplier",
		setting_type = "startup",
		default_value = 1,
		minimum_value = 0,
		maximum_value = 10,
		order = "e-b"
	},
	{
		type = "double-setting",
		name = "alienbiomestweaked_volcanicrockmultiplier",
		description = "alienbiomestweaked_volcanicrockmultiplier",
		setting_type = "startup",
		hidden = true,
		default_value = 2,
		minimum_value = 0,
		maximum_value = 100,
		order = "e-c"
	}
})