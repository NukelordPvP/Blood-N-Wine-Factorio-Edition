local collision_mask_util = require("collision-mask-util")

local playertreecollision = settings.startup["alienbiomestweaked_playertreecollision"].value
local treeresourcelayer = settings.startup["alienbiomestweaked_treeresourcelayer"].value
if playertreecollision or treeresourcelayer then
	for _, tree in pairs(data.raw.tree) do
		local collisions = collision_mask_util.get_mask(tree)
		if playertreecollision then collision_mask_util.add_layer(collisions, "player-layer") end -- add player-layer back to trees
		if treeresourcelayer then collision_mask_util.remove_layer(collisions, "resource-layer") end -- remove resource-layer back off from trees
		tree.collision_mask = collisions
	end
end

-- remove resource-layer back off from landfill
if settings.startup["alienbiomestweaked_resourcelandfillcollision"].value then
	local collisions = collision_mask_util.get_mask(data.raw.tile.landfill)
	collision_mask_util.remove_layer(collisions, "resource-layer")
	data.raw.tile.landfill.collision_mask = collisions
end

-- revert tile pollution absorption changes (and make tweaks to Alien Biome added tiles in an effort to make them equivalent with vanilla values)
if settings.startup["alienbiomestweaked_tilepollutionmodifier"].value then
	local dirt_pollution_absorption = 0.0000066
	local sand_pollution_absorption = 0.0000058
	local red_desert_pollution_absorption = 0.0000066
	for _, tile in pairs(data.raw.tile) do
		if tile.name:find("mineral") then
			if tile.name:find("dirt") then
				tile.pollution_absorption_per_second = dirt_pollution_absorption
			elseif tile.name:find("sand") then
				if tile.name:find("red") then
					tile.pollution_absorption_per_second = red_desert_pollution_absorption
				else
					tile.pollution_absorption_per_second = sand_pollution_absorption
				end
			end
		else
			tile.pollution_absorption_per_second = AlienBiomesTweaked.TilePollutionModifiers[tile.name] or tile.pollution_absorption_per_second
		end
	end
end

-- normalize all Alien Biomes added trees to that of vanilla
if settings.startup["alienbiomestweaked_treeemissionspersecond"].value and mods["alien-biomes"] then
	local trees_data = require("__alien-biomes__/prototypes/entity/tree-data")
	for _, treedata in pairs(trees_data) do
		if not (treedata.enabled == false) then
			if data.raw.tree[treedata.name] then
				data.raw.tree[treedata.name].emissions_per_second = -0.001
			end
		end
	end
end

-- rock frequency for Alien Biomes
local rock_coverage_multiplier = settings.startup["alienbiomestweaked_rockcoveragemultiplier"].value / 3
local rock_max_prob_multiplier = settings.startup["alienbiomestweaked_rockmaxprobmultiplier"].value / 6
-- local volcanic_rock_multiplier = settings.startup["alienbiomestweaked_volcanicrockmultiplier"].value / 2
local rocks = {
	["tan"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny",
		"stone-decal",
		"sand-decal",
		"sand-rock-big",
		"sand-rock-medium",
		"sand-rock-small"
	},
	["dustyrose"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["cream"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["brown"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["beige"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["red"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny",
		"stone-decal",
		"sand-decal",
		"sand-rock-big",
		"sand-rock-medium",
		"sand-rock-small"
	},
	["violet"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["purple"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny",
		"stone-decal",
		"sand-decal",
		"sand-rock-big",
		"sand-rock-medium",
		"sand-rock-small"
	},
	["aubergine"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["black"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny",
		"stone-decal",
		"sand-decal",
		"sand-rock-big",
		"sand-rock-medium",
		"sand-rock-small"
	},
	["grey"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny"
	},
	["white"] = {
		"rock-huge",
		"rock-big",
		"rock-medium",
		"rock-small",
		"rock-tiny",
		"stone-decal",
		"sand-decal",
		"sand-rock-big",
		"sand-rock-medium",
		"sand-rock-small"
	}
}

if rock_coverage_multiplier ~= 1 or rock_max_prob_multiplier ~= 1 then
	for name, base_rocks in pairs(rocks) do
		for _, base in pairs(base_rocks) do
			local current_rock
			if base == "rock-huge" or base == "rock-big" then
				current_rock = data.raw["simple-entity"][base .. "-" .. name]
			else
				current_rock = data.raw["optimized-decorative"][base .. "-" .. name]
			end
			if current_rock and current_rock.autoplace then
				if rock_coverage_multiplier ~= 1 and current_rock.autoplace.coverage then
					current_rock.autoplace.coverage = current_rock.autoplace.coverage * rock_coverage_multiplier
				end
				if rock_max_prob_multiplier ~= 1 and current_rock.autoplace.max_probability then
					current_rock.autoplace.max_probability = current_rock.autoplace.max_probability * rock_max_prob_multiplier
				end
			end
		end
	end
end