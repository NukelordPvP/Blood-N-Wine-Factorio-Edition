if not mods.IndustrialRevolution then
	return
end

data.raw.technology["aai-signal-transmission"].IR_native = true
data.raw.technology["aai-signal-transmission"].prerequisites = {"circuit-network"}

data.raw.recipe["aai-signal-receiver"].energy_required = 3.2
data.raw.recipe["aai-signal-receiver"].ingredients = {
	{"radar", 1},
	{"computer-mk2", 4},
	{"electric-engine-unit", 8},
	{"steel-plate-heavy", 12},
	{"steel-rod", 24},
}

data.raw.recipe["aai-signal-sender"].energy_required = 3.2
data.raw.recipe["aai-signal-sender"].ingredients = {
	{"steel-frame-large", 1},
	{"computer-mk2", 4},
	{"advanced-battery", 20},
	{"electric-engine-unit", 8},
	{"copper-coil", 4},
}
