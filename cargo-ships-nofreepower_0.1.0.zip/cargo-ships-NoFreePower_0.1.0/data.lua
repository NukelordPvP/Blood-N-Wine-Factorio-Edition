-- or_power's primary purpose is to create smoke when the oil rig is in use (and a little bit to power radar/pumps when not in use).
-- Since the smoke is created proportional to the energy usage, we need this EEI to cover the high power demands e.g. when modules are used.

for name, or_power_electric in pairs(data.raw["electric-energy-interface"]) do
  if name == "or_power_electric" then
	--set production to 0
	or_power_electric.energy_production = "0W"
	--lower priority
	or_power_electric.energy_source.usage_priority = "tertiary-output"
	
	--set buffer capacity low to completely remove any energy capacity
	or_power_electric.energy_source.buffer_capacity = "0MJ"
    or_power_electric.energy_source.usage_priority = "tertiary"
    or_power_electric.energy_source.input_flow_limit = "0MW"
    or_power_electric.energy_source.output_flow_limit = "0MW"
  end
end
