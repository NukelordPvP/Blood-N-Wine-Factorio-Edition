# Cargo ships - No free power
Cargo Ships Oil rigs by default contain an entity supplying free power to accomodate module use without the need to hook up to the electric network. It can be fun to get free energy when you accidentally add the oil rig to the main network, it isn't very balanced. This mod sets the "infinite energy" entity production to 0. 

This may cause issues where the oil rig can't get enough power when working with modules. To mitigate this you'll need to integrate the oil rig to your network.

## Features
No more free energy!

## Future features
Water-based pylons/substations
Retain flexible power production, but burn oil that's pumped up as fuel(To a limit)

## Credits
 - schnurrebutz/rudegrass | Creator of original mod
 - All other contributors to the Cargo ships mod
