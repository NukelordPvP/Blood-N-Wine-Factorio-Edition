local BPSB = {}

BPSB.name = "blueprint-sandboxes"
BPSB.path = "__" .. BPSB.name .. "__"
BPSB.pfx = "bpsb-"

return BPSB
