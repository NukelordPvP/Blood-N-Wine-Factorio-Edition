data:extend{{
    type = "int-setting",
    name = "svp-drift",
    setting_type = "runtime-global",
    default_value = 24,
    minimum_value = 0,
},{
    type = "double-setting",
    name = "svp-handling",
    setting_type = "runtime-global",
    default_value = 1/3,
    minimum_value = 0,
    maximum_value = 1,
}}