local cmu = require("collision-mask-util")

for _, car in pairs(data.raw.car) do
    data:extend{{
        type = "simple-entity",
        name = car.name .. "-dummy",
        icon = "__core__/graphics/icons/unknown.png",
        icon_size = 64,
        collision_box = {{-1/256, -1/256}, {1/256, 1/256}},
        collision_mask = cmu.get_mask(car),
        picture = {
            filename = "__core__/graphics/empty.png",
            size = 1
        },
    }}
end