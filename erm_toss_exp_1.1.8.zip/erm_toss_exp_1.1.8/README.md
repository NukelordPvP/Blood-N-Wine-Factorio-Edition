Protoss race for Enemy Race Manager Experimental (HD Assets included - will be released as an additional mod soon to make downloading updates easier and optionally merge the HD Assets with heyqule's original mod).

A few experimental tweaks differing from heyqule's original ERM Protoss:

I simply updated the sprites to higher resolution sprites, slightly modified the unit spawns to try and match Protoss unit spawns a little more with the structure they"re associated with, and added 7 additional Protoss buildings and units.

- Updated the sprites to higher resolution sprites.
- Added psionic matrix effect to Protoss Pylons that additionally glows at night (cosmetic only).
- Slightly modified the unit spawns to try and match Protoss unit spawns a little more with the structure they"re associated with; units higher in the Protoss tech tree will have a greater chance of spawning at higher evolution levels, while from the same structure more common Protoss units will spawn early on.
- Buffed the attack range of Protoss Carriers, Arbiters, and High Templars to suit the original feel and compete with longer ranged modded weapons.
- The Protoss Probe now has a construction animation as it warps in turrets (the Probe is absorbed in the process for balance reasons).
- Added 3 buildings & 4 additional Protoss units: Robotics Facility, Robotics Support Bay, Shield Battery, Reaver, persistent Scarabs (if they don"t detonate on a target), persistent Interceptors, and Dark Archon.
- The Carrier's now buffed long range attack now spawns actual Interceptors now in waves of 8 with a long cooldown. The Interceptors fly around and shoot as normal units once spawned, but are pretty easy to take down; consider the Carrier a mobile unit_spawner.
- The Scout now shoot both its Photon Blasters and Missiles when attacking.
- The new Reaver unit spawns the new Scarab units which are basically long range homing bombs.
- The new Dark Archon unit is basically a range Archon with the visual effects of a Dark Archon casting its spells.
- The new Robotics Facility is a unit_spawner focused on spawning Protoss Shuttles.
- The new Robotics Support Bay is a unit_spawner focused on spawning Reavers.
- The Shield Battery spawns as a turret, but merely heals nearby allies with an AoE effect (I"m looking into giving actual shields to Protoss buildings and units based on the Turret Shields mod, but we"ll see...).

Any other work and coding I 100% attribute to and appreciate the original ERM - Protoss Units modder heyqule: https://mods.factorio.com/mod/erm_toss

If you use Krastorio 2, beware creep will also spawn around Protoss bases; consider them infested Protoss.

If there are any updates to the base ERM mods or Factorio which require this mod to be updated please let me know.