--
-- Created by IntelliJ IDEA.
-- User: heyqule
-- Date: 12/20/2020
-- Time: 5:04 PM
-- To change this template use File | Settings | File Templates.
--

local Game = require("__stdlib__/stdlib/game")
local ErmForceHelper = require("__enemyracemanager__/lib/helper/force_helper")
local ErmRaceSettingsHelper = require("__enemyracemanager__/lib/helper/race_settings_helper")
local ErmConfig = require("__enemyracemanager__/lib/global_config")

local Event = require("__stdlib__/stdlib/event/event")
local String = require("__stdlib__/stdlib/utils/string")
local CustomAttacks = require("__erm_toss_exp__/scripts/custom_attacks")

require("__erm_toss_exp__/global")
-- Constants


local createRace = function()
    local force = game.forces[FORCE_NAME]
    if not force then
        force = game.create_force(FORCE_NAME)
    end

    force.ai_controllable = true;
    force.disable_research()
    force.friendly_fire = false;

    if settings.startup["enemyracemanager-free-for-all"].value then
        ErmForceHelper.set_friends(game, FORCE_NAME, false)
    else
        ErmForceHelper.set_friends(game, FORCE_NAME, true)
    end

    ErmForceHelper.set_neutral_force(game, FORCE_NAME)
end

local addRaceSettings = function()
    local race_settings = remote.call("enemyracemanager", "get_race", MOD_NAME)
    if race_settings == nil then
        race_settings = {}
    end

    race_settings.race = race_settings.race or MOD_NAME
    race_settings.label = {"gui.label-erm-toss-exp"}
    race_settings.level = race_settings.level or 1
    race_settings.tier = race_settings.tier or 1
    race_settings.evolution_point = race_settings.evolution_point or 0
    race_settings.evolution_base_point = race_settings.evolution_base_point or 0
    race_settings.attack_meter = race_settings.attack_meter or 0
    race_settings.attack_meter_total = race_settings.attack_meter_total or 0
    race_settings.next_attack_threshold = race_settings.next_attack_threshold or 0

    if game.active_mods["Krastorio2"] then
        race_settings.enable_k2_creep = settings.startup["erm_toss_exp-k2-creep"].value
    end

    race_settings.units = {
        {"probe","zealot","dragoon"},
        {"shuttle","scout","corsair","templar","darktemplar"},
        {"archon","darkarchon","arbiter","reaver","carrier"}
    }
    race_settings.turrets = {
        {"cannon","acid-cannon","shield_battery"},
        {},
        {}
    }
    race_settings.command_centers = {
        {"nexus","pylon"},
        {},
        {}
    }
    race_settings.support_structures = {
        {"pylon","gateway","forge"},
        {"cybernetics_core","stargate","citadel_adun","robotics_facility"},
        {"templar_archive","arbiter_tribunal","robotics_support_bay","fleet_beacon"}
    }
    race_settings.flying_units = {
        {"scout"},
        {"shuttle","corsair"},
        {"carrier","arbiter"}
    }
    race_settings.dropship = "shuttle"
    race_settings.droppable_units = {
        {{"zealot"},{4}},
        {{"zealot","probe"},{3,2}},
        {{"zealot","dragoon"},{2,1}},
        {{"dragoon","darktemplar"},{1,2}},
        {{"templar","zealot"},{1,3}},
        {{"templar","archon"},{2,1}},
        {{"darktemplar","darkarchon"},{2,1}},
        {{"archon","darkarchon"},{1,1}},
        {{"reaver"},{2}}
    }
    race_settings.construction_buildings = {
        {{ "cannon_shortrange"},{1}},
        {{ "cannon_shortrange"},{1}},
        {{ "cannon_shortrange","pylon"},{2,1}}
    }
    race_settings.featured_groups = {
        -- Unit list, spawn ratio, unit attack point cost
        {{"zealot","dragoon"},{6,3}, 20},
        {{"zealot","archon"},{6,3}, 25},
        {{"zealot","dragoon","archon"},{3,3,2}, 25},
        {{"zealot","dragoon","darkarchon"},{3,3,2}, 25},
        {{"zealot","dragoon","reaver"},{3,3,2}, 25},
        {{"zealot","dragoon","templar"},{7,3,1}, 25},
        {{"darktemplar","templar","archon","darkarchon"},{4,1,2,1}, 25},
        {{"zealot","dragoon","darktemplar","templar","archon","reaver"},{3,3,2,1,1,2}, 30}
    }
    race_settings.featured_flying_groups = {
        {{"scout","corsair"},{1,1}, 35},
        {{"scout","carrier"},{4,1}, 50},
        {{"corsair","arbiter"},{5,1}, 60},
        {{"scout","corsair","carrier","arbiter"},{4,4,1,1}, 50},
        {{"scout","corsair","carrier","shuttle"},{5,3,2,1}, 60}
    }

    race_settings.boss_building = "warpgate"
    race_settings.pathing_unit = "zealot"
    race_settings.colliding_unit = "archon"
    race_settings.boss_tier = race_settings.boss_tier or 1
    race_settings.boss_kill_count = race_settings.boss_kill_count or 0

    ErmRaceSettingsHelper.process_unit_spawn_rate_cache(race_settings)

    remote.call("enemyracemanager", "register_race", race_settings)
    CustomAttacks.get_race_settings(MOD_NAME, true)
end

Event.on_init(function(event)
    createRace()
    addRaceSettings()
end)

Event.on_load(function(event)
end)

Event.on_configuration_changed(function(event)
    createRace()
    addRaceSettings()
end)

local attack_functions = {
    [PROBE_ATTACK] = function(args)
        CustomAttacks.process_probe(args)
    end,
    [SHUTTLE_DROP_ATTACK] = function(args)
        CustomAttacks.process_shuttle_drop_attack(args)
    end,
    [CARRIER_ATTACK] = function(args)
        CustomAttacks.process_carrier_attack(args)
    end,
    [REAVER_ATTACK] = function(args)
        CustomAttacks.process_reaver_attack(args)
    end,
    [SCARAB_ATTACK] = function(args)
        CustomAttacks.process_scarab_attack(args)
    end,
    [BOSS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_boss_units(args)
    end,
    [UNITS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_batch_units(args)
    end,
    [ARBITER_UNITS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_batch_units(args, 1)
    end
}
Event.register(defines.events.on_script_trigger_effect, function(event)
    if  attack_functions[event.effect_id] and
            CustomAttacks.valid(event, MOD_NAME)
    then
        attack_functions[event.effect_id](event)
    end
end)

Event.on_nth_tick(1803, function(event)
    CustomAttacks.clearTimeToLiveUnits(event)
end)

Event.register(defines.events.on_runtime_mod_setting_changed,function(event)
    if event.setting_type == "runtime-global" and
            event.setting == "erm_toss_exp-team-color"
    then
       local color = ErmConfig.format_team_color(settings.startup["erm_toss_exp-team-color"].value)
       game.forces[FORCE_NAME].custom_color = color
    end
end)

local ErmBossAttack = require("scripts/boss_attacks")
remote.add_interface("erm_toss_exp_boss_attacks", {
    get_attack_data = ErmBossAttack.get_attack_data,
})

local RemoteApi = require("scripts/remote")
remote.add_interface("erm_toss_exp", RemoteApi)

