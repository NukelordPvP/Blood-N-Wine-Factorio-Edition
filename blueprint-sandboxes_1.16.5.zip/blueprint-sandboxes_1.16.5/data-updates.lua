BPSB = require("scripts.bpsb")

require("prototypes.recipes.hidden-vanilla-updates")
