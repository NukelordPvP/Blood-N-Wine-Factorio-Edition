local data_util = require("data_util")

if mods["Krastorio2"] then
  -- Require files where further directed changes are made
  require("prototypes/phase-4/krastorio2/science-packs")
end