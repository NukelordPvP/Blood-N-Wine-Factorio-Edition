require("commons")

data:extend({
	{
		type = "bool-setting",
		default_value = false,
		name = cyanSettingName,
		setting_type = "startup",
		order = "a"
	}
})
