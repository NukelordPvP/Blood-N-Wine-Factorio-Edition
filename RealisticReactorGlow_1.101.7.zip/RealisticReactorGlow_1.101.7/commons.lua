modName = "RealisticReactorGlow"
modRoot = "__" .. modName .. "__"

local settingNamePrefix = modName .. "-"
cyanSettingName = settingNamePrefix .. "cyan"
