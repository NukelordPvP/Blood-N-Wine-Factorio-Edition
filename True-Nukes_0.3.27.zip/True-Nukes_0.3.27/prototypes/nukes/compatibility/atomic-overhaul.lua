require("add-basic-uranium-nukes")


table.insert(data.raw.technology["basic-atomic-weapons"].prerequisites, "nuclear-fuel-reprocessing")
