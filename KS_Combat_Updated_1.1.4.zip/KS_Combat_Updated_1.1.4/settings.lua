data:extend({
    
    {
        type = "int-setting",
        name = "ksc-default-magazine-size",
        setting_type = "startup",
        default_value = 20,
        minimum_value = 5,
    },
	
	{
        type = "int-setting",
        name = "ksc-default-shotgun-magazine-size",
        setting_type = "startup",
        default_value = 10,
        minimum_value = 5,
    },
	
    {
        type = "bool-setting",
        name = "ksc-walls-block-spitters",
        setting_type = "startup",
        default_value = true,
    },
	
	{
        type = "bool-setting",
        name = "ksc-homing",
        setting_type = "startup",
        default_value = false,
    },
	
	{
        type = "bool-setting",
        name = "ksc-hitscan",
        setting_type = "startup",
        default_value = false,
    }
})
