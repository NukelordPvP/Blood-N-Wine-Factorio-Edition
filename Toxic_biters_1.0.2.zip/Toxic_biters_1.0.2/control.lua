
local replaces = {
	['small-toxic-worm-turret']={'small-worm-turret'},
	['medium-toxic-worm-turret']={'medium-worm-turret'},
	['big-toxic-worm-turret']={'big-worm-turret'},
	['behemoth-toxic-worm-turret']={'behemoth-worm-turret'},
	['leviathan-toxic-worm-turret']={'behemoth-worm-turret'},
	['mother-toxic-worm-turret']={'behemoth-worm-turret'},
	['toxic-biter-spawner']={'biter-spawner','spitter-spawner'},
	}

local aux_min = 50

local function GetLocalAux(surface,position)
local aux
local calc = surface.calculate_tile_properties({'aux'},{position}) 
if calc and calc.aux then
	aux = calc.aux[1] end
return aux
end

script.on_event(defines.events.on_biter_base_built, function(event)
if not global.setting_disable_terrain_check then
local entity=event.entity
if replaces[entity.name] then
	local position=entity.position
	local surface=entity.surface
	local force=entity.force
	local aux = GetLocalAux(surface,position) 
	if aux then 
		if aux < aux_min then
			local name   = entity.name
			local replac = replaces[name][math.random(#replaces[name])]
			entity.destroy()
			surface.create_entity{name=replac, position=position, force=force} 
			end
		end
	end
end
end)

function ReadSettings(event)
global.setting_disable_terrain_check = settings.startup["tb-disable-terrain-check"].value
end

function on_init() 
ReadSettings()
end
function on_configuration_changed(data)
ReadSettings()
end
script.on_configuration_changed(on_configuration_changed)
script.on_init(on_init)