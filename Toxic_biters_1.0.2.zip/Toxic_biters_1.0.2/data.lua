path = '__Toxic_biters__'
sounds = require("__base__/prototypes/entity/sounds.lua")
biter_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}  -- purple  {r = 0.7, g = 0.5, b = 1, a = 0.9}
biter_tint2 = {r = 0.4, g = 1, b = 0.6, a = 0.6} 
spawner_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}
biter_back_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}

worm_tint= {r = 0.4, g = 1, b = 0.6, a =1} 

OPT_DAMAGE_MULT = settings.startup["tb-DamageScaler"].value


dmg_modifier_spitter_small    = 12* OPT_DAMAGE_MULT
dmg_modifier_spitter_medium   = 24* OPT_DAMAGE_MULT
dmg_modifier_spitter_big      = 36* OPT_DAMAGE_MULT
dmg_modifier_spitter_behemoth = 60* OPT_DAMAGE_MULT
dmg_modifier_spitter_leviathan= 90* OPT_DAMAGE_MULT
dmg_modifier_spitter_mother   =150* OPT_DAMAGE_MULT

dmg_modifier_worm_small    = 36* OPT_DAMAGE_MULT
dmg_modifier_worm_medium   = 48* OPT_DAMAGE_MULT
dmg_modifier_worm_big      = 72* OPT_DAMAGE_MULT
dmg_modifier_worm_behemoth = 96* OPT_DAMAGE_MULT
dmg_modifier_worm_leviathan= 60* OPT_DAMAGE_MULT
dmg_modifier_worm_mother   =100* OPT_DAMAGE_MULT


range_spitter_leviathan = 22
range_spitter_mother = 35


require ("prototypes.projectiles")
require ("prototypes.explosion")
require ("prototypes.spitters")
require ("prototypes.biters")
require ("prototypes.worms")
require ("prototypes.bosses")


local icon_tint = {r = 0.9, g = 0.6, b = 0.9, a = 0.9}

-- custom icons
function create_icons(t,name)
local data = data.raw[t][name]
if data then 
	data.icons = {{icon=data.icon,tint=icon_tint,icon_size=data.icon_size}} 
	end
end

create_icons('unit','small-toxic-biter')
create_icons('unit','medium-toxic-biter')
create_icons('unit','big-toxic-biter')
create_icons('unit','behemoth-toxic-biter')
create_icons('unit','leviathan-toxic-biter')

create_icons('unit','small-toxic-spitter')
create_icons('unit','medium-toxic-spitter')
create_icons('unit','big-toxic-spitter')
create_icons('unit','behemoth-toxic-spitter')
create_icons('unit','leviathan-toxic-spitter')
create_icons('unit','mother-toxic-spitter')

for k=1,10 do 
	create_icons('unit',"maf-boss-toxic-biter-"..k)
	create_icons('unit',"maf-boss-toxic-spitter-"..k)
	end


create_icons("unit-spawner","toxic-biter-spawner")
create_icons("turret","small-toxic-worm-turret")
create_icons("turret","medium-toxic-worm-turret")
create_icons("turret","big-toxic-worm-turret")
create_icons("turret","behemoth-toxic-worm-turret")
create_icons("turret","leviathan-toxic-worm-turret")
create_icons("turret","mother-toxic-worm-turret")


--option to disable vanilla enemies
if settings.startup["tb-disable-vanilla"].value then
	data.raw['unit-spawner']['biter-spawner'].autoplace = nil
	data.raw['unit-spawner']['spitter-spawner'].autoplace = nil
	data.raw['turret']['small-worm-turret'].autoplace = nil
	data.raw['turret']['medium-worm-turret'].autoplace = nil
	data.raw['turret']['big-worm-turret'].autoplace = nil
	data.raw['turret']['behemoth-worm-turret'].autoplace = nil
	end