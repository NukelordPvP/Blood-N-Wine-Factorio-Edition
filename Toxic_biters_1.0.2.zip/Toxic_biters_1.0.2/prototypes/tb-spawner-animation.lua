
function tb_spawner_integration()
return
  {
    filename = "__base__/graphics/entity/spawner/spawner-idle-integration.png",
    variation_count = 4,
    width = 258,
    height = 188,
    shift = util.by_pixel(2, -2),
    frame_count = 1,
    line_length = 1,
    hr_version =
    {
      filename = "__base__/graphics/entity/spawner/hr-spawner-idle-integration.png",
      variation_count = 4,
      width = 522,
      height = 380,
      shift = util.by_pixel(3, -3),
      frame_count = 1,
      line_length = 1,
      scale = 0.5
    }
  }
end

function tb_spawner_idle_animation(variation, tint)
local anim =  {
    layers =
    {
      {
          filename = path .. "/graphics/spawner/explosivespawner-idle.png",
          line_length = 8,
          width = 4608/8,
          height = 4608/8,
          frame_count = 16,
          animation_speed = 0.18,
          direction_count = 1,
          run_mode = "forward-then-backward",
          --shift = util.by_pixel(3, -2),
          y = variation * 4608/8 * 2,
          scale = 0.5
      },
      {
          filename = path .. "/graphics/spawner/explosivespawner-idle-mask.png",
          flags = { "mask" },
          width = 4608/8,
          height = 4608/8,
          frame_count = 16,
          animation_speed = 0.18,
          run_mode = "forward-then-backward",
          --shift = util.by_pixel(-1, -14),
          line_length = 8,
          tint = tint,
          y = variation * 4608/8 * 2,
          scale = 0.5
      },
      {

          filename = path .. "/graphics/spawner/explosivespawner-idle-shadow.png",
          draw_as_shadow = true,
          width = 4608/8,
          height = 4608/8,
          frame_count = 16,
          animation_speed = 0.18,
          run_mode = "forward-then-backward",
         -- shift = util.by_pixel(36, 10),
          line_length = 8,
          y = variation * 4608/8 * 2,
          scale = 0.5

      }
    }
  }
  
 if not tint then anim.layers[2] = nil end
 return anim
end



function tb_spawner_die_animation(variation, tint)
return
  {
    layers =
    {
      {
        filename = "__base__/graphics/entity/spawner/spawner-die.png",
        line_length = 8,
        width = 248,
        height = 178,
        frame_count = 8,
        direction_count = 1,
        shift = util.by_pixel(2, -2),
        y = variation * 178,
        hr_version =
        {
          filename = "__base__/graphics/entity/spawner/hr-spawner-die.png",
          line_length = 8,
          width = 490,
          height = 354,
          frame_count = 8,
          direction_count = 1,
          shift = util.by_pixel(3, -2),
          y = variation * 354,
          scale = 0.5
        }
      },
      {
        filename = "__base__/graphics/entity/spawner/spawner-die-mask.png",
        flags = { "mask" },
        width = 140,
        height = 118,
        frame_count = 8,
        direction_count = 1,
        shift = util.by_pixel(-2, -14),
        line_length = 8,
        tint = tint,
        y = variation * 118,
        hr_version =
        {
          filename = "__base__/graphics/entity/spawner/hr-spawner-die-mask.png",
          flags = { "mask" },
          width = 276,
          height = 234,
          frame_count = 8,
          direction_count = 1,
          shift = util.by_pixel(-1, -14),
          line_length = 8,
          tint = tint,
          y = variation * 234,
          scale = 0.5
        }
      },
      {
        filename = "__base__/graphics/entity/spawner/spawner-die-shadow.png",
        draw_as_shadow = true,
        width = 232,
        height = 176,
        frame_count = 8,
        direction_count = 1,
        shift = util.by_pixel(36, -2),
        line_length = 8,
        y = variation * 176,
        hr_version =
        {
          filename = "__base__/graphics/entity/spawner/hr-spawner-die-shadow.png",
          draw_as_shadow = true,
          width = 466,
          height = 406,
          frame_count = 8,
          direction_count = 1,
          shift = util.by_pixel(36, 10),
          line_length = 8,
          y = variation * 406,
          scale = 0.5
        }
      }
    }
  }
end


function tb_TEMP_spawner_die_animation(variation, tint)
return
  {
    layers =
    {
      {

          filename = "__base__/graphics/entity/spawner/hr-spawner-idle-integration.png",
          line_length = 1,
          width = 522,
          height = 1520/4,
          frame_count = 1,
          direction_count = 1,
          --shift = util.by_pixel(3, -2),
          y = variation * 1520/4,
          scale = 0.5

      },
    }
  }
end

