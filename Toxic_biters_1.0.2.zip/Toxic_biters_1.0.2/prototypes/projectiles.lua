
local tint = {r = 0.7, g = 0.5, b = 1, a = 0.9}
local small_scale =0.6
local big_scale = 1.1
local boss_scale = 3.2
local stream_worm_scale = 1.3



function fire_stream(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 6}, -----
--    ground_light = {intensity = 0.8, size = 6}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 1, type = "acid"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
		type = "instant",
          target_effects =
          {
            {
              type = "play-sound",
              sound =
              {
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-1.ogg",
                  volume = 0.8
                },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-2.ogg",
                  volume = 0.8
                },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-long-1.ogg",
                  volume = 0.8
                },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-long-2.ogg",
                  volume = 0.8
                }
              }
            },
            {
              type = "create-fire",
              entity_name = data.splash_fire_name,
              tile_collision_mask = { "water-tile" },
              show_in_tooltip = true			  
            },
			{
			  type = "create-entity",
			  entity_name = data.poison_cloud,
			  show_in_tooltip = true
			},			

          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        force = "enemy",
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "acid"}
            }
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end


function firemother_stream(data)
  return
  {
    type = "stream",
    name = data.name,
    flags = {"not-on-map"},
--    stream_light = {intensity = 1, size = 6}, -----
--    ground_light = {intensity = 0.8, size = 6}, ---
    particle_buffer_size = 90,
    particle_spawn_interval = data.particle_spawn_interval,
    particle_spawn_timeout = data.particle_spawn_timeout,
    particle_vertical_acceleration = 0.005 * 0.60 *1.5, --x
    particle_horizontal_speed = 0.2* 0.75 * 1.5 * 1.5, --x
    particle_horizontal_speed_deviation = 0.005 * 0.70,
    particle_start_alpha = 0.5,
    particle_end_alpha = 1,
    particle_alpha_per_part = 0.8,
    particle_scale_per_part = 0.8,
    particle_loop_frame_count = 15,
    --particle_fade_out_threshold = 0.95,
    particle_fade_out_duration = 2, 
    particle_loop_exit_threshold = 0.25,
    special_neutral_target_damage = {amount = 1, type = "acid"},
    initial_action =
    {
      {
        type = "direct",
        action_delivery =
        {
		type = "instant",
          target_effects =
          {
            {
              type = "play-sound",
              sound =
              {
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-1.ogg",
                  volume = 1
                },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-2.ogg",
                  volume = 1
				  },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-long-1.ogg",
                  volume = 1
                },
                {
                  filename = "__base__/sound/creatures/projectile-acid-burn-long-2.ogg",
                  volume = 1
                }
              }
            },
            {
              type = "create-fire",
              entity_name = data.splash_fire_name,
              tile_collision_mask = { "water-tile" },
              show_in_tooltip = true			  
            },
			{
			  type = "create-entity",
			  entity_name = data.poison_cloud,
			 -- tile_collision_mask = { "water-tile" }
			},	
			{
			 type = "create-entity",
			 entity_name = "behemoth-toxic-spitter",
			 tile_collision_mask = { "water-tile" }			 
			 },
			{
			 type = "create-entity",
			 entity_name = "behemoth-toxic-biter",
			 tile_collision_mask = { "water-tile" }			 
			 },
          }
        }
      },
      {
        type = "area",
        radius = data.spit_radius,
        force = "enemy",
        ignore_collision_condition = true,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = data.sticker_name
            },
            {
              type = "damage",
              damage = {amount = 1, type = "acid"}
            }			
          }
        }
      }
    },
    particle = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-head.png",
      line_length = 5,
      width = 22,
      height = 84,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-head.png",
        line_length = 5,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    spine_animation = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-tail.png",
      line_length = 5,
      width = 66,
      height = 12,
      frame_count = 15,
      shift = util.mul_shift(util.by_pixel(0, -2), data.scale),
      tint = data.tint,
      priority = "high",
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-tail.png",
        line_length = 5,
        width = 132,
        height = 20,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(0, -1), data.scale),
        tint = data.tint,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },
    shadow = {
      filename = "__base__/graphics/entity/acid-projectile/acid-projectile-shadow.png",
      line_length = 15,
      width = 22,
      height = 84,
      frame_count = 15,
      priority = "high",
      shift = util.mul_shift(util.by_pixel(-2, 30), data.scale),
      draw_as_shadow = true,
      scale = data.scale,
      animation_speed = 1,
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-projectile/hr-acid-projectile-shadow.png",
        line_length = 15,
        width = 42,
        height = 164,
        frame_count = 15,
        shift = util.mul_shift(util.by_pixel(-2, 31), data.scale),
        draw_as_shadow = true,
        priority = "high",
        scale = 0.5 * data.scale,
        animation_speed = 1,
      }
    },

    oriented_particle = true,
    shadow_scale_enabled = true,
  }
end


function tb_acid_sticker(data)
  return
  {
    type = "sticker",
    name = data.name,
    flags = {"not-on-map"},
    animation =
    {
      filename = "__base__/graphics/entity/acid-sticker/acid-sticker.png",
      draw_as_glow = true,
      priority = "extra-high",
      line_length = 5,
      width = 16,
      height = 18,
      frame_count = 50,
      animation_speed = 0.5,
      tint = data.tint, 
      shift = util.by_pixel (2,0),
      hr_version =
      {
        filename = "__base__/graphics/entity/acid-sticker/hr-acid-sticker.png",
        draw_as_glow = true,
        line_length = 5,
        width = 30,
        height = 34,
        frame_count = 50,
        animation_speed = 0.5,
        tint = data.tint, -- #b6aa4abe
        shift = util.by_pixel(1.5, 0),
        scale = 0.5
      }
    },
    duration_in_ticks = data.slow_seconds * 60,
    target_movement_modifier_from = data.slow_player_movement,
    target_movement_modifier_to = 1,
    vehicle_speed_modifier_from = data.slow_vehicle_speed,
    vehicle_speed_modifier_to = 1,
    vehicle_friction_modifier_from = data.slow_vehicle_friction,
    vehicle_friction_modifier_to = 1,
  }
end

data:extend(
{
  
  tb_acid_sticker({
    name = "tb-fire-sticker",
    tint = biter_tint,
    slow_player_movement = 0.5,
    slow_vehicle_speed = 0.5,
    slow_vehicle_friction = 1.5,
    slow_seconds = 5
  }),
  
  acid_splash_fire({
    name = "tb-fire-splash-small",
    scale = small_scale,
    tint = biter_tint,
    ground_patch_scale = small_scale * ground_patch_scale_modifier,
    patch_tint_multiplier = patch_opacity,
    splash_damage_per_tick = 0.4,
    sticker_name = "tb-fire-sticker"
  }),

  fire_stream({
    name = "tb-fire-stream-small",
    scale = small_scale,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-small",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_1",
  }),

  ---big-
  
  acid_splash_fire({
    name = "tb-fire-splash-big",
    scale = big_scale,
    tint = biter_tint,
    ground_patch_scale = big_scale * ground_patch_scale_modifier,
    patch_tint_multiplier = patch_opacity,
    splash_damage_per_tick = 0.4,
    sticker_name = "tb-fire-sticker"
  }),

  fire_stream({
    name = "tb-fire-stream-big",
    scale = big_scale,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-big",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-big",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_3",
  }),


  fire_stream({
    name = "tb-fire-stream-boss",
    scale = boss_scale,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-big",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-big",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_5",
  }),

-- mother

  firemother_stream({
    name = "tb-firemother-stream-big",
    scale = big_scale+ 0.5,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-big",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-big",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_4",
  }),

  

  
  
  
  ---  WORMS 
  
  
  
    fire_stream({
    name = "tb-fire-stream-small-t",
    scale = stream_worm_scale,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-t",
    spit_radius = stream_radius_spitter_small,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-small",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_1",
  }),

  ---big-

  fire_stream({
    name = "tb-fire-stream-big-t",
    scale = stream_worm_scale+1,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_big,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-big",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_3",
  }),

-- mother

  firemother_stream({
    name = "tb-firemother-stream-big-t",
    scale = stream_worm_scale+1.4,
    tint = biter_tint,
    corpse_name = "tb-fire-splash-corpse-big-t",
    spit_radius = stream_radius_spitter_behemoth,
    particle_spawn_interval = 1,
    particle_spawn_timeout = 6,
    splash_fire_name = "tb-fire-splash-big",
    sticker_name = "tb-fire-sticker",
	poison_cloud = "tb_poison_cloud_4",
  }),

  
})


data.raw.fire['tb-fire-splash-small'].localised_name = {"entity-name.tb-fire-sticker"}
data.raw.fire['tb-fire-splash-big'].localised_name = {"entity-name.tb-fire-sticker"}

