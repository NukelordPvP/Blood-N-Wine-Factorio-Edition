local DAMAGE_S = settings.startup["tb-DamageScaler"].value
local color_1 = {r = 0.87, g = 0.4, b = 0.9, a = 0.7} --  {r = 0.239, g = 0.875, b = 0.992, a = 0.690}, -- #3ddffdb0,
local color_2 = {r = 0.7, g = 0.5, b = 1, a = 0.55} --  {r = 0.239, g = 0.875, b = 0.992, a = 0.690}, -- #3ddffdb0,

local dura  = 10

data:extend({
  {
    type = "smoke-with-trigger",
    name = "tb_poison-cloud-visual-dummy",
    flags = {"not-on-map"},
    show_when_smoke_off = true,
    particle_count = 10, --24
    particle_spread = { 3.6 * 1.05, 3.6 * 0.6 * 1.05 },
    particle_distance_scale_factor = 0.5,
    particle_scale_factor = { 1, 0.707 },
    particle_duration_variation = 60 * 3,
    wave_speed = { 0.5 / 80, 0.5 / 60 },
    wave_distance = { 1, 0.5 },
    spread_duration_variation = 300 - dura,

    render_layer = "object",

    affected_by_wind = false,
    cyclic = true,
    duration = 60 * dura + 3 * 60,
    fade_away_duration = 2 * 60,
    spread_duration = (300 - dura) / 2 ,
    color = color_2, -- #035b6452

    animation =
    {
      width = 152,
      height = 120,
      line_length = 5,
      frame_count = 60,
      shift = {-0.53125, -0.4375},
      priority = "high",
      animation_speed = 0.25,
      filename = "__base__/graphics/entity/smoke/smoke.png",
      flags = { "smoke" }
    },
    working_sound =
    {
      sound = sounds.poison_cloud(0.5),
      max_sounds_per_type = 1,
      audible_distance_modifier = 0.8,
      match_volume_to_activity = true
    }
  },

})



function tb_create_pcloud(level,damage,explosion_name)
local die = 
  {
    name = "tb_poison_die_cloud_"..level,
    type = "smoke-with-trigger",
    flags = {"not-on-map"},
    show_when_smoke_off = true,
    particle_count = 16,
    particle_spread = { 3.6 * 1.05, 3.6 * 0.6 * 1.05 },
    particle_distance_scale_factor = 0.5,
    particle_scale_factor = { 1, 0.707 },
    wave_speed = { 1/80, 1/60 },
    wave_distance = { 0.3, 0.2 },
    spread_duration_variation = 20,
    particle_duration_variation = 60 * 3,
    render_layer = "object",

    affected_by_wind = false,
    cyclic = true,
    duration = 60 * (dura + 2),
    fade_away_duration = 2 * 60,
    spread_duration = 20,
    color = color_1,


    animation =
    {
      width = 152,
      height = 120,
      line_length = 5,
      frame_count = 60,
      shift = {-0.53125, -0.4375},
      priority = "high",
      animation_speed = 0.25,
      filename = "__base__/graphics/entity/smoke/smoke.png",
      flags = { "smoke" }
    },
 
    created_effect =
    {
	 {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = explosion_name
          },
  
		}
	  }
	 },
     {
        type = "cluster",
        cluster_count = level*2,
        distance = level,
        distance_deviation = 0,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-smoke",
              show_in_tooltip = false,
              entity_name = "tb_poison-cloud-visual-dummy",
              initial_height = 0
            },
          }
        }
      }
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "nested-result",
          action =
          {
            type = "area",
            radius = level *1.5,
            entity_flags = {"breaths-air"},
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                type = "damage",
                damage = { amount = damage * DAMAGE_S, type = "poison"}
              }
            }
          }
        },
        
	
      }
    },
    action_cooldown = level * 4
  }
data:extend({die})

local cloud = 
  {
    name = "tb_poison_cloud_"..level,
    type = "smoke-with-trigger",
    flags = {"not-on-map"},
    show_when_smoke_off = true,
    particle_count = 16,
    particle_spread = { 3.6 * 1.05, 3.6 * 0.6 * 1.05 },
    particle_distance_scale_factor = 0.5,
    particle_scale_factor = { 1, 0.707 },
    wave_speed = { 1/80, 1/60 },
    wave_distance = { 0.3, 0.2 },
    spread_duration_variation = 20,
    particle_duration_variation = 60 * 3,
    render_layer = "object",

    affected_by_wind = false,
    cyclic = true,
    duration = 60 * (dura + 2),
    fade_away_duration = 2 * 60,
    spread_duration = 20,
    color = color_1,


    animation =
    {
      width = 152,
      height = 120,
      line_length = 5,
      frame_count = 60,
      shift = {-0.53125, -0.4375},
      priority = "high",
      animation_speed = 0.25,
      filename = "__base__/graphics/entity/smoke/smoke.png",
      flags = { "smoke" }
    },
 
    created_effect =
    {
     {
        type = "cluster",
        cluster_count = level*2,
        distance = level,
        distance_deviation = 0,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-smoke",
              show_in_tooltip = false,
              entity_name = "tb_poison-cloud-visual-dummy",
              initial_height = 0
            },
          }
        }
      }
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "nested-result",
          action =
          {
            type = "area",
            radius = level *1.5,
            entity_flags = {"breaths-air"},
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                type = "damage",
                damage = { amount = damage * DAMAGE_S, type = "poison"}
              }
            }
          }
        },
        
	
      }
    },
    action_cooldown = level * 4
  }
data:extend({cloud})
data.raw["smoke-with-trigger"]["tb_poison_cloud_"..level].localised_name = {"entity-name.poison-cloud"}
data.raw["smoke-with-trigger"]["tb_poison_die_cloud_"..level].localised_name = {"entity-name.poison-cloud"}
end


tb_create_pcloud(1,8,"small-biter-die")  
tb_create_pcloud(2,16,"medium-biter-die") 
tb_create_pcloud(3,32,"big-biter-die") 
tb_create_pcloud(4,50,"behemoth-biter-die")
tb_create_pcloud(5,80,"biter-spawner-die") 
