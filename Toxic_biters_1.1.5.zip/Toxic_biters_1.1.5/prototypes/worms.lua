require ("prototypes.values")
--require ("prototypes.worm-animations")

local tb_enemy_autoplace
local autoplace_vanilla = enemy_autoplace
local autoplace_temperature = require ("prototypes.enemy-autoplace")

if settings.startup["tb-disable-terrain-check"].value then
tb_enemy_autoplace = autoplace_vanilla
else
tb_enemy_autoplace = autoplace_temperature
end




if not settings.startup["tb-disable-worms"].value then


local leviathan_scale=2.5
local stream_small = "tb-fire-stream-small"
local stream_big = "tb-fire-stream-big"


data:extend(
{



  {
    type = "turret",
    name = "small-toxic-worm-turret",
    icon = "__base__/graphics/icons/small-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    order="b-tt-a",
    max_health = 200 *HEALTH_S,
    subgroup="enemies",
    resistances = poison_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.9, -0.8 }, {0.9, 0.8}},
    map_generator_bounding_box = {{-1.9, -1.8}, {1.9, 1.8}},
    selection_box = {{-0.9, -0.8 }, {0.9, 0.8}},
    shooting_cursor_size = 3,
    corpse = "small-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_1",
    dying_sound = sounds.worm_dying(0.8),
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_small, worm_tint),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_small, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_sound = sounds.worm_breath(0.8),
    prepared_animation = worm_prepared_animation(scale_worm_small, worm_tint),
    prepared_alternative_speed = 0.024,
    prepared_alternative_speed_secondary = 0.018,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_small, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_small, worm_tint),
    starting_attack_sound = sounds.worm_roars(0.75),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_small, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_small, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    integration = worm_integration(scale_worm_small),
    prepare_range = range_worm_small + prepare_range_worm_small,
    allow_turning_when_starting_attack = true,
	
    attack_parameters =
    {
      type = "stream",
      cooldown = 20 + 5,
      range = range_worm_small,--defined in demo-spitter-projectiles.lua
      damage_modifier = dmg_modifier_worm_small,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_medium, scale_worm_medium * scale_worm_stream),
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 *1.5, -- this is same as particle horizontal speed of flamethrower fire stream
      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "tb-fire-stream-small-t",
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },	
     autoplace = tb_enemy_autoplace.enemy_worm_autoplace(0),
    call_for_help_radius = 40
  },



  {
    type = "turret",
    name = "medium-toxic-worm-turret",
    icon = "__base__/graphics/icons/medium-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    order="b-tt-b",
    subgroup="enemies",
    max_health = 400*HEALTH_S,
    resistances = poison_resists,
    healing_per_tick = 0.015,
    collision_box = {{-1.1, -1.0}, {1.1, 1.0}},
    map_generator_bounding_box = {{-2.1, -2.0}, {2.1, 2.0}},
    selection_box = {{-1.1, -1.0}, {1.1, 1.0}},
    shooting_cursor_size = 3.5,
    rotation_speed = 1,
    corpse = "medium-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_2",
    dying_sound = sounds.worm_dying(1),

    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_medium, worm_tint),
    preparing_speed = 0.024,
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    preparing_animation = worm_preparing_animation(scale_worm_medium, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_medium, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    prepared_animation = worm_prepared_animation(scale_worm_medium, worm_tint),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_medium, worm_tint),
    starting_attack_sound = sounds.worm_roars(0.8),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_medium, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_medium, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    integration = worm_integration(scale_worm_medium),
    prepare_range = range_worm_medium + prepare_range_worm_medium,
    allow_turning_when_starting_attack = true,

    attack_parameters =
    {
      type = "stream",
      cooldown = 20 + 5,
      range = range_worm_medium,--defined in demo-spitter-projectiles.lua
      damage_modifier = dmg_modifier_worm_medium,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_medium, scale_worm_medium * scale_worm_stream),

      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 *1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_small,
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.3,
    autoplace = tb_enemy_autoplace.enemy_worm_autoplace(2),
    call_for_help_radius = 40
  },


  {
    type = "turret",
    name = "big-toxic-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 750*HEALTH_S,
    order="b-tt-c",
    subgroup="enemies",
    resistances = poison_resists,
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "big-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_3",
    dying_sound = sounds.worm_dying(1),

    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_big, worm_tint),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_big, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_big, worm_tint),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_big, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, worm_tint),
    starting_attack_sound = sounds.worm_roars(0.95),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(1),
    integration = worm_integration(scale_worm_big),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = range_worm_big + prepare_range_worm_big,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      damage_modifier = dmg_modifier_worm_big,
      cooldown = 20 + 5,
      range = range_worm_big,--defined in demo-spitter-projectiles.lua
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_big, scale_worm_big * scale_worm_stream),

      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_small,
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.5,
    autoplace = tb_enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },
  
  {
    type = "turret",
    name = "behemoth-toxic-worm-turret",
    icon = "__base__/graphics/icons/behemoth-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 1000*HEALTH_S,
    order="b-tt-d",
    subgroup="enemies",
    resistances = poison_resists,
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "behemoth-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_4",
    dying_sound = sounds.worm_dying(1.1),

    inventory_size = 2,

    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth, worm_tint),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth, worm_tint),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth, worm_tint),
    starting_attack_sound = sounds.worm_roars(0.95),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(1),
    integration = worm_integration(scale_worm_behemoth),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = range_worm_behemoth + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = dmg_modifier_worm_behemoth,
      cooldown = 20 + 5,
      range = range_worm_behemoth,--defined in demo-spitter-projectiles.lua
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth, scale_worm_behemoth * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_big,
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.9,
    autoplace = tb_enemy_autoplace.enemy_worm_autoplace(8),
    call_for_help_radius = 80
  },

  
  {
    type = "turret",
    name = "leviathan-toxic-worm-turret",
    icon = "__base__/graphics/icons/behemoth-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 1500*HEALTH_S,
    order="b-tt-e",
    subgroup="enemies",
    resistances = poison_resists,
    healing_per_tick = 0.02,
    collision_box = {{-2, -2}, {2, 2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-2, -2}, {2, 2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "leviathan-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_5",
    dying_sound = sounds.worm_dying(1.5),
    inventory_size = 2,
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth+1, worm_tint),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth+1, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(1),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth+1, worm_tint),
    prepared_sound = sounds.worm_breath(2),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth+1, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth+1, worm_tint),
    starting_attack_sound = sounds.worm_roars(2),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth+1, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth+1, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(2),
    integration = worm_integration(scale_worm_behemoth+1),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = 60  + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = dmg_modifier_worm_leviathan,
      cooldown = 20 + 6,
      range = 60,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth+1, (scale_worm_behemoth+1) * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = stream_big,
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.94,
    autoplace = tb_enemy_autoplace.enemy_worm_autoplace(8),
    call_for_help_radius = 100
  },
  
  
  
  
 


---- corpses

  {
    type = "corpse",
    name = "small-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_small, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_small)}
  },

  {
    type = "corpse",
    name = "medium-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_medium, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_medium)}
  },
  {
    type = "corpse",
    name = "big-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_big, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_big)}
  },
  {
    type = "corpse",
    name = "behemoth-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-d[behemoth]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth)}
  },
  {
    type = "corpse",
    name = "leviathan-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-e[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth+1, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth+1)}
  },


  
})




if not settings.startup["tb-disable-mother"].value then
data:extend(
{
  
  {
    type = "turret",
    name = "mother-toxic-worm-turret",
    icon = "__base__/graphics/icons/behemoth-worm.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 2000*HEALTH_S,
    order="b-tt-m",
    subgroup="enemies",
    resistances = poison_resists,
    healing_per_tick = 0.02,
    collision_box = {{-2, -2}, {2, 2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    selection_box = {{-2, -2}, {2, 2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "mother-toxic-worm-corpse",
    dying_explosion = "tb_poison_die_cloud_5",
    dying_sound = sounds.worm_dying(2),
    inventory_size = 2,
    folded_speed = 0.01,
    folded_speed_secondary = 0.024,
    folded_animation = worm_folded_animation(scale_worm_behemoth+2, worm_tint),
    preparing_speed = 0.024,
    preparing_animation = worm_preparing_animation(scale_worm_behemoth+2, worm_tint, "forward"),
    preparing_sound = sounds.worm_standup(2),
    prepared_speed = 0.024,
    prepared_speed_secondary = 0.012,
    prepared_animation = worm_prepared_animation(scale_worm_behemoth+2, worm_tint),
    prepared_sound = sounds.worm_breath(0.8),
    prepared_alternative_speed = 0.014,
    prepared_alternative_speed_secondary = 0.010,
    prepared_alternative_chance = 0.2,
    prepared_alternative_animation = worm_prepared_alternative_animation(scale_worm_behemoth+2, worm_tint),
    prepared_alternative_sound = sounds.worm_roar_alternative(0.8),
    starting_attack_speed = 0.034,
    starting_attack_animation = worm_start_attack_animation(scale_worm_behemoth+2, worm_tint),
    starting_attack_sound = sounds.worm_roars(2),
    ending_attack_speed = 0.016,
    ending_attack_animation = worm_end_attack_animation(scale_worm_behemoth+2, worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_behemoth+2, worm_tint, "backward"),
    folding_sound = sounds.worm_fold(2),
    integration = worm_integration(scale_worm_behemoth+2),
    secondary_animation = true,
    random_animation_offset = true,
    attack_from_start_frame = true,

    prepare_range = 70  + prepare_range_worm_behemoth,
    allow_turning_when_starting_attack = true,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = dmg_modifier_worm_mother,
      cooldown = 20 + 300,
      range = 70,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(scale_worm_behemoth+2, (scale_worm_behemoth+2) * scale_worm_stream),
      use_shooter_direction = true,

      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream

      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "tb-firemother-stream-big-t",
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.98,
    autoplace = tb_enemy_autoplace.enemy_worm_autoplace(12),
    call_for_help_radius = 100
  },


  {
    type = "corpse",
    name = "mother-toxic-worm-corpse",
    icon = "__base__/graphics/icons/medium-worm-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-tt[worm]-m[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    time_before_removed = 15 * 60 * 60,
    final_render_layer = "lower-object-above-shadow",
    animation = worm_die_animation(scale_worm_behemoth+2, worm_tint),
    ground_patch = {sheet = worm_integration(scale_worm_behemoth+2)}
  },
})
end



end