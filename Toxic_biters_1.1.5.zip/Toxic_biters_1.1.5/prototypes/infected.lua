



--------------------------------------------------------------------------------------
local infected_ship = table.deepcopy(data.raw["unit-spawner"]["biter-spawner"])
infected_ship.name="tb_infected_ship"
infected_ship.corpse = nil
infected_ship.autoplace = nil 
infected_ship.result_units = table.deepcopy(data.raw["unit-spawner"]["toxic-biter-spawner"].result_units)
infected_ship.icons={{icon=path .. "/graphics/toxic-spawner-icon.png", icon_size=64},{icon="__base__/graphics/icons/crash-site-spaceship.png", icon_size=64, tint=icon_tint}}
infected_ship.icon="__base__/graphics/icons/crash-site-spaceship.png"
infected_ship.collision_box = {{-8.7, -3.3}, {6.9, 4.5}}
infected_ship.map_generator_bounding_box = {{-8.7, -3.3}, {6.9, 4.5}}
infected_ship.selection_box = {{-8.7, -3.3}, {6.9, 4.5}}
infected_ship.dying_explosion = "nuke-explosion"
infected_ship.max_health = 1000
infected_ship.animations =
{
	{
layers =
      {
        {
            filename = path .. "/graphics/infected/hr-spaceship-infection.png",
            priority = "very-low",
            width = 1228,
            height = 790,
            shift = util.by_pixel(-13, 34),
            dice_x = 4,
            dice_y = 3,
            scale = 0.5
        },
        {
            filename = "__base__/graphics/entity/crash-site-spaceship/hr-spaceship-shadow.png",
            priority = "very-low",
            width = 1340,
            height = 842,
            shift = util.by_pixel(-23, 50),
            scale = 0.5,
            dice_x = 5,
            dice_y = 4,
            draw_as_shadow = true
        }
      }
	}
}
infected_ship.integration = table.deepcopy(data.raw["container"]["crash-site-spaceship"].integration_patch)
infected_ship.vehicle_impact_sound = sounds.generic_impact
data:extend({infected_ship})


-- boss spaceship
local infected_ship = table.deepcopy(data.raw["unit-spawner"]["tb_infected_ship"])
infected_ship.name="tb_infected_ship_boss"
infected_ship.max_health = 100000
local ru = {}
for k=1,10 do 
	table.insert (ru, {'maf-boss-toxic-biter-'..k, {{k/10 - 0.05, 0.0}, {k/10, 0.1}}})
	table.insert (ru, {'maf-boss-toxic-spitter-'..k, {{k/10 - 0.05, 0.0}, {k/10, 0.1}}})
	end
infected_ship.result_units = ru
data:extend({infected_ship})





 ----------------------------------------------------------------------------
 --
 -- PLAYER's BUILDINGS INFECTION
 --
 ----------------------------------------------------------------------------
function re_add_vanilla_icon(raw,icon)
raw.icon=icon
raw.icon_size=64
raw.icon_mipmaps = 4
end

if settings.startup["tb-allow-infection"].value then


local gun_turret = table.deepcopy(data.raw["ammo-turret"]["gun-turret"])
gun_turret.name='tb_infected_gun_turret'
re_add_vanilla_icon(gun_turret,"__base__/graphics/icons/gun-turret.png")
gun_turret.icons={{icon=path .. "/graphics/toxic-spawner-icon.png", icon_size=64},{icon=gun_turret.icon, icon_size=gun_turret.icon_size, tint=icon_tint}}
gun_turret.flags = {"placeable-player", "placeable-enemy", "not-repairable"}
gun_turret.attack_parameters.ammo_consumption_modifier = 0 -- does not consume ammo
gun_turret.attack_parameters.damage_modifier = 1 + DAMAGE_S
gun_turret.max_health = gun_turret.max_health * HEALTH_S
--hack_tint(gun_turret, biter_back_tint)
gun_turret.base_picture =     {
      layers =
      {
        {
            filename = path .. "/graphics/infected/hr-gun-turret-base-infection.png",
            priority = "high",
            width = 150,
            height = 118,
            axially_symmetrical = false,
            direction_count = 1,
            frame_count = 1,
            shift = util.by_pixel(0.5, -1),
            scale = 0.5
        },
        {
            filename = "__base__/graphics/entity/gun-turret/hr-gun-turret-base-mask.png",
            flags = { "mask", "low-object" },
            line_length = 1,
            width = 122,
            height = 102,
            axially_symmetrical = false,
            direction_count = 1,
            frame_count = 1,
            shift = util.by_pixel(0, -4.5),
            apply_runtime_tint = true,
            scale = 0.5
        }
      }
    }
data:extend({gun_turret})








local laser_turret = table.deepcopy(data.raw["electric-turret"]["laser-turret"])
laser_turret.name='tb_infected_laser_turret'
re_add_vanilla_icon(laser_turret,"__base__/graphics/icons/laser-turret.png")
laser_turret.icons={{icon=path .. "/graphics/toxic-spawner-icon.png", icon_size=64},{icon=laser_turret.icon, icon_size=laser_turret.icon_size, tint=icon_tint}}
laser_turret.flags = {"placeable-player", "placeable-enemy", "not-repairable"}
laser_turret.attack_parameters.ammo_type.energy_consumption = "0kJ"
laser_turret.attack_parameters.damage_modifier = 3 * DAMAGE_S
laser_turret.max_health = laser_turret.max_health * HEALTH_S
laser_turret.void_energy_source =
    {
      type = "electric",
      buffer_capacity = "801kJ",
      input_flow_limit = "9600kW",
      drain = "24kW",
      usage_priority = "primary-input"
    }
hack_tint(laser_turret, biter_back_tint)
laser_turret.base_picture = {
      layers =
      {
        {
            filename = path .. "/graphics/infected/hr-laser-turret-base-infection.png",
            priority = "high",
            width = 138,
            height = 104,
            direction_count = 1,
            frame_count = 1,
            shift = util.by_pixel(-0.5, 2),
            scale = 0.5
        },
        {
            filename = "__base__/graphics/entity/laser-turret/hr-laser-turret-base-shadow.png",
            line_length = 1,
            width = 132,
            height = 82,
            draw_as_shadow = true,
            direction_count = 1,
            frame_count = 1,
            shift = util.by_pixel(6, 3),
            scale = 0.5
        }
      }
    }
data:extend({laser_turret})





--------------------------------------------------------------------------------------
local infected_radar = table.deepcopy(data.raw["unit-spawner"]["biter-spawner"])
infected_radar.name="tb_infected_radar"
infected_radar.autoplace = nil 
re_add_vanilla_icon(infected_radar,"__base__/graphics/icons/radar.png")
infected_radar.icons={{icon=path .. "/graphics/toxic-spawner-icon.png", icon_size=64},{icon=data.raw.radar.radar.icon, icon_size=data.raw.radar.radar.icon_size, tint=icon_tint}}
infected_radar.max_health = 300
infected_radar.result_units = table.deepcopy(data.raw["unit-spawner"]["toxic-biter-spawner"].result_units)
infected_radar.collision_box = data.raw.radar.radar.collision_box
infected_radar.selection_box = data.raw.radar.radar.selection_box
infected_radar.corpse = "radar-remnants"
infected_radar.animations =
{
	{
layers =
      {
        {
            filename = path .. "/graphics/infected/hr-infected_radar.png",
            priority = "very-low",
            width = 357,
            height = 272,
            --shift = util.by_pixel(-13, 34),
            --dice_x = 4,
            --dice_y = 3,
            scale = 0.5,
			animation_speed = 0.18,
			direction_count = 1,			
        },
      }
	}
}
infected_radar.integration = table.deepcopy(data.raw["unit-spawner"]["toxic-biter-spawner"].integration)
data:extend({infected_radar})







local arty_turret = table.deepcopy(data.raw["artillery-turret"]["artillery-turret"])
arty_turret.name='tb_infected_artillery_turret'
re_add_vanilla_icon(arty_turret,"__base__/graphics/icons/artillery-turret.png")
arty_turret.icons={{icon=path .. "/graphics/toxic-spawner-icon.png", icon_size=64},{icon=arty_turret.icon, icon_size=arty_turret.icon_size, tint=icon_tint}}
arty_turret.flags = {"placeable-player", "placeable-enemy", "not-repairable"}
arty_turret.ammo_stack_limit = 100
hack_tint(arty_turret, biter_back_tint)
arty_turret.base_picture =
    {
      layers =
      {
        {
          filename = path .. "/graphics/infected/hr-artillery-turret-base-infection.png",
            priority = "high",
            line_length = 1,
            width = 207,
            height = 199,
            frame_count = 1,
            direction_count = 1,
            shift = util.by_pixel(-0, 22),
            scale = 0.5
        },
        {
            filename = "__base__/graphics/entity/artillery-turret/hr-artillery-turret-base-shadow.png",
            priority = "high",
            line_length = 1,
            width = 277,
            height = 149,
            frame_count = 1,
            direction_count = 1,
            shift = util.by_pixel(18, 38),
            draw_as_shadow = true,
            scale = 0.5
        }
      }
    }
data:extend({arty_turret})
end
