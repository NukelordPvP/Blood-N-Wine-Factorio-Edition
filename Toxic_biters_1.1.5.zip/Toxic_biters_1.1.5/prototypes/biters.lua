require ("prototypes.values")
require ("prototypes.tb-biter-animations")
require ("prototypes.tb-spawner-animation")

local effects = require("__base__/prototypes/entity/biter-die-effects.lua")


local tb_enemy_autoplace
local autoplace_vanilla = enemy_autoplace
local autoplace_temperature = require ("prototypes.enemy-autoplace")

if settings.startup["tb-disable-terrain-check"].value then
tb_enemy_autoplace = autoplace_vanilla
else
tb_enemy_autoplace = autoplace_temperature
end


local small_biter_scale = 0.55
local medium_biter_scale = 0.8
local big_biter_scale = 1.05
local behemoth_biter_scale = 1.25
local leviathan_scale=2.65




local small_biter_tint =    {r=0.6, g=0.5, b=0.4, a=0.6}  --{r=0.60, g=0.58, b=0.51, a=a}    -- {r=0.5, g=0.9, b=0.5, a=0.7}
local medium_biter_tint =   {r=0.85, g=0.4, b=0.3, a=0.7}  --{r=0.49, g=0.46, b=0.51, a=a}   --{r=0.9, g=0.9, b=0.5, a=0.7}
local big_biter_tint =      {r=0.1, g=0.5, b=0.65, a=0.6}  -- {r=0.37, g=0.40, b=0.72, a=a}  --{r=0.9, g=0.5, b=0.1, a=0.7}
local behemoth_biter_tint = {r=0.5, g=0.9, b=0.5, a=0.7}   --{r=0.21, g=0.19, b=0.25, a=a}  --{r=0.85, g=0.4, b=0.3, a=0.7}
local leviathan_tint=       {r=0.85, g=0.25, b=0.7, a=0.7}





local function make_biter_area_damage(damage,radius)
return  {
					type = "area",
					radius = radius,
					force = "enemy",
					ignore_collision_condition = true,
					action_delivery =
					{
					  type = "instant",
					  target_effects =
					  {
						{
						  type = "damage",
						  damage = {amount = damage, type = "physical"}
						},
						{
						type = "create-particle",
						repeat_count = 5,
						particle_name = "explosion-remnants-particle",
						initial_height = 0.5,
						speed_from_center = 0.08,
						speed_from_center_deviation = 0.15,
						initial_vertical_speed = 0.08,
						initial_vertical_speed_deviation = 0.15,
						offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
						},
					  }
					}
                   }
end


data:extend(
{

 {
    type = "unit",
    name = "small-toxic-biter",
    icon = path .. "/graphics/toxic-biter-icon.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "not-repairable", "breaths-air"},
    max_health = 15*HEALTH_S,
    order = "b-t-a",
    subgroup="enemies",
    resistances =poison_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.7}, {0.7, 0.4}},
    attack_parameters =
    {
      type = "projectile",
      range = 0.5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(8*DAMAGE_S),
      sound = sounds.biter_roars(0.4),
      animation = tb_biterattackanimation(small_biter_scale, small_biter_tint, biter_back_tint),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.2,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 4,
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    corpse = "small-toxic-biter-corpse",
    dying_explosion = "tb_poison_die_cloud_1", --"blood-explosion-small",

    working_sound = table.deepcopy(data.raw['unit']['small-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['small-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['small-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(small_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['small-biter'].damaged_trigger_effect),
    run_animation = tb_biterrunanimation(small_biter_scale, small_biter_tint, biter_back_tint),
	ai_settings = biter_ai_settings,
  },

  
  tb_add_biter_die_animation(small_biter_scale, small_biter_tint, biter_back_tint,
  {
    type = "corpse",
    name = "small-toxic-biter-corpse",
    icon = "__base__/graphics/icons/small-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-ta[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
  }),
	  
  
  
  {
    type = "unit",
    name = "medium-toxic-biter",
    icon = path .. "/graphics/toxic-biter-icon.png",    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 75*HEALTH_S,
    order="b-t-b",
    subgroup="enemies",
    resistances =poison_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(16*DAMAGE_S),
      range = 1,
      cooldown = 35,
      sound = sounds.biter_roars(0.5),
      animation = tb_biterattackanimation(medium_biter_scale, medium_biter_tint, biter_back_tint),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.185,
    distance_per_frame = 0.15,
    -- in pu
    pollution_to_join_attack = 20,
    corpse = "medium-toxic-biter-corpse",
    dying_explosion = "tb_poison_die_cloud_2", --"blood-explosion-small",
    working_sound = table.deepcopy(data.raw['unit']['medium-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['medium-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['medium-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(medium_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['medium-biter'].damaged_trigger_effect),

    run_animation = tb_biterrunanimation(medium_biter_scale, medium_biter_tint, biter_back_tint),
	ai_settings = biter_ai_settings,
  },

  {
    type = "unit",
    name = "big-toxic-biter",
    order="b-t-c",
    icon = path .. "/graphics/toxic-biter-icon.png",    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 375*HEALTH_S,
    subgroup="enemies",
    resistances =poison_resists,
    spawning_time_modifier = 3,
    healing_per_tick = 0.02,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.6, -0.8}, {0.6, 0}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      range = 1.5,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = make_unit_melee_attack_type(30*DAMAGE_S),
      sound =  sounds.biter_roars(0.6),
      animation = tb_biterattackanimation(big_biter_scale, big_biter_tint, biter_back_tint),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 80,
    corpse = "big-toxic-biter-corpse",
    dying_explosion = "tb_poison_die_cloud_3", --"blood-explosion-big",
    working_sound = table.deepcopy(data.raw['unit']['big-biter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['big-biter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['big-biter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(big_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['big-biter'].damaged_trigger_effect),
    run_animation = tb_biterrunanimation(big_biter_scale, big_biter_tint, biter_back_tint),
	ai_settings = biter_ai_settings,
  },

  {
    type = "unit",
    name = "behemoth-toxic-biter",
    order="b-t-d",
    icon = path .. "/graphics/toxic-biter-icon.png",    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 3000*HEALTH_S,
    subgroup="enemies",
    resistances =poison_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
    sticker_box = {{-0.6, -0.8}, {0.6, 0}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
            attack_parameters =
                {
                    type = "projectile",
                    range = 2,
                    cooldown = 50,
                    sound =  sounds.biter_roars_behemoth(0.8),
                    animation = tb_biterattackanimation(behemoth_biter_scale, behemoth_biter_tint, biter_back_tint),
										ammo_type = {
							  category = "melee",
							  target_type = "entity",
								action = {
								  {
								  action_delivery = {
									target_effects = {
									  damage = {
										amount = (100*DAMAGE_S),
										type = "physical"
									  },
									  type = "damage",
									  show_in_tooltip = true
									},
									type = "instant"
								  },
								  type = "direct"
								  },
								  make_biter_area_damage(50*DAMAGE_S,1),
								  },
							}		
                },	
	
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 400,
    corpse = "behemoth-toxic-biter-corpse",
    dying_explosion = "tb_poison_die_cloud_4",-- "blood-explosion-big",
    working_sound = sounds.biter_calls_big(1.0),
    dying_sound = sounds.biter_dying_big(0.7),
    walking_sound = sounds.biter_walk_big(0.8),
    running_sound_animation_positions = {2,},
	water_reflection = biter_water_reflection(behemoth_biter_scale),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
    run_animation = tb_biterrunanimation(behemoth_biter_scale, behemoth_biter_tint, biter_back_tint),
	ai_settings = biter_ai_settings,
  },
 
  tb_add_biter_die_animation(medium_biter_scale, medium_biter_tint, biter_back_tint,
  {
    type = "corpse",
    name = "medium-toxic-biter-corpse",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-tb[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),  
  
  tb_add_biter_die_animation(big_biter_scale, big_biter_tint, biter_back_tint,
  {
    type = "corpse",
    name = "big-toxic-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-tc[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),  
  
  
  tb_add_biter_die_animation(behemoth_biter_scale, behemoth_biter_tint, biter_back_tint,
  {
    type = "corpse",
    name = "behemoth-toxic-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-td[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),  
  
   {
    type = "unit",
    name = "leviathan-toxic-biter",
    order="b-t-e",
    icon = path .. "/graphics/toxic-biter-icon.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 80000*HEALTH_S,
    subgroup="enemies",
    resistances = leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.2, -2.4}, {1.2, 0.9}},
    sticker_box = {{-1.2, -2}, {1.2, 0}},
    distraction_cooldown = 300,
    loot =
    {
    },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
    {
      type = "projectile",
      range = 3,
      cooldown = 35,
      ammo_category = "melee",
      ammo_type = 
      {
        category = "melee",
        target_type = "entity",
        action =
        {
		   make_biter_area_damage(100*DAMAGE_S,3),
          {
		  type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              {
                type = "damage",
                damage = { amount = 50 * DAMAGE_S, type = "physical"}
              },
              {
                type = "damage",
                damage = { amount = 50 * DAMAGE_S, type = "poison"}
              },
            }
          }}
        }
      },
      sound =  sounds.biter_roars(0.9),
      animation = tb_biterattackanimation(leviathan_scale, leviathan_tint, biter_back_tint),
	  range_mode = "bounding-box-to-bounding-box"
    },
    vision_distance = 50,
    movement_speed = 0.2,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 1000,
    corpse = "leviathan-toxic-biter-corpse",
    dying_explosion = "tb_poison_die_cloud_5",
    working_sound = sounds.biter_calls_big(1.4),
    dying_sound = sounds.biter_dying_big(1),
    walking_sound = sounds.biter_walk_big(1.2),
	running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
	water_reflection = biter_water_reflection(leviathan_scale),	
    run_animation = tb_biterrunanimation(leviathan_scale, leviathan_tint, biter_back_tint),
	ai_settings = biter_ai_settings,
  },

  
  tb_add_biter_die_animation(leviathan_scale, leviathan_tint, biter_back_tint,
  {
    type = "corpse",
    name = "leviathan-toxic-biter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-te[lev]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),  
    

 
  
  --------------
  --- NEST
 
  {
    type = "unit-spawner",
    name = "toxic-biter-spawner",
    icon = path .. "/graphics/toxic-spawner-icon.png",
    icon_size = 64, --icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "not-repairable"},
    max_health = 800*HEALTH_S,
    order="b-tsp-a",
    subgroup="enemies",
    resistances = nest_resists,
    working_sound = {
      sound =
      {
        {
          filename = "__base__/sound/creatures/spawner.ogg",
          volume = 1.0
        }
      },
      apparent_volume = 2
    },
    dying_sound =
    {
      {
        filename = "__base__/sound/creatures/spawner-death-1.ogg",
        volume = 1.0
      },
      {
        filename = "__base__/sound/creatures/spawner-death-2.ogg",
        volume = 1.0
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-3.2, -2.2}, {2.2, 2.2}},
    map_generator_bounding_box = {{-4.2, -3.2}, {3.2, 3.2}},
    selection_box = {{-3.5, -2.5}, {2.5, 2.5}},
    -- in ticks per 1 pu
    pollution_absorption_absolute = 20,
    pollution_absorption_proportional = 0.01,	
    corpse = "toxic-biter-spawner-corpse",
    dying_explosion ="blood-explosion-huge",
    max_count_of_owned_units = 10,
    max_friends_around_to_spawn = 7,
    animations = tb_spawner_idle_animation(),
    result_units = (function()
                     local res = {}
                     res[1] = {"small-toxic-biter", {{0.0, 0.3}, {0.6, 0.0}}}
					 res[2] = {"medium-toxic-biter", {{0.2, 0.0}, {0.6, 0.3}, {0.7, 0.1}}}
                     res[3] = {"small-toxic-spitter", {{0.25, 0.0}, {0.5, 0.3}, {0.7, 0.0}}}
					 res[4] = {"medium-toxic-spitter", {{0.4, 0.0}, {0.7, 0.3}, {0.9, 0.1}}}
                     res[5] = {"big-toxic-biter", {{0.5, 0.0}, {1.0, 0.4}}}
					 res[6] = {"big-toxic-spitter", {{0.5, 0.0}, {1.0, 0.4}}}
                     res[7] = {"behemoth-toxic-biter", {{0.9, 0.0}, {1.0, 0.3}}}
					 res[8] = {"behemoth-toxic-spitter", {{0.9, 0.0}, {1.0, 0.3}}}
					 res[9] = {"leviathan-toxic-biter", {{0.965, 0.0}, {1.0, 0.03}}}
					 res[10]= {"leviathan-toxic-spitter", {{0.965, 0.0}, {1.0, 0.03}}}
					 if not settings.startup["tb-disable-mother"].value then
						res[11]= {"mother-toxic-spitter", {{0.98, 0.0}, {1.0, 0.02}}} end
                     return res
                   end)(),
    -- With zero evolution the spawn rate is 6 seconds, with max evolution it is 2.5 seconds
    spawning_cooldown = {360, 150},
    spawning_radius = 10,
    spawning_spacing = 3,
    max_spawn_shift = 0,
    max_richness_for_spawn_shift = 100,
    autoplace = tb_enemy_autoplace.enemy_spawner_autoplace(0),
    damaged_trigger_effect = table.deepcopy(data.raw['unit-spawner']['biter-spawner'].damaged_trigger_effect),
    call_for_help_radius = 50,
    integration =
    {
      sheet = tb_spawner_integration()
    },	
  },


  {
    type = "corpse",
    name = "toxic-biter-spawner-corpse",
    flags = {"placeable-neutral", "placeable-off-grid", "not-on-map"},
    icon = "__base__/graphics/icons/biter-spawner-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    collision_box = {{-2, -2}, {2, 2}},
    selection_box = {{-2, -2}, {2, 2}},
    selectable_in_game = false,
    dying_speed = 0.03,--4
    time_before_removed = 15 * 60 * 60,
    subgroup="corpses",
    order = "c[corpse]-ts[toxic-spawner]-te",
    final_render_layer = "remnants",
    animation =tb_spawner_die_animation(),
    ground_patch =
    {
      sheet = tb_spawner_integration() --spawner_integration()
    }	
  },
 
  
 
  
	}
)