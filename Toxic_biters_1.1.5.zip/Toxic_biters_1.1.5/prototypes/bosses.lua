require ("tb-biter-animations")

local sounds = require("__base__/prototypes/entity/sounds.lua")

local leviathan_tint=       {r=0.85, g=0.25, b=0.7, a=0.7}

local HEALTH_S = settings.startup["tb-HealthScaler"].value
local DAMAGE_S = settings.startup["tb-DamageScaler"].value

local function make_biter_area_damage(damage,radius)
return  {
					type = "area",
					radius = radius,
					force = "enemy",
					ignore_collision_condition = true,
					action_delivery =
					{
					  type = "instant",
					  target_effects =
					  {
						{
						  type = "damage",
						  damage = {amount = damage, type = "physical"}
						},
						{
						type = "create-particle",
						repeat_count = 5,
						particle_name = "explosion-remnants-particle",
						initial_height = 0.5,
						speed_from_center = 0.08,
						speed_from_center_deviation = 0.15,
						initial_vertical_speed = 0.08,
						initial_vertical_speed_deviation = 0.15,
						offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
						},
					  }
					}
                   }
end




function make_boss(k)
local scale = 1.5 + k/3
local base_resist = 17+k*2
local resistances =  
    {
      {
        type = "physical",
        decrease = k,
        percent = base_resist,
      },
      {
        type = "explosion",
        decrease = k,
        percent = base_resist,
      },
      {
        type = "laser",
        percent = -230+k,
      },
      {
        type = "impact",
        percent = base_resist,
      },

      {
        type = "fire",
        percent = base_resist,
      },
      {
        type = "electric",
        percent = -50+k,
      },
      {
        type = "poison",
        percent = 100,
      },
      {
        type = "acid",
        percent = 100,
      },
    }
	
data:extend(
{


  {
    type = "unit",
    name = "maf-boss-toxic-biter-"..k,
	localised_name =  {"",{"entity-name.maf-boss-toxic-biter"}," ",k},
    order="b-t-d-BOSS"..k,
    icon = path .. "/graphics/toxic-biter-icon.png",    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000 * k * HEALTH_S,
    subgroup="enemies",
    resistances = resistances,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.7, -2.4}, {1.7, 2.4}},
    sticker_box = {{-0.7, -1.2}, {0.7, 0.2}},
    distraction_cooldown = 100,
	call_for_help_radius = 100+k*5,	
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
            attack_parameters =
                {
                    type = "projectile",
                    range = 1+k/5,
                    cooldown = 35,
                    sound =  sounds.biter_roars_behemoth(0.9),
                    animation = tb_biterattackanimation(scale, leviathan_tint, biter_back_tint),
										ammo_type = {
							  category = "melee",
							  target_type = "entity",
								action = {
								  {
								  action_delivery = {
									target_effects = {
									  damage = {
										amount = (100+k*40 * DAMAGE_S),
										type = "physical"
									  },
									  type = "damage",
									  show_in_tooltip = true
									},
									type = "instant"
								  },
								  type = "direct"
								  },
								  make_biter_area_damage((50+k*10)* DAMAGE_S,k+1),
								  },
							}		
                },	
	
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 300,
    corpse = "corpse-maf-boss-toxic-biter-"..k,
    dying_explosion = "tb_poison_die_cloud_4",-- "blood-explosion-big",
    working_sound = sounds.biter_calls_big(1.4),
    dying_sound = sounds.biter_dying_big(1),
    walking_sound = sounds.biter_walk_big(1.2),
	running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
	water_reflection = biter_water_reflection(scale),	
    run_animation = tb_biterrunanimation(scale, leviathan_tint, biter_back_tint),
	ai_settings = {destroy_when_commands_fail = false}
  },
 
  tb_add_biter_die_animation(scale, leviathan_tint, biter_back_tint,
  {
    type = "corpse",
    name = "corpse-maf-boss-toxic-biter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1, -1}, {1, 1}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-a[biter]-tb[medium]-BOSS"..k,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),



 
  {
    type = "unit",
    name = "maf-boss-toxic-spitter-"..k,
	localised_name =  {"",{"entity-name.maf-boss-toxic-spitter"}," ",k},
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health =  30000*k *HEALTH_S,
    order="b-ts-e-BOSS"..k,	
    subgroup="enemies",
	resistances = resistances,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
	collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{-3.4, -3.4}, {3.4, 3.4}},
	sticker_box = {{-0.4, -0.6}, {0.4, 0.2}},
    distraction_cooldown = 100,
    loot =  { },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = "tb-fire-stream-boss",
      range=40+k*2,
      min_attack_distance=10,
      cooldown=130-k*3,
	  cooldown_deviation = 0.15,
      damage_modifier=12+k*4*DAMAGE_S,
      scale=scale,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"	  

    }),	
	vision_distance = 80+k,
    movement_speed = 0.07+ k/150,
    distance_per_frame = 0.04,
    pollution_to_join_attack = 400,
    corpse = "corpse-maf-boss-toxic-spitter-"..k,
    dying_explosion = "tb_poison_die_cloud_5",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale, biter_tint, biter_tint2),
	ai_settings = {destroy_when_commands_fail = false}
  },


  add_spitter_die_animation(scale,biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "corpse-maf-boss-toxic-spitter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-e[leviathan]-BOSS"..k,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.01,
  }),   


  
})
end


for k=1,10 do make_boss(k) end