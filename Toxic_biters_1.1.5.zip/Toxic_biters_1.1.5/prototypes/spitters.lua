require ("prototypes.values")


scale_spitter_small    = 0.5
scale_spitter_medium   = 0.7
scale_spitter_big      = 1.0
scale_spitter_behemoth = 1.2
leviathan_scale=2.5


local stream_small = "tb-fire-stream-small"
local stream_big = "tb-fire-stream-big"


data:extend(
{

   {
    type = "unit",
    name = "small-toxic-spitter",
    icon = "__base__/graphics/icons/small-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 10*HEALTH_S,
    order="b-ts-a",
    subgroup="enemies",
	resistances =poison_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
    attack_parameters = spitter_attack_parameters(
    {
      acid_stream_name = stream_small,
      range=range_spitter_small,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_small,
      scale=scale_spitter_small,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=0.4,
	  range_mode = "bounding-box-to-bounding-box"
    }),
    vision_distance = 30,
    movement_speed = 0.185,
    distance_per_frame = 0.04,
    -- in pu
    pollution_to_join_attack = 4,
    corpse = "small-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_1",
    working_sound = sounds.spitter_calls(0.7),
    dying_sound = sounds.spitter_dying(0.4),
    walking_sound = sounds.spitter_walk(0.3),	
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['small-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_small),
    run_animation = spitterrunanimation(scale_spitter_small, biter_tint, biter_tint2),
    ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "medium-toxic-spitter",
    icon = "__base__/graphics/icons/medium-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50*HEALTH_S,
    order="b-ts-b",
    subgroup="enemies",
	resistances =poison_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.7}, {0.5, 0.7}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
    attack_parameters = spitter_mid_attack_parameters(
    {
      acid_stream_name = stream_small,
      range=range_spitter_medium,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_medium,
      scale=scale_spitter_medium,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=0.4,
	  range_mode = "bounding-box-to-bounding-box"
    }),
    vision_distance = 30,
    movement_speed = 0.165,
    distance_per_frame = 0.055,
    -- in pu
    pollution_to_join_attack = 12,
    corpse = "medium-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_2",
    working_sound = table.deepcopy(data.raw['unit']['medium-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['medium-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['medium-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['medium-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_medium),	
    run_animation = spitterrunanimation(scale_spitter_medium, biter_tint, biter_tint2),
	ai_settings = biter_ai_settings
  },

  
  {
    type = "unit",
    name = "big-toxic-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 200*HEALTH_S,
    order="b-ts-c",
    subgroup="enemies",
	resistances =poison_resists,
    spawning_time_modifier = 3,
    healing_per_tick = 0.01,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
    attack_parameters = spitter_big_attack_parameters(
    {
      acid_stream_name = stream_small,
      range=range_spitter_big,
      min_attack_distance=7,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_big,
      scale=scale_spitter_big,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=0.6,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.07,
    -- in pu
    pollution_to_join_attack = 30,
    corpse = "big-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_3",
    working_sound = table.deepcopy(data.raw['unit']['big-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['big-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['big-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = spitter_water_reflection(scale_spitter_big),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['big-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale_spitter_big, biter_tint, biter_tint2),
	ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "behemoth-toxic-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 1500*HEALTH_S,
    order="b-ts-d",
    subgroup="enemies",
	resistances =poison_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = stream_big,
      range=range_spitter_behemoth,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_behemoth,
      scale=scale_spitter_behemoth,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=0.8,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.084,
    pollution_to_join_attack = 250,
    corpse = "behemoth-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_4",
    working_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale_spitter_behemoth, biter_tint, biter_tint2),
	ai_settings = biter_ai_settings
  },


  
  
  {
    type = "unit",
    name = "leviathan-toxic-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000*HEALTH_S,
    order="b-ts-e",
    subgroup="enemies",
	resistances = leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.7, -2.4}, {1.7, 2.4}},
    sticker_box = {{-0.7, -1.2}, {0.7, 0.2}},
    distraction_cooldown = 300,
    loot =  { },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = stream_big,
      range=22,
      min_attack_distance=11,
      cooldown=100,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_leviathan,
      scale=leviathan_scale,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=0.8,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 50,
    movement_speed = 0.15,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 800,
    corpse = "leviathan-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_5",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(0.9),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	
    run_animation = spitterrunanimation(leviathan_scale, biter_tint, biter_tint2),
	ai_settings = biter_ai_settings
  },
  


  
  -- CORPSES  *********************************
  
  
 
  add_spitter_die_animation(scale_spitter_small, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "small-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/small-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_medium, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "medium-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_big, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "big-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
  
  add_spitter_die_animation(scale_spitter_behemoth, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "behemoth-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-d[behemoth]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
   
  add_spitter_die_animation(leviathan_scale, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "leviathan-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-e[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.02,
  }),  
  
})



if not settings.startup["tb-disable-mother"].value then
data:extend(
{
 
  {
    type = "unit",
    name = "mother-toxic-spitter",
    icon = "__base__/graphics/icons/behemoth-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 100000*HEALTH_S,
    order="b-ts-m",
    subgroup="enemies",
	resistances = leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-2, -2}, {2, 2}},
    selection_box = {{-2, -2}, {2, 2}},
    sticker_box = {{-1.5, -1.5}, {1.5, 1.5}},
    distraction_cooldown = 300,
    loot =
    {
    },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = "tb-firemother-stream-big",
      range=35,
      min_attack_distance=11,
      cooldown=400,
	  cooldown_deviation = 0.15,
      damage_modifier=dmg_modifier_spitter_mother,
      scale=leviathan_scale +1,
      tint1=biter_tint,
      tint2=biter_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"
    }),	
    vision_distance = 80,
    movement_speed = 0.10,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 1000,
    corpse = "mother-toxic-spitter-corpse",
    dying_explosion = "tb_poison_die_cloud_5",
    working_sound = sounds.spitter_calls_big(1.2),
    dying_sound = sounds.spitter_dying_big(1.2),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	
    run_animation = spitterrunanimation(leviathan_scale+1, biter_tint, biter_tint2),
	ai_settings = biter_ai_settings
  },

  
  add_spitter_die_animation(leviathan_scale+1, biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "mother-toxic-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-m[mother]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.007,
  }),  
  
})
end