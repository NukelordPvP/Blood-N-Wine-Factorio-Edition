tb_cooldown = 20


poison_resists =
    {
      {
        type = "poison",
        percent = 100,
      },
      {
        type = "acid",
        percent = 100,
      },
      {
        type = "laser",
        percent = -30,
      },
      {
        type = "electric",
        percent = -40,
      },

    }
	


nest_resists =
    {
      {
        type = "poison",
        percent = 100,
      },
      {
        type = "acid",
        percent = 100,
      },
      {
        type = "physical",
		decrease = 3,
        percent = 18,
      },
      {
        type = "impact",
		decrease = 3,
        percent = 20,
      },
      {
        type = "fire",
        percent = -20,
      },	  
	  

    }



leviathan_resists = 
    {
      {
        type = "physical",
        decrease = 12,
        percent = 75,
      },
      {
        type = "explosion",
        decrease = 50,
        percent = 60,
      },
      {
        type = "laser",
        percent = -230,
      },
      {
        type = "impact",
        percent = 60,
      },

      {
        type = "fire",
        percent = 50,
      },
      {
        type = "electric",
        percent = -50,
      },
      {
        type = "poison",
        percent = 100,
      },
      {
        type = "acid",
        percent = 100,
      },
    }

if data.raw["damage-type"]["bob-pierce"] then	
table.insert(leviathan_resists,	
      {
        type = "bob-pierce",
        decrease = 25,
        percent = 80,
      })
end





function make_unit_melee_attack_type(damagevalue)
  return
  {
    category = "melee",
    target_type = "entity",
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "damage",
          damage = { amount = damagevalue/2 , type = "physical"}
        },
        {
          type = "damage",
          damage = { amount = damagevalue/2 , type = "poison"}
        }		
      }
    }
  }
end
