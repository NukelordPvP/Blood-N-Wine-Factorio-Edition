
function tb_spawner_integration()
return
  {
    filename = "__base__/graphics/entity/spawner/spawner-idle-integration.png",
    variation_count = 1,
    width = 258,
    height = 188,
    shift = util.by_pixel(5, -2),
    frame_count = 1,
    line_length = 1,
	scale = 1.0,
    hr_version =
    {
      filename = "__base__/graphics/entity/spawner/hr-spawner-idle-integration.png",
      variation_count = 1,
      width = 522,
      height = 380,
      shift = util.by_pixel(7, -3),
      frame_count = 1,
      line_length = 1,
      scale = 0.5
    }
  }
end

function tb_spawner_idle_animation()
local anim =  {
    layers =
    {
      {
          filename = path .. "/graphics/spawner/toxic-spawner-a.png",
          line_length = 5,
          width = 2295/5,
          height = 1686/6,
          frame_count = 30,
          animation_speed = 0.12, --18
         -- direction_count = 1,
          run_mode = "forward-then-backward",
          shift = util.by_pixel(3, -2),
        --  y = variation * 354 * 2,
          scale = 0.5


      },
	{

          filename = "__base__/graphics/entity/spawner/hr-spawner-idle-shadow.png",
		  --filename = path .. "/graphics/spawner/shadow.png",
          draw_as_shadow = true,
         -- width = 449,
         -- height = 280,
          width = 464,
          height = 406,
 shift = util.by_pixel(36, 10),		
          frame_count = 1,
		  repeat_count=60,
          animation_speed = 0.12,
          --run_mode = "forward",
          --shift = util.by_pixel(36, 10),
          --line_length = 4,
          --y = variation * 406 * 2,
          scale = 0.5

      }
    }
  }
 return anim
end



function tb_spawner_die_animation()
return
  {
    layers =
    {
      {
          filename = path .. "/graphics/spawner/hr-spawner-die.png",
          line_length = 4,
          width = 490,
          height = 354,
          frame_count = 4,
          direction_count = 1,
          shift = util.by_pixel(7, 0),
          scale = 0.5
      },

      {
        filename = "__base__/graphics/entity/spawner/spawner-die-shadow.png",
        draw_as_shadow = true,
        width = 232,
        height = 176,
        frame_count = 4,
        direction_count = 1,
        shift = util.by_pixel(36, -2),
        line_length = 4,
      --  y = variation * 176,
        hr_version =
        {
          filename = "__base__/graphics/entity/spawner/hr-spawner-die-shadow.png",
          draw_as_shadow = true,
          width = 466,
          height = 406,
          frame_count = 4,
          direction_count = 1,
          shift = util.by_pixel(36, 10),
          line_length = 4,
       --   y = variation * 406,
          scale = 0.5
        }
      }
    }
  }
end


function tb_TEMP_spawner_die_animation(variation, tint)
return
  {
    layers =
    {
      {

          filename = "__base__/graphics/entity/spawner/hr-spawner-idle-integration.png",
          line_length = 1,
          width = 522,
          height = 1520/4,
          frame_count = 1,
          direction_count = 1,
          --shift = util.by_pixel(3, -2),
          y = variation * 1520/4,
          scale = 0.5

      },
    }
  }
end

