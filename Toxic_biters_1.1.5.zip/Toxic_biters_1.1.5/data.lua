path = '__Toxic_biters__'
sounds = require("__base__/prototypes/entity/sounds.lua")
biter_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}  -- purple  {r = 0.7, g = 0.5, b = 1, a = 0.9}
biter_tint2 = {r = 0.4, g = 1, b = 0.6, a = 0.6} 
spawner_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}
biter_back_tint = {r = 0.9, g = 0.4, b = 0.9, a = 0.8}

worm_tint= {r = 0.4, g = 1, b = 0.6, a =1} 
icon_tint = {r = 0.9, g = 0.6, b = 0.9, a = 0.9}


DAMAGE_S = settings.startup["tb-DamageScaler"].value
HEALTH_S = settings.startup["tb-HealthScaler"].value

dmg_modifier_spitter_small    = 12* DAMAGE_S
dmg_modifier_spitter_medium   = 24* DAMAGE_S
dmg_modifier_spitter_big      = 36* DAMAGE_S
dmg_modifier_spitter_behemoth = 60* DAMAGE_S
dmg_modifier_spitter_leviathan= 90* DAMAGE_S
dmg_modifier_spitter_mother   =150* DAMAGE_S

dmg_modifier_worm_small    = 36* DAMAGE_S
dmg_modifier_worm_medium   = 48* DAMAGE_S
dmg_modifier_worm_big      = 72* DAMAGE_S
dmg_modifier_worm_behemoth = 96* DAMAGE_S
dmg_modifier_worm_leviathan= 60* DAMAGE_S
dmg_modifier_worm_mother   =100* DAMAGE_S


range_spitter_leviathan = 22
range_spitter_mother = 35


	

local is_sprite = function(array)
  return array.width and array.height and (array.filename or array.stripes or array.filenames)
end

function hack_tint(array, tint,check_runtime)
  for k, v in pairs (array) do
    if type(v) == "table" then
      if is_sprite(v) then
        if not check_runtime or v.apply_runtime_tint then
          v.tint = tint
          v.apply_runtime_tint = false
          if v.hr_version then
            v.hr_version.apply_runtime_tint = false
            v.hr_version.tint = tint
          end
        end
      end
      hack_tint(v, tint, check_runtime)
    end
  end
end



require ("prototypes.projectiles")
require ("prototypes.explosion")
require ("prototypes.spitters")
require ("prototypes.biters")
require ("prototypes.worms")
require ("prototypes.bosses")
require ("prototypes.infected")


-- custom icons
function create_icons(t,name)
local data = data.raw[t][name]
if data then 
	data.icons = {{icon=data.icon,tint=icon_tint,icon_size=data.icon_size}} 
	end
end

create_icons('unit','small-toxic-biter')
create_icons('unit','medium-toxic-biter')
create_icons('unit','big-toxic-biter')
create_icons('unit','behemoth-toxic-biter')
create_icons('unit','leviathan-toxic-biter')

create_icons('unit','small-toxic-spitter')
create_icons('unit','medium-toxic-spitter')
create_icons('unit','big-toxic-spitter')
create_icons('unit','behemoth-toxic-spitter')
create_icons('unit','leviathan-toxic-spitter')
create_icons('unit','mother-toxic-spitter')

for k=1,10 do 
	create_icons('unit',"maf-boss-toxic-biter-"..k)
	create_icons('unit',"maf-boss-toxic-spitter-"..k)
	end


--create_icons("unit-spawner","toxic-biter-spawner")
create_icons("turret","small-toxic-worm-turret")
create_icons("turret","medium-toxic-worm-turret")
create_icons("turret","big-toxic-worm-turret")
create_icons("turret","behemoth-toxic-worm-turret")
create_icons("turret","leviathan-toxic-worm-turret")
create_icons("turret","mother-toxic-worm-turret")


--option to disable vanilla enemies
if settings.startup["tb-disable-vanilla"].value then
	data.raw['unit-spawner']['biter-spawner'].autoplace = nil
	data.raw['unit-spawner']['spitter-spawner'].autoplace = nil
	data.raw['turret']['small-worm-turret'].autoplace = nil
	data.raw['turret']['medium-worm-turret'].autoplace = nil
	data.raw['turret']['big-worm-turret'].autoplace = nil
	data.raw['turret']['behemoth-worm-turret'].autoplace = nil
	end
	
	

	