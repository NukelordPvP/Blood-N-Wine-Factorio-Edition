
local toxic_tint = {r = 0.9, g = 0.4, b = 0.9}

local enemy_names = {
	"small-toxic-worm-turret",	"medium-toxic-worm-turret",	"big-toxic-worm-turret","behemoth-toxic-worm-turret","leviathan-toxic-worm-turret",
	"mother-toxic-worm-turret","small-toxic-biter","medium-toxic-biter", "small-toxic-spitter","medium-toxic-spitter",
	"big-toxic-biter", "big-toxic-spitter", "behemoth-toxic-biter", "behemoth-toxic-spitter", "leviathan-toxic-biter", "leviathan-toxic-spitter", 
	"mother-toxic-spitter"}

for x=1,10 do
	table.insert (enemy_names,"maf-boss-toxic-spitter-"..x)
	table.insert (enemy_names,"maf-boss-toxic-biter-"..x)
	end


local replaces = {
	['small-toxic-worm-turret']={'small-worm-turret'},
	['medium-toxic-worm-turret']={'medium-worm-turret'},
	['big-toxic-worm-turret']={'big-worm-turret'},
	['behemoth-toxic-worm-turret']={'behemoth-worm-turret'},
	['leviathan-toxic-worm-turret']={'behemoth-worm-turret'},
	['mother-toxic-worm-turret']={'behemoth-worm-turret'},
	['toxic-biter-spawner']={'biter-spawner','spitter-spawner'},
	}

local aux_min = 0.65 --50

local function GetLocalAux(surface,position)
local aux
local calc = surface.calculate_tile_properties({'aux'},{position}) 
if calc and calc.aux then
	aux = calc.aux[1] end
return aux
end

script.on_event(defines.events.on_biter_base_built, function(event)
if not global.setting_disable_terrain_check then
local entity=event.entity
if replaces[entity.name] then
	local position=entity.position
	local surface=entity.surface
	local force=entity.force
	local aux = GetLocalAux(surface,position) 
	if aux then 
		if aux < aux_min then
			local name   = entity.name
			local replac = replaces[name][math.random(#replaces[name])]
			entity.destroy()
			surface.create_entity{name=replac, position=position, force=force} 
			end
		end
	end
end
end)

function ReadSettings(event)
global.setting_disable_terrain_check = settings.startup["tb-disable-terrain-check"].value
global.setting_allow_infection = settings.startup["tb-allow-infection"].value
--global.infected_buildings = global.infected_buildings or {}

global.infect_ammo ={[1]="firearm-magazine",[2]="piercing-rounds-magazine",[3]="artillery-shell"}
if game.item_prototypes["rifle-magazine"] then global.infect_ammo[1] = "rifle-magazine" end
if game.item_prototypes["armor-piercing-rifle-magazine"] then global.infect_ammo[2] = "armor-piercing-rifle-magazine" end
end

function on_init() 
ReadSettings()
end
function on_configuration_changed(data)
ReadSettings()
end
script.on_configuration_changed(on_configuration_changed)
script.on_init(on_init)




function in_list(list, obj)
	for k, obj2 in pairs(list) do
		if obj2 == obj then
			return(k)
		end
	end
	return(nil)
end





--- INFECTION
script.on_event(defines.events.on_entity_died, function(event)

local force=event.force  -- force that kill
local killer=event.cause
local dead = event.entity
local surface = dead.surface

if  in_list({"tb_infected_ship","tb_infected_ship_boss","toxic-biter-spawner","tb_infected_radar"}, dead.name)  then 
	surface.create_entity {name="tb_poison_die_cloud_5",position =  dead.position, force=force}
	end
	
if global.setting_allow_infection then
if not (force and killer and killer.valid) then return end

if in_list(enemy_names, killer.name) then 
	surface.create_entity {name="tb_poison_die_cloud_1",position =  dead.position, force=force}
	if dead.type=="ammo-turret" then 
		local turret = surface.create_entity {name="tb_infected_gun_turret",position =  dead.position, force=force}
		if remote.interfaces["kr-creep"] then remote.call("kr-creep", "spawn_creep_at_position", surface, turret.position) end
		local bullet = global.infect_ammo[1]
		if force.evolution_factor>0.3 then bullet = global.infect_ammo[2] end
		turret.insert({name=bullet}) 
		--global.infected_buildings[turret.unit_number] = {host = dead.name, force=dead.force}
	elseif dead.type=="electric-turret" then 
		local turret = surface.create_entity {name="tb_infected_laser_turret",position =  dead.position, force=force}
		if remote.interfaces["kr-creep"] then remote.call("kr-creep", "spawn_creep_at_position", surface, turret.position) end
		--global.infected_buildings[turret.unit_number] = {host = dead.name, force=dead.force}
	elseif dead.type=="radar" then 
		local radar = surface.create_entity {name="tb_infected_radar",position =  dead.position, force=force}
		if remote.interfaces["kr-creep"] then remote.call("kr-creep", "spawn_creep_at_position", surface, radar.position) end
		--global.infected_buildings[turret.unit_number] = {host = dead.name, force=dead.force}
	elseif dead.type=="artillery-turret" then 
		local turret = surface.create_entity {name="tb_infected_artillery_turret",position =  dead.position, force=force}
		turret.insert{name=global.infect_ammo[3], count=40}	
		if remote.interfaces["kr-creep"] then remote.call("kr-creep", "spawn_creep_at_position", surface, turret.position) end
	end	
	end

end
end,
 {{filter = "type", type = "ammo-turret"}, {filter = "type", type = "electric-turret"}, 
		{filter = "type", type = "radar"}, {filter = "type", type = "artillery-turret"},
		{filter = "type", type = "unit-spawner"}}
		) -- event filters 
-- ?? "fluid-turret" -- "character"??