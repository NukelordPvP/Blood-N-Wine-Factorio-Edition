data:extend({


	{
	    type = "double-setting",
	    name = "tb-HealthScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "b",
	},

	{
	    type = "double-setting",
	    name = "tb-DamageScaler",
	    setting_type = "startup",
	    default_value = 1.0,
	    minimum_value = 0.1,
	    maximum_value = 100.0,
	    order = "c",
	},

	{
	    type = "bool-setting",
	    name = "tb-disable-worms",
	    setting_type = "startup",
	    default_value = false,
	    order = "d",
	},

	{
	
	    type = "bool-setting",
	    name = "tb-disable-mother",
	    setting_type = "startup",
	    default_value = false,
	    order = "e",
	},	


   {
    type = "bool-setting",
    name = "tb-disable-terrain-check",
    setting_type = "startup",
    default_value = false,
	order = "t"
   },  


	{
	
	    type = "bool-setting",
	    name = "tb-allow-infection",
	    setting_type = "startup",
	    default_value = true,
	    order = "v",
	},	

	
   {
    type = "bool-setting",
    name = "tb-disable-vanilla",
    setting_type = "startup",
    default_value = false,
	order = "z"
   },  
	


	
})
