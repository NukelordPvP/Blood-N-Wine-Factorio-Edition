world = {
    aux = {
        max = 0.92476963996887207,
        min = 0
    },
    elevation = {
        max = 66.864372253417969,
        min = -43.986110687255859
    },
    enemy_base_probability = {
        max = 5.6449527740478516,
        min = -1001.2664794921875
    },
    moisture = {
        max = 1,
        min = 0
    },
    temperature = {
        max = 17.667638778686523,
        min = 12.830085754394531
    }
}