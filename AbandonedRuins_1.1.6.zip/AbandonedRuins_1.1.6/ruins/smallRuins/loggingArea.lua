return
{
  entities =
  {
    {"tree-05-stump", {x = -2.6, y = -2.71}, {dir = "south", }},
    {"tree-05-stump", {x = 0.09, y = -2.2}, {dir = "south", }},
    {"tree-05-stump", {x = -0.86, y = -3.3}, {dir = "south", }},
    {"tree-05-stump", {x = 1.12, y = -2.87}, {dir = "south", }},
    {"wooden-chest", {x = 2.5, y = -2.5}, {items = {wood = {type = "random", min = 60, max = 200}}, }},
    {"tree-05-stump", {x = -3.73, y = -0.91}, {dir = "south", }},
    {"tree-05-stump", {x = -1.73, y = -0.92}, {dir = "south", }},
    {"tree-05-stump", {x = -0.04, y = -0.8}, {dir = "south", }},
    {"tree-05-stump", {x = 2.22, y = -0.2}, {dir = "south", }},
    {"tree-05-stump", {x = -3.52, y = 0.62}, {dir = "south", }},
    {"tree-05-stump", {x = -1.9, y = 0.6}, {dir = "south", }},
    {"tree-05-stump", {x = -3.66, y = 1.2}, {dir = "south", }},
    {"tree-05-stump", {x = -0.97, y = 1.31}, {dir = "south", }},
    {"tree-05-stump", {x = 0.31, y = 0.48}, {dir = "south", }},
    {"dead-dry-hairy-tree", {x = 2.02, y = 2.06}, {}},
    {"tree-05-stump", {x = 1.29, y = 1.48}, {dir = "south", }},
    {"tree-05-stump", {x = -3.62, y = 2.69}, {dir = "south", }},
    {"tree-05-stump", {x = -2.11, y = 2.89}, {dir = "south", }},
    {"tree-05-stump", {x = 0.36, y = 3.19}, {dir = "south", }},
    {"tree-05-stump", {x = 2.98, y = 3.43}, {dir = "south", }},
  },
}
