return
{
  entities =
  {
    {"stone-wall", {x = 3.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 2.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 1.5, y = -1.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 1.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 2.5, y = -1.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -0.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -0.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -1.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = 0.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -2.5, y = 3.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
    {"stone-wall", {x = -1.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 0, max = 200}}, dead = 0.3}},
  },
}
