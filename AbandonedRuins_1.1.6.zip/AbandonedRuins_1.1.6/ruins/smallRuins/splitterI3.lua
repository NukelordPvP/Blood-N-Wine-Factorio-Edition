return
{
  entities =
  {
    {{type = "random-of-entity-type", entity_type = "splitter"}, {x = 1, y = -0.5}, {dir = "south", dmg = {dmg = {type="random", min = 0, max = 50}}}},
  },
}
