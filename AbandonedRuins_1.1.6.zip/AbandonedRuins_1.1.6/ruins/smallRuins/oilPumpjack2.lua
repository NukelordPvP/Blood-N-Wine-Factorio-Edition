return
{
  entities =
  {
    {"pumpjack", {x = 1.5, y = -2.5}, {dir = "south", }},
    {"pipe", {x = -1.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 80}}, dead = 0.4}},
    {"pipe", {x = -0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 80}}, dead = 0.4}},
    {"pipe", {x = 0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 80}}, dead = 0.4}},
    {"small-electric-pole-remnants", {x = -0.5, y = 0.5}, {}},
    {"pipe", {x = -1.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 80}}, dead = 0.4}},
    {"pipe", {x = -1.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 80}}, dead = 0.4}},
    {"pump", {x = -1.5, y = 3}, {dir = "south", dead = 0.4}},
  },
}
