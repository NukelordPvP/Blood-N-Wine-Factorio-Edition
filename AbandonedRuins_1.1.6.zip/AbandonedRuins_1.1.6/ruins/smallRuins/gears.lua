return
{
  entities =
  {
    {"transport-belt", {x = 1.5, y = -2.5}, {dir = "east", }},
    {"transport-belt", {x = 0.5, y = -2.5}, {dir = "east", }},
    {"transport-belt", {x = 3.5, y = -2.5}, {dir = "south", }},
    {"transport-belt", {x = 2.5, y = -2.5}, {dir = "east", }},
    {"fast-inserter", {x = -0.5, y = -0.5}, {dir = "south", dead = 0.3}},
    {"transport-belt", {x = -0.5, y = -1.5}, {dir = "east", }},
    {"fast-inserter", {x = 1.5, y = -0.5}, {dir = "south", dead = 0.3}},
    {"medium-electric-pole-remnants", {x = 0.5, y = -0.5}, {}},
    {"transport-belt", {x = 1.5, y = -1.5}, {dir = "west", }},
    {"transport-belt", {x = 0.5, y = -1.5}, {}},
    {"transport-belt", {x = 3.5, y = -1.5}, {dir = "east", }},
    {"assembling-machine-2", {x = -1.5, y = 1.5}, {recipe = "iron-gear-wheel", }},
    {"assembling-machine-2", {x = 1.5, y = 1.5}, {recipe = "iron-gear-wheel", dmg = {dmg = {type = "random", min = 30, max = 80}},}},
    {"fast-inserter", {x = -2.5, y = 3.5}, {dir = "south", dead = 0.3}},
    {"medium-electric-pole-remnants", {x = -0.5, y = 3.5}, {}},
    {"fast-inserter", {x = -1.5, y = 3.5}, {dir = "south", dead = 0.3}},
    {"fast-inserter", {x = 1.5, y = 3.5}, {dir = "south", dead = 0.3}},
    {"fast-inserter", {x = 0.5, y = 3.5}, {dir = "south", dead = 0.3}},
  },
}
