return
{
  entities =
  {
    {"transport-belt", {x = 1.5, y = -2.5}, {dir = "south", dmg = {dmg = {type = "random", min = 80, max = 230}}, }},
    {"transport-belt", {x = 1.5, y = -3.5}, {dir = "south", dmg = {dmg = {type = "random", min = 80, max = 230}}, }},
    {"roboport-remnants", {x = -2, y = -2}, {}},
    {"transport-belt", {x = 1.5, y = -0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 150}}, }},
    {"transport-belt", {x = 1.5, y = -1.5}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 150}}, }},
    {"storage-chest-remnants", {x = 0.5, y = -1.5}, {dir = "south", }},
    {"assembling-machine-2", {x = -1.5, y = 2.5}, {recipe = "construction-robot", }},
    {"inserter", {x = -0.5, y = 0.5}, {dir = "south", }},
    {"inserter", {x = 0.5, y = 1.5}, {dir = "east", }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"transport-belt", {x = 1.5, y = 0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"medium-electric-pole-remnants", {x = 0.5, y = 0.5}, {}},
    {"long-handed-inserter", {x = 0.5, y = 3.5}, {dir = "east", }},
    {"transport-belt", {x = 2.5, y = 3.5}, {dir = "west", dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"transport-belt", {x = 3.5, y = 3.5}, {dir = "west", dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
  },
}
