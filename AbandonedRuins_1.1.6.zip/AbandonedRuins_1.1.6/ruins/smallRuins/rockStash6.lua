return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {}},
  },
}
