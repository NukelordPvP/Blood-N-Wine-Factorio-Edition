return
{
  entities =
  {
    {"wooden-chest", {x = -2.5, y = -3.5}, {items = {["copper-plate"] = {type = "random", min = 1, max = 40}}, }},
    {"medium-electric-pole-remnants", {x = -2.5, y = -2.5}, {}},
    {"stone-furnace", {x = 2, y = -3}, {dmg = {dmg = 15}, }},
    {"transport-belt", {x = -0.5, y = -0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"inserter", {x = -0.5, y = -1.5}, {dmg = {dmg = 60}, }},
    {"transport-belt", {x = 2.5, y = -0.5}, {dir = "south", }},
    {"inserter", {x = 2.5, y = -1.5}, {dmg = {dmg = 45}, }},
    {"transport-belt", {x = -2.5, y = 0.5}, {dir = "west", dmg = {dmg = {type = "random", min = 10, max = 80}}, }},
    {"transport-belt", {x = -0.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = -0.5, y = 1.5}, {}},
    {"transport-belt", {x = -1.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 1.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 0.5, y = 0.5}, {dir = "west", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"transport-belt", {x = 3.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 1.5}, {}},
    {"medium-electric-pole-remnants", {x = -2.5, y = 3.5}, {}},
    {"inserter", {x = -0.5, y = 2.5}, {dir = "south", }},
    {"inserter", {x = 2.5, y = 2.5}, {dir = "south", }},
  },
}
