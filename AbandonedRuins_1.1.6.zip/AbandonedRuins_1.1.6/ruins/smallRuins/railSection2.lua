return
{
  entities =
  {
    {"straight-rail", {x = -3, y = -3}, {dir = "east", }},
    {"straight-rail", {x = -1, y = -3}, {dir = "east", }},
    {"straight-rail", {x = 1, y = -3}, {dir = "east", }},
    {"straight-rail", {x = -3, y = 1}, {dir = "east", }},
    {"straight-rail", {x = 1, y = 1}, {dir = "east", }},
    {"straight-rail", {x = 3, y = 1}, {dir = "east", }},
  },
}
