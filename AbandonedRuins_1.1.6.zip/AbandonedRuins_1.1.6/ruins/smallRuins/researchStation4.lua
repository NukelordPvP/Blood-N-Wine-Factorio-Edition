return
{
  entities =
  {
    {"lab", {x = 1.5, y = -0.5}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {items = {["automation-science-pack"] = {type = "random", min = 20, max = 40}, ["logistic-science-pack"] = {type = "random", min = 20, max = 40}}, }},
  },
}
