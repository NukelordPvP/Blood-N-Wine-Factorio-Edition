return
{
  entities =
  {
    {"electric-mining-drill", {x = 1.5, y = -1.5}, {dir = "south", }},
    {"transport-belt", {x = -2.5, y = 0.5}, {dir = "west", }},
    {"electric-mining-drill", {x = -1.5, y = 2.5}, {}},
    {"transport-belt", {x = -1.5, y = 0.5}, {dir = "west", }},
  },
}
