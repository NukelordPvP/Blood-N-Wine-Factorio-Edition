return
{
  entities =
  {
    {"pipe", {x = 0, y = -2.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"chemical-plant-remnants", {x = -3, y = -0.5}, {dir = "east", }},
    {"pipe", {x = -1, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"pipe", {x = -1, y = -1.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"long-handed-inserter", {x = 0, y = -0.5}, {dir = "west", }},
    {"pipe", {x = 0, y = -1.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"assembling-machine-2", {x = 2, y = -1.5}, {dir = "west", dead = 0.5}},
    {"small-electric-pole-remnants", {x = -2, y = 1.5}, {}},
    {"pipe", {x = -1, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"pipe", {x = -1, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"long-handed-inserter", {x = 0, y = 0.5}, {dir = "west", }},
    {"pipe", {x = 0, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
    {"assembling-machine-2", {x = 2, y = 1.5}, {dir = "west", dead = 0.5}},
    {"pipe", {x = 0, y = 2.5}, {dmg = {dmg = {type = "random", min = 0, max = 90}}, }},
  },
}
