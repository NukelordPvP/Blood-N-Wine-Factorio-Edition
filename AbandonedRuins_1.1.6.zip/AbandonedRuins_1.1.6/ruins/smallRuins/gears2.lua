return
{
  entities =
  {
    {"fast-inserter", {x = -0.5, y = -2.5}, {dir = "south", dead = 0.3}},
    {"medium-electric-pole-remnants", {x = 1.5, y = -2.5}, {}},
    {"fast-inserter", {x = 0.5, y = -2.5}, {dir = "south", dead = 0.3}},
    {"fast-inserter", {x = 3.5, y = -2.5}, {dir = "south", dmg = {dmg = 50}, dead = 0.1}},
    {"fast-inserter", {x = 2.5, y = -2.5}, {dir = "south", dmg = {dmg = 36}, dead = 0.1}},
    {"assembling-machine-2", {x = -0.5, y = -0.5}, {recipe = "iron-gear-wheel", }},
    {"assembling-machine-2", {x = 2.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 20, max = 130}}, recipe = "iron-gear-wheel", }},
    {"fast-inserter", {x = -0.5, y = 1.5}, {dir = "south", dead = 0.3}},
    {"fast-inserter", {x = 1.5, y = 1.5}, {dir = "south", dead = 0.3}},
    {"medium-electric-pole-remnants", {x = 0.5, y = 1.5}, {}},
    {"fast-transport-belt", {x = -2.5, y = 2.5}, {dir = "south", }},
    {"fast-transport-belt", {x = -2.5, y = 3.5}, {dir = "east", }},
    {"fast-transport-belt", {x = -0.5, y = 3.5}, {dir = "east", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"fast-transport-belt", {x = -1.5, y = 3.5}, {dir = "east", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"fast-transport-belt", {x = -0.5, y = 2.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 1.5, y = 2.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 0.5, y = 2.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 0.5, y = 3.5}, {}},
  },
}
