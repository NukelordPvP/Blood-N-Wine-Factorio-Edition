return
{
  entities =
  {
    {"stone-wall", {x = -3, y = -1.5}, {}},
    {"stone-wall", {x = -2, y = -1.5}, {}},
    {"stone-wall", {x = -3, y = -0.5}, {}},
    {"gun-turret", {x = -1.5, y = 0}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 190}}, items = {["firearm-magazine"] = 2}, force = "enemy" }},
    {"stone-wall", {x = -1, y = -1.5}, {}},
    {"stone-wall", {x = 0, y = -1.5}, {}},
    {"stone-wall", {x = 1, y = -1.5}, {}},
    {"stone-wall", {x = 2, y = -1.5}, {}},
    {"gun-turret", {x = 1.5, y = 0}, {dir = "south", dmg = {dmg = {type = "random", min = 0, max = 190}}, items = {["firearm-magazine"] = 1}, force = "enemy" }},
    {"stone-wall", {x = 3, y = -1.5}, {}},
    {"stone-wall", {x = 3, y = -0.5}, {}},
    {"wall-remnants", {x = -3, y = 1.5}, {}},
    {"wall-remnants", {x = -2, y = 1.5}, {}},
    {"stone-wall", {x = -3, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"wall-remnants", {x = -1, y = 1.5}, {}},
    {"stone-wall", {x = 0, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"wall-remnants", {x = 2, y = 1.5}, {}},
    {"stone-wall", {x = 1, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"wall-remnants", {x = 3, y = 1.5}, {}},
    {"stone-wall", {x = 3, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
  },
}
