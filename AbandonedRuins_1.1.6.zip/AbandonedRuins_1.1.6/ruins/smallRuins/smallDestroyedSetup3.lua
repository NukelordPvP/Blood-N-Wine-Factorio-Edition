return
{
  entities =
  {
    {"assembling-machine-1", {x = -0.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 15, max = 75}}, }},
    {"inserter", {x = -2.5, y = -1.5}, {dmg = {dmg = {type = "random", min = 50, max = 150}}, }},
    {"transport-belt", {x = 1.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 5, max = 35}}, }},
    {"inserter", {x = -0.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 0, max = 20}}, }},
    {"transport-belt", {x = 1.5, y = 1.5}, {}},
    {"transport-belt", {x = 1.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 5, max = 35}}, }},
    {"transport-belt", {x = 1.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 5, max = 40}}, }},
  },
}
