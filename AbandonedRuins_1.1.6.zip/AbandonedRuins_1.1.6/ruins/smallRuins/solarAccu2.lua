return
{
  entities =
  {
    {"accumulator", {x = 3, y = -2}, {}},
    {"solar-panel", {x = -1.5, y = -0.5}, {}},
    {"medium-electric-pole-remnants", {x = 0.5, y = -0.5}, {}},
    {"medium-electric-pole-remnants", {x = 2.5, y = 2.5}, {}},
  },
}
