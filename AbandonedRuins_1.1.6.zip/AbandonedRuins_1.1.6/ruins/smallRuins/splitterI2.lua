return
{
  entities =
  {
    {"splitter", {x = 0, y = -1.5}, {dir = "south", }},
    {"splitter", {x = 2, y = -1.5}, {dir = "south", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"splitter", {x = 1, y = 1.5}, {dir = "south", }},
    {"splitter", {x = 2, y = 0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
  },
}
