return
{
  entities =
  {
    {"wall-remnants", {x = -2.5, y = -3.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = -2.5}, {dir = "west", }},
    {"wall-remnants", {x = -1.5, y = -3.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = -3.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = -0.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = -1.5}, {dir = "west", }},
    {"gun-turret-remnants", {x = -2, y = -2}, {dir = "west", }},
    {"medium-biter-corpse", {x = 0.83, y = -1.68}, {dir = "west", }},
    {"land-mine-remnants", {x = 2.5, y = -0.5}, {dir = "west", }},
    {"wall-remnants", {x = -2.5, y = 1.5}, {dir = "west", }},
    {"wall-remnants", {x = -1.5, y = 1.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = 1.5}, {dir = "west", }},
    {"wall-remnants", {x = -0.5, y = 0.5}, {dir = "west", }},
    {"gun-turret-remnants", {x = -2, y = 0}, {dir = "west", }},
    {"medium-biter-corpse", {x = -3.61, y = 3.29}, {dir = "west", }},
    {"medium-biter-corpse", {x = 0.28, y = 2.98}, {dir = "west", }},
    {"land-mine-remnants", {x = 1.5, y = 3.5}, {dir = "west", }},
  },
}
