return
{
  entities =
  {
    {"splitter", {x = 0.5, y = 0}, {dir = "west", }},
    {"transport-belt", {x = 1.5, y = -0.5}, {dir = "west", dmg = {dmg = {type = "random", min = 25, max = 130}}, }},
    {"transport-belt", {x = -1.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = -1.5, y = 1.5}, {dir = "west", }},
    {"splitter", {x = -0.5, y = 1}, {dir = "west", dmg = {dmg = {type = "random", min = 25, max = 130}}, }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 70}}, }},
    {"transport-belt", {x = 1.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 3.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 70}}, }},
    {"transport-belt", {x = 2.5, y = 0.5}, {dir = "west", }},
  },
}
