return
{
  entities =
  {
    {"solar-panel", {x = -2.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"accumulator", {x = 0, y = -3}, {dmg = {dmg = {type = "random", min = 0, max = 300}}, }},
    {"solar-panel", {x = 2.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"accumulator", {x = -3, y = 0}, {dmg = {dmg = {type = "random", min = 0, max = 300}}, }},
    {"medium-electric-pole", {x = 0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 100}}, }},
    {"accumulator", {x = 3, y = 0}, {dmg = {dmg = {type = "random", min = 0, max = 300}}, }},
    {"solar-panel", {x = -2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"small-lamp", {x = -0.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 0, max = 100}}, }},
    {"solar-panel", {x = 2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 0, max = 400}}, }},
    {"accumulator", {x = 0, y = 3}, {dmg = {dmg = {type = "random", min = 0, max = 300}}, }},
  },
}
