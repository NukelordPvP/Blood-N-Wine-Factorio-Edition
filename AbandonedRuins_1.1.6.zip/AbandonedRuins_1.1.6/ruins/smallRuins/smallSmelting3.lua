return
{
  entities =
  {
    {"stone-furnace", {x = -2, y = -2}, {}},
    {"wooden-chest", {x = 0.5, y = -0.5}, {items = {["copper-ore"] = {type = "random", min = 1, max = 30}, ["iron-ore"] = {type = "random", min = 1, max = 30}}, }},
  },
}
