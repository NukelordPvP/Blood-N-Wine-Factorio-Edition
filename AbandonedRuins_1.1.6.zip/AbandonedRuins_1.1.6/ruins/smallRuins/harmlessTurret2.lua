return
{
  entities =
  {
    {"gun-turret", {x = 1, y = 0}, {force = "enemy", items = {["firearm-magazine"] = 1}, }},
  },
}
