return
{
  entities =
  {
    {"small-electric-pole-remnants", {x = 0.5, y = -3.5}, {dir = "west", }},
    {"lamp-remnants", {x = -0.5, y = -2.5}, {}},
    {"lamp-remnants", {x = -1.5, y = -1.5}, {}},
    {"small-lamp", {x = -0.5, y = -1.5}, {}},
    {"small-lamp", {x = 1.5, y = -1.5}, {}},
    {"small-lamp", {x = 0.5, y = -2.5}, {}},
    {"small-lamp", {x = 0.5, y = -1.5}, {}},
    {"small-electric-pole-remnants", {x = -3.5, y = -0.5}, {dir = "west", }},
    {"small-lamp", {x = -0.5, y = 0.5}, {}},
    {"small-lamp", {x = -1.5, y = -0.5}, {}},
    {"small-lamp", {x = -0.5, y = -0.5}, {}},
    {"small-lamp", {x = 0.5, y = 0.5}, {}},
    {"small-lamp", {x = 1.5, y = -0.5}, {}},
    {"small-lamp", {x = 0.5, y = -0.5}, {}},
    {"small-electric-pole-remnants", {x = 2.5, y = -0.5}, {dir = "west", }},
    {"decider-combinator-remnants", {x = -3.5, y = 1}, {}},
    {"arithmetic-combinator", {x = -0.5, y = 3}, {}},
    {"decider-combinator", {x = -1.5, y = 3}, {}},
    {"constant-combinator", {x = 2.5, y = 3.5}, {dir = "west", }},
  },
  tiles =
  {
    {"stone-path", {x = -2, y = -2}},
    {"stone-path", {x = -2, y = -1}},
    {"stone-path", {x = -1, y = -3}},
    {"stone-path", {x = -1, y = -2}},
    {"stone-path", {x = -1, y = -1}},
    {"stone-path", {x = -1, y = 0}},
    {"stone-path", {x = 0, y = -3}},
    {"stone-path", {x = 0, y = -2}},
    {"stone-path", {x = 0, y = -1}},
    {"stone-path", {x = 0, y = 0}},
    {"stone-path", {x = 1, y = -2}},
    {"stone-path", {x = 1, y = -1}},
  }
}
