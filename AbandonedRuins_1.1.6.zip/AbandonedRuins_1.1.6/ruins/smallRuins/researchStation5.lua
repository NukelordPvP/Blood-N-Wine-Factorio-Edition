return
{
  entities =
  {
    {"lab", {x = 1.5, y = -0.5}, {}},
    {"wooden-chest", {x = -1.5, y = 0.5}, {}},
  },
}
