return
{
  entities =
  {
    {"stone-wall", {x = 0.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"stone-wall", {x = 0.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"stone-wall", {x = 0.5, y = -1.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"gate", {x = 0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 20, max = 50}}, dead = 0.3}},
    {"stone-wall", {x = 0.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"gate", {x = 0.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 20, max = 50}}, dead = 0.3}},
    {"stone-wall", {x = 0.5, y = 3.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
  },
}
