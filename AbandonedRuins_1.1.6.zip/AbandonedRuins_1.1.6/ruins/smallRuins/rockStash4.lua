return
{
  entities =
  {
    {"rock-big", {x = 0, y = 0}, {}},
    {"wooden-chest", {x = 1.5, y = 1.5}, {items = {["firearm-magazine"] = {type = "random", min = 25, max = 200}, ["shotgun-shell"] = {type = "random", min = 5, max = 25}}, }},
  },
}
