return
{
  entities =
  {
    {"stone-wall", {x = -0.5, y = -2.5}, {}},
    {"stone-wall", {x = 0.5, y = -2.5}, {}},
    {"stone-wall", {x = -2.5, y = -0.5}, {}},
    {"stone-wall", {x = 2.5, y = -0.5}, {}},
    {"stone-wall", {x = -2.5, y = 1.5}, {}},
    {"wooden-chest", {x = 0.5, y = 0.5}, {items = {["firearm-magazine"] = {type = "random", min = 1, max = 300}}, }},
    {"stone-wall", {x = 2.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 1, max = 75}}, }},
    {"stone-wall", {x = 2.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 1, max = 75}}, }},
    {"stone-wall", {x = -2.5, y = 2.5}, {}},
    {"stone-wall", {x = 0.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 75}}, }},
    {"stone-wall", {x = 2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 75}}, }},
  },
}
