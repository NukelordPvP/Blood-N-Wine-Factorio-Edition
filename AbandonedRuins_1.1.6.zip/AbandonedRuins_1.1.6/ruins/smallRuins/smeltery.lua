return
{
  entities =
  {
    {"wooden-chest", {x = -2.5, y = -2.5}, {}},
    {"stone-furnace", {x = -1, y = -2}, {dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"stone-furnace", {x = 2, y = -2}, {dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"small-electric-pole-remnants", {x = -2.5, y = -1.5}, {}},
    {"inserter", {x = -0.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"inserter", {x = 2.5, y = -0.5}, {}},
    {"small-electric-pole-remnants", {x = 3.5, y = -1.5}, {}},
    {"transport-belt", {x = -2.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"small-lamp", {x = -2.5, y = 0.5}, {dmg = {dmg = 62}, }},
    {"transport-belt", {x = -0.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = -1.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"transport-belt", {x = -0.5, y = 0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 0.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 3.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 0.5}, {dir = "south", dmg = {dmg = {type = "random", min = 10, max = 50}}, }},
    {"inserter", {x = -0.5, y = 3.5}, {dir = "south", }},
    {"transport-belt", {x = -0.5, y = 2.5}, {}},
    {"inserter", {x = 2.5, y = 3.5}, {dir = "south", }},
    {"transport-belt", {x = 2.5, y = 2.5}, {}},
  },
}
