return
{
  entities =
  {
    {"electric-mining-drill", {x = 0.5, y = 0.5}, {dir = "south", }},
    {"wooden-chest", {x = 0.5, y = 2.5}, {}},
  },
}
