return
{
  entities =
  {
    {"tree-06-stump", {x = -3.15, y = -2.07}, {dir = "south", }},
    {"tree-06-stump", {x = -0.64, y = -3.55}, {dir = "south", }},
    {"tank-remnants", {x = 1.57, y = -1.3}, {dir = "south", }},
    {"rock-huge", {x = 1.93, y = 1.77}, {}},
  },
}
