return
{
  entities =
  {
    {"lab", {x = 1.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 10, max = 80}}, }},
    {"wooden-chest", {x = -1.5, y = 0.5}, {items = {["automation-science-pack"] = {type = "random", min = 10, max = 40}}, }},
  },
}
