return
{
  entities =
  {
    {"electric-mining-drill", {x = 0.5, y = 0.5}, {dir = "west", }},
    {"iron-chest", {x = -1.5, y = 0.5}, {items = {["copper-ore"] = {type = "random", min = 1, max = 75}}, }},
  },
}
