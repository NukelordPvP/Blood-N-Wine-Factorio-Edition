return
{
  entities =
  {
    {"burner-mining-drill", {x = -1, y = 0}, {dir = "south", }},
    {"burner-mining-drill", {x = 1, y = 0}, {dir = "south", dmg = {dmg = {type = "random", min = 5, max = 110}}, }},
    {"transport-belt", {x = -0.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 140}}, }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 140}}, }},
  },
}
