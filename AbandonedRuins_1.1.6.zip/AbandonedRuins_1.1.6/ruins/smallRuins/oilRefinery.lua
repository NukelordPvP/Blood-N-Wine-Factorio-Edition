return
{
  entities =
  {
    {"pipe", {x = -2.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"oil-refinery", {x = -1.5, y = -0.5}, {dmg = {dmg = 8}, recipe = "basic-oil-processing", fluids = {["petroleum-gas"] = 400, ["crude-oil"] = 100}}},
    {"pipe", {x = -1.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -0.5, y = -3.5}, {}},
    {"pipe", {x = 1.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = 0.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = 3.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = 2.5, y = -3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"storage-tank-remnants", {x = 2.5, y = 1.5}, {}},
    {"pipe", {x = -0.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -0.5, y = 3.5}, {}},
    {"pipe", {x = 0.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
  },
}
