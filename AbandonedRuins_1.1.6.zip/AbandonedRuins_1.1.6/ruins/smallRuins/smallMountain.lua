return
{
  entities =
  {
    {"rock-big", {x = -2, y = -1}, {}},
    {"rock-big", {x = 0.5, y = -0.5}, {}},
    {"rock-big", {x = -1.5, y = 1}, {}},
    {"rock-big", {x = 1.5, y = 1.5}, {}},
  },
}
