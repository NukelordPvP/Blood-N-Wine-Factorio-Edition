return
{
  entities =
  {
    {"pipe", {x = -3.5, y = -0.5}, {}},
    {"pipe-remnants", {x = -0.5, y = -0.5}, {dir = "south", }},
    {"pipe-to-ground", {x = 0.5, y = -1.5}, {dir = "south", }},
    {"pipe", {x = 0.5, y = -0.5}, {dead = 0.4, }},
    {"pipe", {x = 3.5, y = -0.5}, {dead = 0.4, }},
    {"flamethrower-turret", {x = -2, y = 0.5}, {dir = "south", dead = 0.7}},
    {"flamethrower-turret", {x = 2, y = 0.5}, {dir = "south", dead = 0.7}},
    {"stone-wall", {x = -3.5, y = 3.5}, {dead = 0.4, }},
    {"stone-wall", {x = -2.5, y = 3.5}, {dead = 0.4, }},
    {"stone-wall", {x = -0.5, y = 3.5}, {dir = "south", dead = 0.4, }},
    {"stone-wall", {x = -1.5, y = 3.5}, {dir = "south", dead = 0.4, }},
    {"stone-wall", {x = 1.5, y = 3.5}, {dir = "south", dead = 0.4, }},
    {"stone-wall", {x = 0.5, y = 3.5}, {dir = "south", dead = 0.4, }},
    {"stone-wall", {x = 3.5, y = 3.5}, {dead = 0.4, }},
    {"stone-wall", {x = 2.5, y = 3.5}, {dead = 0.4, }},
  },
}
