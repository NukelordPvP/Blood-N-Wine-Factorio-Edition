return
{
  entities =
  {
    {"small-electric-pole-remnants", {x = -2.5, y = -0.5}, {}},
    {"fish", {x = -1.04, y = -1.25}, {}},
    {"fish", {x = -0.32, y = -1.25}, {}},
    {"fish", {x = 0.11, y = 2.17}, {}},
    {"wooden-chest", {x = -3.5, y = 1.5}, {items = {["raw-fish"] = {type = "random", min = 3, max = 18}}, }},
    {"fish", {x = -0.14, y = 0.27}, {}},
    {"long-handed-inserter", {x = -1.5, y = 1.5}, {dir = "west", }},
  },
  tiles =
  {
    {"water", {x = -2, y = -2}},
    {"water", {x = -2, y = -1}},
    {"water", {x = -2, y = 0}},
    {"water", {x = -1, y = -2}},
    {"water", {x = -1, y = -1}},
    {"water", {x = -1, y = 0}},
    {"water", {x = -1, y = 1}},
    {"water", {x = -1, y = 2}},
    {"water", {x = 0, y = -2}},
    {"water", {x = 0, y = -1}},
    {"water", {x = 0, y = 0}},
    {"water", {x = 0, y = 1}},
    {"water", {x = 0, y = 2}},
    {"water", {x = 1, y = -1}},
    {"water", {x = 1, y = 0}},
    {"water", {x = 1, y = 1}},
    {"water", {x = 1, y = 2}},
  }
}
