return
{
  entities =
  {
    {"rock-huge", {x = -1.5, y = -1.5}, {}},
    {"rock-huge", {x = 2.5, y = -2.5}, {}},
    {"rock-huge", {x = -2, y = 2}, {}},
    {"rock-huge", {x = 1, y = 2}, {}},
  },
}
