return
{
  entities =
  {
    {"stone-wall", {x = -2.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"gate", {x = -0.5, y = 0.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 50}}, dead = 0.3}},
    {"stone-wall", {x = -1.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"gate", {x = 1.5, y = 0.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 50}}, dead = 0.3}},
    {"gate", {x = 0.5, y = 0.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 50}}, dead = 0.3}},
    {"stone-wall", {x = 3.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
    {"stone-wall", {x = 2.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, dead = 0.4}},
  },
}
