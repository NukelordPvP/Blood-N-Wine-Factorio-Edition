return
{
  entities =
  {
    {"gun-turret", {x = 1, y = 0}, {force = "enemy", dmg = {dmg = {type = "random", min = 250, max = 390}}, }},
  },
}
