return
{
  entities =
  {
    {"stone-wall", {x = -2.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -0.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -1.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 1.5, y = -2.5}, {}},
    {"stone-wall", {x = 0.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 2.5, y = -2.5}, {}},
    {"stone-wall", {x = -2.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -2.5, y = -1.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"gun-turret", {x = 0, y = 0}, {force = "enemy", dmg = {dmg = {type = "random", min = 50, max = 200}}, }},
    {"stone-wall", {x = 2.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 2.5, y = -1.5}, {}},
    {"stone-wall", {x = -2.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -2.5, y = 0.5}, {}},
    {"stone-wall", {x = 2.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 2.5, y = 0.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = -0.5, y = 2.5}, {}},
    {"stone-wall", {x = -1.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 1.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
    {"stone-wall", {x = 0.5, y = 2.5}, {}},
    {"stone-wall", {x = 2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 1, max = 500}}, }},
  },
}
