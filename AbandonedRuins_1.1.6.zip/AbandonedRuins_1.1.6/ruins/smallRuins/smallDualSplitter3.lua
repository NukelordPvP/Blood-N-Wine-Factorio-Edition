return
{
  entities =
  {
    {"fast-splitter", {x = 0.5, y = 0}, {dir = "east", }},
    {"fast-transport-belt", {x = 1.5, y = -0.5}, {}},
    {"fast-transport-belt", {x = -1.5, y = 1.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 1.5, y = 1.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 1.5, y = 0.5}, {dir = "east", }},
    {"fast-transport-belt", {x = 2.5, y = 1.5}, {dir = "east", }},
  },
}
