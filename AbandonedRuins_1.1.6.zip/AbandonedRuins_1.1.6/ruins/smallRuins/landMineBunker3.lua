return
{
  entities =
  {
    {"land-mine", {x = -1, y = -1}, {force = "enemy", }},
    {"stone-wall", {x = -1.5, y = -1.5}, {}},
    {"stone-wall", {x = 1.5, y = -0.5}, {}},
    {"stone-wall", {x = 2.5, y = 1.5}, {}},
    {"stone-wall", {x = 2.5, y = 3.5}, {}},
  },
}
