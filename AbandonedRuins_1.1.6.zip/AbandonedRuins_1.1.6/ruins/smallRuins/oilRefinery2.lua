return
{
  entities =
  {
    {"oil-refinery", {x = -0.5, y = -1.5}, {dir = "south", dmg = {dmg = {type = "random", min = 7, max = 70}}, }},
    {"pipe", {x = -2.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = -3.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -0.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = 1.5, y = 1.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = 0.5, y = 1.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = 2.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -2.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = -3.5, y = 2.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -0.5, y = 3.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe", {x = -0.5, y = 2.5}, {dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = -1.5, y = 3.5}, {dir = "east", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
    {"pipe-to-ground", {x = -1.5, y = 2.5}, {dir = "west", dmg = {dmg = {type = "random", min = 20, max = 110}},  }},
    {"pipe-to-ground", {x = 0.5, y = 3.5}, {dir = "west", dmg = {dmg = {type = "random", min = 20, max = 110}}, }},
  },
}
