return
{
  entities =
  {
    {"logistic-robot-remnants", {x = -1.25, y = -2.41}, {}},
    {"logistic-robot-remnants", {x = 0.35, y = -2.23}, {}},
    {"construction-robot-remnants", {x = 3.26, y = -2.7}, {}},
    {"medium-electric-pole-remnants", {x = 1.5, y = -0.5}, {}},
    {"construction-robot-remnants", {x = 0.5, y = -1.71}, {}},
    {"storage-chest-remnants", {x = 3.5, y = -0.5}, {}},
    {"storage-chest-remnants", {x = 2.5, y = -0.5}, {}},
    {"passive-provider-chest-remnants", {x = -2.5, y = 1.5}, {}},
    {"logistic-robot-remnants", {x = -2.7, y = 0.01}, {}},
    {"construction-robot-remnants", {x = -0.36, y = 1.54}, {}},
    {"logistic-robot-remnants", {x = -1.15, y = 3.08}, {}},
    {"logistic-robot-remnants", {x = 0.04, y = 2.94}, {}},
    {"roboport-remnants", {x = 2, y = 2}, {}},
  },
}
