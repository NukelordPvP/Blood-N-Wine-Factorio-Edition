return
{
  entities =
  {
    {"splitter", {x = 0.5, y = 0}, {dir = "east", }},
    {"transport-belt", {x = 1.5, y = -0.5}, {}},
    {"transport-belt", {x = -1.5, y = 0.5}, {dir = "east", }},
    {"transport-belt", {x = -1.5, y = 1.5}, {dir = "east", }},
    {"splitter", {x = -0.5, y = 1}, {dir = "east", }},
    {"transport-belt", {x = 0.5, y = 1.5}, {dir = "east", }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "east", }},
    {"transport-belt", {x = 1.5, y = 0.5}, {dir = "east", }},
    {"transport-belt", {x = 2.5, y = 1.5}, {dir = "east", }},
    {"transport-belt", {x = 2.5, y = 0.5}, {dir = "east", }},
  },
}
