return
{
  entities =
  {
    {"electric-mining-drill", {x = -1.5, y = -0.5}, {dir = "south", }},
    {"electric-mining-drill", {x = 1.5, y = -0.5}, {dir = "south", }},
    {"transport-belt", {x = -1.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = -0.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 0.5, y = 1.5}, {dir = "west", }},
    {"transport-belt", {x = 2.5, y = 1.5}, {dir = "west", }},
  },
}
