return
{
  entities =
  {
    {"wooden-chest", {x = -3.5, y = -3.5}, {items = {["iron-plate"] = {type = "random", min = 1, max = 50}}, }},
    {"fast-inserter", {x = -3.5, y = -2.5}, {}},
    {"fast-inserter", {x = -0.5, y = -2.5}, {}},
    {"fast-inserter", {x = 2.5, y = -2.5}, {}},
    {"fast-transport-belt", {x = -2.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = -0.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = -1.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = -0.5, y = -1.5}, {dir = "south", }},
    {"fast-transport-belt", {x = 1.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = 0.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = 3.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = 2.5, y = -0.5}, {dir = "west", }},
    {"fast-transport-belt", {x = 2.5, y = -1.5}, {dir = "south", }},
    {"fast-inserter", {x = -0.5, y = 1.5}, {dir = "south", }},
    {"fast-transport-belt", {x = -0.5, y = 0.5}, {}},
    {"fast-inserter", {x = 2.5, y = 1.5}, {dir = "south", }},
    {"fast-transport-belt", {x = 2.5, y = 0.5}, {}},
    {"small-electric-pole-remnants", {x = -2.5, y = 2.5}, {}},
    {"steel-furnace", {x = -1, y = 3}, {}},
    {"steel-furnace", {x = 2, y = 3}, {}},
    {"small-electric-pole-remnants", {x = 3.5, y = 2.5}, {}},
  },
}
