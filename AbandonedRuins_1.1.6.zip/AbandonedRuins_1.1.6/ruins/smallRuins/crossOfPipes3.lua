return
{
  entities =
  {
    {"pipe", {x = -2.5, y = 0.5}, {}},
    {"pipe-to-ground", {x = -3.5, y = 0.5}, {dir = "east", }},
    {"pipe", {x = -0.5, y = 0.5}, {}},
    {"pipe", {x = 0.5, y = 0.5}, {}},
    {"pipe", {x = 1.5, y = 0.5}, {}},
    {"pipe-to-ground", {x = 3.5, y = 0.5}, {dir = "west", }},
  },
}
