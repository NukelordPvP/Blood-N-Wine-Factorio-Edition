return
{
  entities =
  {
    {"burner-mining-drill", {x = 1, y = 1}, {dir = "east", }},
    {"wooden-chest", {x = 2.5, y = 0.5}, {items = {["iron-ore"] = {type = "random", min = 1, max = 90}}, }},
  },
}
