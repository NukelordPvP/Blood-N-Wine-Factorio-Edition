return
{
  entities =
  {
    {"straight-rail", {x = 1, y = -1}, {dir = "northwest", }},
    {"straight-rail", {x = 1, y = -3}, {dir = "southeast", }},
    {"curved-rail", {x = 0, y = 2}, {dir = "east", }},
    {"straight-rail", {x = -1, y = -1}, {dir = "southeast", }},
  },
}
