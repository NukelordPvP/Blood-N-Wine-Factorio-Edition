return
{
  entities =
  {
    {"inserter", {x = -1.5, y = -2.5}, {dmg = {dmg = {type = "random", min = 25, max = 150}}, }},
    {"assembling-machine-2", {x = -2.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 50, max = 250}}, }},
    {"inserter", {x = 1.5, y = -0.5}, {dmg = {dmg = 44}, }},
    {"transport-belt", {x = -0.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 25, max = 90}}, }},
    {"transport-belt", {x = 1.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 25, max = 90}}, }},
    {"transport-belt", {x = 0.5, y = 1.5}, {dir = "west", dmg = {dmg = {type = "random", min = 25, max = 90}}, }},
  },
}
