return
{
  tiles =
  {
    {"stone-path", {x = -3.5, y = -2}},
    {"stone-path", {x = -3.5, y = -1}},
    {"stone-path", {x = -2.5, y = -3}},
    {"stone-path", {x = -2.5, y = -2}},
    {"stone-path", {x = -2.5, y = -1}},
    {"stone-path", {x = -2.5, y = 0}},
    {"stone-path", {x = -1.5, y = -3}},
    {"stone-path", {x = -1.5, y = -2}},
    {"stone-path", {x = -1.5, y = -1}},
    {"stone-path", {x = -1.5, y = 0}},
    {"stone-path", {x = -1.5, y = 1}},
    {"stone-path", {x = -0.5, y = -1}},
    {"stone-path", {x = -0.5, y = 0}},
    {"stone-path", {x = -0.5, y = 1}},
    {"stone-path", {x = -0.5, y = 2}},
    {"stone-path", {x = 0.5, y = -3}},
    {"stone-path", {x = 0.5, y = -2}},
    {"stone-path", {x = 0.5, y = -1}},
    {"stone-path", {x = 0.5, y = 0}},
    {"stone-path", {x = 0.5, y = 1}},
    {"stone-path", {x = 1.5, y = -3}},
    {"stone-path", {x = 1.5, y = -2}},
    {"stone-path", {x = 1.5, y = -1}},
    {"stone-path", {x = 1.5, y = 0}},
    {"stone-path", {x = 2.5, y = -2}},
    {"stone-path", {x = 2.5, y = -1}},
  }
}
