return
{
  entities =
  {
    {"boiler", {x = -3, y = -2.5}, {dir = "east", }},
    {"steam-engine", {x = 0.5, y = -2.5}, {dir = "east", }},
    {"pipe", {x = -3.5, y = -0.5}, {}},
    {"small-electric-pole-remnants", {x = -1.5, y = -0.5}, {}},
    {"boiler", {x = -3, y = 1.5}, {dir = "east", }},
    {"steam-engine-remnants", {x = 0.5, y = 1.5}, {dir = "east", }},
  },
}
