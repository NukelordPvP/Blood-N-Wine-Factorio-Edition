return
{
  entities =
  {
    {"transport-belt", {x = -2.5, y = 0.5}, {dir = "west", }},
    {"electric-mining-drill", {x = -1.5, y = 2.5}, {}},
    {"transport-belt", {x = -1.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = -0.5, y = 0.5}, {dir = "west", }},
    {"transport-belt", {x = 1.5, y = 0.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 50}}, }},
    {"electric-mining-drill", {x = 1.5, y = 2.5}, {}},
    {"transport-belt", {x = 2.5, y = 0.5}, {dir = "west", dmg = {dmg = {type = "random", min = 5, max = 50}}, }},
  },
}
