return
{
  entities =
  {
    {"lab", {x = 1.5, y = -0.5}, {dmg = {dmg = {type = "random", min = 0, max = 30}}, }},
    {"wooden-chest", {x = -1.5, y = 0.5}, {items = {["logistic-science-pack"] = 50}, }},
  },
}
