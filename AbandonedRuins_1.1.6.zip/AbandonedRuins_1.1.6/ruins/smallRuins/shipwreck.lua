return
{
  entities =
  {
    {"small-scorchmark", {x = -1.17, y = -1.19}, {}},
    {"rock-huge", {x = 0.06, y = -2.79}, {}},
    {"dry-tree", {x = 2.21, y = -3.39}, {}},
    {"crash-site-spaceship-wreck-small-6", {x = -1.91, y = -1.45}, {}},
    {"medium-scorchmark", {x = 1.65, y = 1.08}, {}},
    {"small-scorchmark", {x = -1.23, y = 2.32}, {}},
    {"crash-site-spaceship-wreck-small-4", {x = 1.86, y = 1.31}, {}},
    {"small-remnants", {x = -1.5, y = 2.5}, {}},
  },
}
