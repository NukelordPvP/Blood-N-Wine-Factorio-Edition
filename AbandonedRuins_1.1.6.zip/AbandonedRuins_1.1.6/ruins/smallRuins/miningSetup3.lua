return
{
  entities =
  {
    {"wooden-chest", {x = 0.5, y = -0.5}, {items = {coal = {type = "random", min = 1, max = 75}}, }},
    {"burner-mining-drill", {x = 1, y = 1}, {dmg = {dmg = {type = "random", min = 20, max = 100}}, }},
  },
}
