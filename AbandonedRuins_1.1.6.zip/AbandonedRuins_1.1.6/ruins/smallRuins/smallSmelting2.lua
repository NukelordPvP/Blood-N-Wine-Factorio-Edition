return
{
  entities =
  {
    {"stone-furnace", {x = -2, y = -2}, {}},
    {"wooden-chest", {x = -1.5, y = 0.5}, {items = {coal = {type = "random", min = 1, max = 10}, ["copper-ore"] = {type = "random", min = 1, max = 40}}, }},
  },
}
