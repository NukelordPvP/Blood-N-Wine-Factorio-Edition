return
{
  entities =
  {
    {"pipe", {x = -2.5, y = -2.5}, {dead = 0.4}},
    {"pipe", {x = -1.5, y = -2.5}, {dead = 0.4}},
    {"medium-electric-pole-remnants", {x = 2.5, y = -2.5}, {}},
    {"chemical-plant", {x = -0.5, y = -0.5}, {dir = "south", dead = 0.4}},
    {"long-handed-inserter", {x = 1.5, y = -0.5}, {dir = "east", dead = 0.4}},
    {"iron-chest", {x = 3.5, y = -0.5}, {dead = 0.4}},
    {"pipe-to-ground", {x = -3.5, y = 1.5}, {dir = "west", dead = 0.4}},
    {"pipe-to-ground", {x = -0.5, y = 1.5}, {dir = "east", dead = 0.4}},
    {"pipe", {x = -1.5, y = 1.5}, {dead = 0.4}},
    {"pipe", {x = 1.5, y = 1.5}, {dead = 0.4}},
    {"pipe", {x = 0.5, y = 1.5}, {dead = 0.4}},
    {"pipe", {x = 2.5, y = 1.5}, {dead = 0.4}},
    {"pipe", {x = -2.5, y = 2.5}, {dead = 0.4}},
    {"pipe", {x = -3.5, y = 2.5}, {dead = 0.4}},
    {"pipe", {x = -1.5, y = 2.5}, {dead = 0.4}},
  },
}
