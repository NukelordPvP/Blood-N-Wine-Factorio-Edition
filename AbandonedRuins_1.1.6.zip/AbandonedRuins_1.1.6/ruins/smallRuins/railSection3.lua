return
{
  entities =
  {
    {"straight-rail", {x = -1, y = -3}, {dir = "southwest", }},
    {"straight-rail", {x = -1, y = -1}, {dir = "northeast", }},
    {"curved-rail", {x = 0, y = 0}, {dir = "southeast", }},
    {"straight-rail", {x = 1, y = -1}, {dir = "southwest", }},
    {"straight-rail", {x = 1, y = 1}, {dir = "northeast", }},
    {"straight-rail", {x = 3, y = 1}, {dir = "southwest", }},
  },
}
