return
{
  entities =
  {
    {"lab", {x = -2, y = -2}, {dmg = {dmg = {type = "random", min = 20, max = 150}}, }},
    {"small-electric-pole-remnants", {x = 0, y = -2}, {}},
    {"lab", {x = 2, y = -2}, {dmg = {dmg = {type = "random", min = 20, max = 150}}, }},
    {"lab", {x = -2, y = 1}, {dmg = {dmg = {type = "random", min = 20, max = 150}}, }},
    {"inserter", {x = 0, y = 0}, {dir = "east", dmg = {dmg = {type = "random", min = 0, max = 50}}}},
    {"inserter", {x = 0, y = -1}, {dir = "east", dmg = {dmg = {type = "random", min = 0, max = 50}}}},
    {"lab", {x = 2, y = 1}, {dmg = {dmg = {type = "random", min = 20, max = 150}}, }},
  },
}
