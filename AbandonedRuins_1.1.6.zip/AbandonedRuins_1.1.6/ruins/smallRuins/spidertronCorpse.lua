return
{
  entities =
  {
    {"destroyer-remnants", {x = -2.02, y = -2.45}, {dir = "south", }},
    {"destroyer-remnants", {x = -1.59, y = -3.5}, {dir = "south", }},
    {"destroyer-remnants", {x = -0.23, y = -3.16}, {dir = "south", }},
    {"spidertron-remnants", {x = 0.41, y = 0.29}, {}},
    {"destroyer-remnants", {x = -3.58, y = 2.23}, {dir = "south", }},
    {"distractor-remnants", {x = -2.64, y = 3.2}, {dir = "south", }},
  },
}
