require "util"
require "utils"
require "particles"
local format_number = util.format_number

local lightred = {r = 1, g = 0.5, b = 0.5}
local yellow = {r = 1, g = 1, b = 0}


local curses = {
'biter_attractor',
'reduced_health',
'reduced_crafting_speed',
'reduced_moving_speed',
'reduced_mining_speed',

'acid_spiller',
'fire_spiller',
'poisonous',
'shock_hazard',
'smoker',
'ripped_backpack',

'corona_virus',
'muscle_paralysis'
--'open_wounds',
--'trembling_hands'
}


function ReadRunTimeSettings(event)
global.setting_enable_curses     = settings.global["dc_enable_curses"].value
global.setting_curse_duration    = settings.global["dc_curse_duration"].value
global.setting_death_scream      = settings.global["dc_enable_screams"].value
global.setting_stack_curse_duration = settings.global["dc_stack_curse_duration"].value

if event and event.player_index then 
	local player = game.players[event.player_index]
	update_player_gui(player)
	end
end
script.on_event(defines.events.on_runtime_mod_setting_changed, ReadRunTimeSettings)




function setup_mod_vars() 
global.player_curse = global.player_curse  or {}
global.player_deaths= global.player_deaths or {}
global.player_corpses= global.player_corpses or {}
ReadRunTimeSettings()
end

function on_init()
setup_mod_vars()
RegisterEvents()

for name,player in pairs (game.players) do
	global.player_deaths[name] = global.player_deaths[name] or 0
	global.player_corpses[name]=global.player_corpses[name] or {}
	end

end


function on_load()
RegisterEvents()
end
function on_configuration_changed()
setup_mod_vars()
end
script.on_init(on_init)
script.on_configuration_changed(on_configuration_changed)
script.on_load(on_load)

function RegisterEvents()
if remote.interfaces["space-exploration"] then 
   script.on_event(remote.call("space-exploration", "get_on_player_respawned_event"), function (event)
	on_player_respawned(event)
   end)
end
end







function on_player_respawned(event)
local player = game.players[event.player_index]

if global.setting_enable_curses then
	AddCurseToPlayer(player)
	end
update_player_gui(player)	
end

script.on_event(defines.events.on_player_respawned, function(event)
on_player_respawned(event)
end)



script.on_event(defines.events.on_pre_player_died, function(event)
local player = game.players[event.player_index]
local name = player.name
if not global.player_deaths[name] then global.player_deaths[name]=0 end

global.player_deaths[name] = global.player_deaths[name] + 1
update_player_gui(player)

if settings.get_player_settings(player)["dc_enable_corpse_tag"].value then
	local tag = player.force.add_chart_tag(player.surface, {icon = {type = "item", name = "power-armor"},text=player.name,position=player.position})
	player.print ({'death_position',get_gps_tag(player.position)},yellow)
	global.player_corpses[name] = global.player_corpses[name] or {}
	table.insert(global.player_corpses[name],{map_tag=tag, until_tick=game.tick + 60*60*15, position=player.position})
	end

if global.setting_death_scream then 
	player.surface.play_sound{path='dc_deah_scream', position=player.position, volume_modifie=1.5}
	end

create_blood_particles(player.surface, 50, player.position)
create_guts_particles(player.surface, 50, player.position)

--global.player_curse[name] = {name='apply_curse', until_tick=game.tick + 60*60*60}
end)






function ShockHazard(player)
local enemy = player.surface.find_entities_filtered{position=player.position,radius=20,limit=100}
for k=#enemy,1,-1 do 
	if ((enemy[k].name=='entity-ghost') or (enemy[k].type=='entity-ghost') or (not enemy[k].destructible)) or (not enemy[k].health) then table.remove(enemy,k) end
	end
if #enemy>0 then
for x=1,math.random(3)+2 do
	local target = enemy[math.random(#enemy)]
	if player.character and player.character.valid and target and target.valid and target.destructible then
		target.surface.create_entity{name = 'electric-beam', position=player.position, source = player.character,target=target, duration=40}
		end
	end
end
end



function restore_player(player,curse)
if curse=='reduced_crafting_speed' then 
	player.character_crafting_speed_modifier = 0
elseif curse=='reduced_moving_speed' then 
	player.character_running_speed_modifier = 0
elseif curse=='reduced_mining_speed' then 
	player.character_mining_speed_modifier = 0
	end 

if game.active_mods['RPGsystem'] then
	if curse=='reduced_crafting_speed' then 
		remote.call('RPG','OtherEventsByPlayer',player,'adjust_player_stats','character_crafting_speed_modifier')
	elseif curse=='reduced_moving_speed' then 
		remote.call('RPG','OtherEventsByPlayer',player,'adjust_player_stats','character_running_speed_modifier')
	elseif curse=='reduced_mining_speed' then 
		remote.call('RPG','OtherEventsByPlayer',player,'adjust_player_stats','character_mining_speed_modifier')
		end
	end
global.player_curse[player.name]=nil
player.print ({'no_longer_cursed'},yellow)
update_player_gui(player)	
end 


function Spill_stack(player)
local inv = player.character.get_inventory(defines.inventory.character_main)
local items = {}
for i = 1, #inv do
    local stack = inv[i]
	if stack and stack.valid and stack.valid_for_read then 
		if not (stack.is_blueprint or stack.is_blueprint_book or stack.is_item_with_inventory or stack.is_deconstruction_item or stack.grid ~= nil) then
			table.insert(items,stack) 
			end
		end
	end

if #items>0 then 
	local stack = items[math.random(#items)]
	local copy_of_item_stack = { name = stack.name, count = stack.count, health = stack.health or nil, durability = stack.durability or nil }
	local count = math.random(copy_of_item_stack.count)
	copy_of_item_stack.count=count
	player.surface.spill_item_stack(player.position, copy_of_item_stack, false)
	player.character.remove_item({name=copy_of_item_stack.name, count=count})
	create_ceiling_drops(player.surface, player.position,6)
	end
end



function CoronaCheck(player)
create_blood_particles(player.surface, 2+ math.random(5), player.position)
local character = player.character
local force = player.force
local another = player.surface.find_entities_filtered{position=player.position,radius=24,type='character'}
for _,other in pairs(another) do
	if character and character.valid and other and other.valid and other ~= character then
		other.damage(50, force)
		character.damage(50, force)
		if other and other.valid and other.player and other.player.valid and 
			(not global.player_curse[other.player.name]) then AddCurseToPlayer(game.players[other.player.name],'corona_virus') end
		end
	end
end




function get_acid()
local name = 'acid-splash-fire-worm-small'
local sname = 'acid-sticker-small'
local e = game.forces.enemy.evolution_factor
if e>0.4 then name = 'acid-splash-fire-worm-medium' sname = 'acid-sticker-medium' end
if e>0.6 then name = 'acid-splash-fire-worm-big' sname = 'acid-sticker-big' end
if e>0.85 then name = 'acid-splash-fire-worm-behemoth' sname = 'acid-sticker-behemoth' end
return {name,sname}
end





script.on_nth_tick(60, function (event)
for _,player in pairs (game.connected_players) do
	if global.player_curse[player.name] and player.character and player.character.valid then
		local curse = global.player_curse[player.name].name
		local tick  = global.player_curse[player.name].until_tick
		update_player_gui(player)
		
		if game.tick > tick then restore_player(player,curse)
			elseif player.character and player.character.valid then
				if curse=='apply_curse' then AddCurseToPlayer(player)
				elseif curse=='biter_attractor' then player.surface.create_trivial_smoke{name='turbine-smoke', position=player.position} if game.tick%1200==0 then CallFrenzyAttack(player.surface,player.character) end
				elseif curse=='poisonous' and game.tick%1200==0 then player.surface.create_entity{name = 'poison-cloud', position = player.position}
				elseif curse=='acid_spiller' and game.tick%720==0 then player.surface.create_entity{name = get_acid()[1], position = player.position}  player.surface.create_entity {name=get_acid()[2], target = player.character, position=player.position}
				elseif curse=='shock_hazard' then create_spark_particles(player.surface, 5+ math.random(10), player.position) if game.tick%660==0 then ShockHazard(player) end
				elseif curse=='fire_spiller' and game.tick%660==0 then player.surface.create_entity{name = 'fire-flame', position = player.position} player.surface.create_entity {name='fire-sticker', target = player.character, position=player.position}
				elseif curse=='reduced_health' and player.character.health>100 then player.character.health=100 create_blood_particles(player.surface, 2+ math.random(5), player.position)
				elseif curse=='reduced_crafting_speed' then  if player.character_crafting_speed_modifier>-0.5 then player.character_crafting_speed_modifier = -0.5  end
				elseif curse=='reduced_moving_speed' then create_water_particles(player.surface, 2+ math.random(4), player.position) if player.character_running_speed_modifier>-0.5 then player.character_running_speed_modifier = -0.5  end
				elseif curse=='reduced_mining_speed' then if player.character_mining_speed_modifier>-0.5 then player.character_mining_speed_modifier = -0.5 end
				elseif curse=='smoker' then player.surface.pollute(player.position,25) player.surface.create_trivial_smoke{name='fire-smoke-on-adding-fuel', position=player.position}  player.surface.create_trivial_smoke{name='turbine-smoke', position=player.position}
				elseif curse=='ripped_backpack' and game.tick%1200==0 then Spill_stack(player)
				elseif curse=='corona_virus' and game.tick%120==0 then CoronaCheck(player)
				elseif curse=='muscle_paralysis' and game.tick%300==0 and math.random(2)==1 then player.surface.create_entity {name='stun-sticker', target = player.character, position=player.position}
				end
			end
		end
	end
end)


script.on_nth_tick(60*60, function (event)
for _,player in pairs (game.players) do
	if global.player_corpses[player.name] then
		for t=#global.player_corpses[player.name],1,-1 do
			local tag  = global.player_corpses[player.name][t].map_tag
			local tick = global.player_corpses[player.name][t].until_tick
			if game.tick > tick then
				if tag and tag.valid then tag.destroy() end
				table.remove(global.player_corpses[player.name],t)
				end
			end
		end
	end
end)



function AddCurseToPlayer(player,curse)
global.player_deaths[player.name] =global.player_deaths[player.name] or 0
if not curse then curse = curses[math.random(#curses)] end
local t = math.min(global.player_deaths[player.name] + math.random (math.max(1,global.player_deaths[player.name]) * 2), global.setting_curse_duration)

local prev_curse = global.player_curse[player.name]
local extra_curse = 0
if prev_curse and prev_curse.until_tick and prev_curse.name ~= 'apply_curse' then extra_curse = prev_curse.until_tick - game.tick end

local duration =  t*60*60 
if global.setting_stack_curse_duration then duration=duration + extra_curse end
global.player_curse[player.name] = {
	name=curse,
	until_tick=game.tick + duration}
player.print({'you_are_cursed',{curse}},lightred)
end


function reset_player_vars(player)
global.player_curse[player.name]  =nil
global.player_deaths[player.name] =0
end


function onPlayerJoin(event)
local player = game.players[event.player_index]
global.player_deaths[player.name] =global.player_deaths[player.name] or 0
update_player_gui(player)
end
script.on_event(defines.events.on_player_joined_game, onPlayerJoin)



--- GUI
function update_player_gui(player)
local DeathFrame = player.gui.top.DeathFrame
local tab
if not DeathFrame then 
	DeathFrame = player.gui.top.add{name="DeathFrame", direction = "horizontal", type="frame" }--style=mod_gui.frame_style
 	DeathFrame.style.minimal_height = 30
--	DeathFrame.style.minimal_width = 200
	end

DeathFrame.visible = settings.get_player_settings(player)["dc_show_death_count"].value or global.setting_enable_curses

if DeathFrame.visible then
	local tab = DeathFrame.death_tab
	if tab then tab.destroy() end
	tab = DeathFrame.add{type = "table", name = "death_tab", column_count = 2}
	
	
	if settings.get_player_settings(player)["dc_show_death_count"].value then
		local btd = tab.add{type="button", 
				caption='[img=virtual-signal/dc_signal_death]: '.. format_number( global.player_deaths[player.name]),
				style = 'rounded_button', tooltip='Death counter'}
		btd.enabled =false
		btd.style.font= "default-large-bold"
		btd.style.width = 120
		end
	if global.setting_enable_curses and global.player_curse[player.name] and 
		global.player_curse[player.name].name ~= 'apply_curse' then
		
		if not (player.character and player.character.valid) then global.player_curse[player.name].until_tick = global.player_curse[player.name].until_tick + 60  end
		
		local btc = tab.add{type="button", 
			caption='[img=virtual-signal/dc_signal_curse] [color=1,0.5,0.5]'.. format_time_from_tick(global.player_curse[player.name].until_tick)..'[/color]',
	        style = 'rounded_button', tooltip={"",{'curse'},': ',{global.player_curse[player.name].name}}}
		btc.style.font= "default-large-bold"
		btc.enabled =false
		btc.style.width = 120
		btc.style.font_color = lightred
		end
	end
end





function CallFrenzyAttack(surface,target,limit,multiplier)
if surface.map_gen_settings.autoplace_controls and surface.map_gen_settings.autoplace_controls["enemy-base"] and
	surface.map_gen_settings.autoplace_controls["enemy-base"].size and
    surface.map_gen_settings.autoplace_controls["enemy-base"].size>0 then

local position
if target.type and target.valid 
	then 
	position=target.position
	else
	position = target
	end

local Min = 5
local Max = 20
local Dist = 1000

local spawn = surface.find_entities_filtered({type = "unit-spawner",limit=1,position=position,radius=Dist})
if #spawn>0 then
local force = spawn[1].force


local aliens = Max * force.evolution_factor
if aliens < Min then aliens=Min end
if limit and aliens>limit then aliens=limit end
if multiplier then aliens=math.floor(aliens * multiplier) end 

	if target.type and target.valid then 
		local sent = surface.set_multi_command({
			command = {type=defines.command.attack, target=target, distraction = defines.distraction.by_anything },
			unit_count = aliens,
			force = force,
			unit_search_distance = Dist,
		})
		else
		local sent = surface.set_multi_command({
			command = {type=defines.command.attack_area, destination=position, radius=50, distraction = defines.distraction.by_anything },
			unit_count = aliens,
			force = force,
			unit_search_distance = Dist,
		})
		end
	end
end
end



------------------------------------------------------------------------------------------------------------------------
---------------------------------------------INTERFACE------------------------------------------------------------------
local interface = {}

--  /c remote.call('death_curses','CursePlayer','player_name','reduced_moving_speed')    -- check curse names on top
function interface.CursePlayer(player_name, curse_name)
if not (curse_name and in_list(curses,curse_name)) then curse_name=nil end
if game.players[player_name] then 
	AddCurseToPlayer(game.players[player_name],curse_name)
	end
end

function interface.RemoveCurse(player_name)
if game.players[player_name] and global.player_curse[player_name] then
	local curse = global.player_curse[player_name].name
	restore_player(game.players[player_name],curse)
	end
end

remote.add_interface("death_curses", interface)
