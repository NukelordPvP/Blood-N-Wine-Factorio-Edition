local shared_constants = {}

shared_constants.infinity_pipe_capacities = { 100, 500, 1000, 5000, 10000, 25000, 50000, 100000 }

return shared_constants
