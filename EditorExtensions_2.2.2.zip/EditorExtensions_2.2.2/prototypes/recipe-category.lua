data:extend({
  {
    type = "recipe-category",
    name = "ee-testing-tool",
  },
})
