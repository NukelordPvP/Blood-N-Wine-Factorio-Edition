ErmZergExp = {}

require("__erm_zerg_exp__/global")

local ErmConfig = require("__enemyracemanager__/lib/global_config")

---
--- This is REQUIRED to register the mod as an ERM race mod.
--- There are further data processing in data-updates and data-final-fixes.
---
data.erm_registered_race = data.erm_registered_race or {}
data.erm_registered_race[MOD_NAME] = true
---
--- This set up specification for default autospawn.  This is used as reference.  The data will be balanced in
--- __enemyracemanager__/prototype/extend-default-autoplace.lua
---
data.erm_spawn_specs = data.erm_spawn_specs or {}
table.insert(data.erm_spawn_specs, {
    mod_name = MOD_NAME,
    force_name = FORCE_NAME,
    moisture = 1, -- 1 = Dry and 2 = Wet
    aux = 2, -- 1 = red desert, 2 = sand
    elevation = 3, -- 1,2,3 (1 low elevation, 2. medium, 3 high elavation)
    temperature = 3, -- 1,2,3 (1 cold, 2. normal, 3 hot)
})

---
--- This set of data replace vanilla biters for the menu.  It may interfere with other mods that use vanilla biter.
---
data.erm_menu_replacement = data.erm_menu_replacement or {}
data.erm_menu_replacement[MOD_NAME] = {
    race = MOD_NAME,
    level = 3,
    ["unit"] = {
        ["small-biter"] = 'zergling',
        ["small-spitter"] = 'mutalisk',
        ["medium-biter"] = 'hydralisk',
        ["medium-spitter"] = 'ultralisk',
        ["big-biter"] = 'hydralisk',
        ["big-spitter"] = 'devourer',
        ["behemoth-biter"] = "ultralisk",
        ["behemoth-spitter"] = "devourer",
    },
    ["turret"] = {
        ["small-worm-turret"] = 'sunken_colony',
        ["medium-worm-turret"] = 'sunken_colony',
        ["big-worm-turret"] = 'sunken_colony',
        ["behemoth-worm-turret"] = 'sunken_colony',
    },
    ["turret-scale"] = 0.8,
    ["unit-spawner"] = {
        ["biter-spawner"] = 'hive',
        ["spitter-spawner"] = 'spawning_pool',
    },
    ["unit-spawner-scale"] = 0.8
}

require "prototypes/decoratives"
require "prototypes/projectiles"
require "prototypes/boss-projectiles"
require "prototypes.enemy.zergling"
require "prototypes.enemy.mutalisk"
require "prototypes.enemy.hydralisk"
require "prototypes.enemy.ultralisk"
require "prototypes.enemy.devourer"
require "prototypes.enemy.guardian"
require "prototypes.enemy.overlord"
require "prototypes.enemy.lurker"
require "prototypes.enemy.drone"
require "prototypes.enemy.defiler"
require "prototypes.enemy.queen"
require "prototypes.enemy.infested"
require "prototypes.enemy.broodling"
require "prototypes.enemy.scourge"
require "prototypes.enemy.parasite"

require "prototypes.building.building_death"
require "prototypes.building.hydraden"
require "prototypes.building.spawning_pool"
require "prototypes.building.hatchery"
require "prototypes.building.lair"
require "prototypes.building.hive"
require "prototypes.building.boss_overmind"
require "prototypes.building.spore_colony"
require "prototypes.building.sunken_colony"
require "prototypes.building.chamber"
require "prototypes.building.spire"
require "prototypes.building.greater_spire"
require "prototypes.building.queen_nest"
require "prototypes.building.defiler_mound"
require "prototypes.building.ultralisk_cavern"
require "prototypes.building.nyduspit"
require "prototypes.building.infested_cmd"

local max_level = ErmConfig.MAX_LEVELS

for i = 1, max_level + ErmConfig.MAX_ELITE_LEVELS do
    ErmZergExp.make_zergling(i)
    ErmZergExp.make_hydralisk(i)
    ErmZergExp.make_mutalisk(i)
    ErmZergExp.make_ultralisk(i)
    ErmZergExp.make_devourer(i)
    ErmZergExp.make_guardian(i)
    ErmZergExp.make_overlord(i)
    ErmZergExp.make_lurker(i)
    ErmZergExp.make_drone(i)
    ErmZergExp.make_defiler(i)
    ErmZergExp.make_queen(i)
    ErmZergExp.make_infested(i)
    ErmZergExp.make_broodling(i)
    ErmZergExp.make_scourge(i)
    ErmZergExp.make_parasite(i)
end

local boss_level = ErmConfig.BOSS_LEVELS

local boss_unit_ai = { destroy_when_commands_fail = true, allow_try_return_to_spawner = false }
local override_units = {"zergling","broodling","hydralisk","mutalisk","devourer","guardian","overlord","lurker","drone","defiler","queen","infested","scourge","parasite","ultralisk"}

for i = 1, #boss_level do
    local level = boss_level[i]
    ErmZergExp.make_zergling(level)
    ErmZergExp.make_hydralisk(level)
    ErmZergExp.make_mutalisk(level)
    ErmZergExp.make_ultralisk(level)
    ErmZergExp.make_devourer(level)
    ErmZergExp.make_guardian(level)
    ErmZergExp.make_overlord(level)
    ErmZergExp.make_lurker(level)
    ErmZergExp.make_drone(level)
    ErmZergExp.make_defiler(level)
    ErmZergExp.make_queen(level)
    ErmZergExp.make_infested(level)
    ErmZergExp.make_broodling(level)
    ErmZergExp.make_scourge(level)
    ErmZergExp.make_parasite(level)

    ErmZergExp.make_boss_hive(level, ErmConfig.BOSS_BUILDING_HITPOINT[i])

    for _, unit in pairs(override_units) do
        data.raw["unit"][MOD_NAME .. "/" .. unit .. "/" .. level]["ai_settings"] = boss_unit_ai
    end
end

for i = 1, max_level do
    ErmZergExp.make_hatchery(i)
    ErmZergExp.make_lair(i)
    ErmZergExp.make_hive(i)
    ErmZergExp.make_hydraden(i)
    ErmZergExp.make_spawning_pool(i)
    ErmZergExp.make_chamber(i)
    ErmZergExp.make_spire(i)
    ErmZergExp.make_greater_spire(i)
    ErmZergExp.make_defiler_mound(i)
    ErmZergExp.make_queen_nest(i)
    ErmZergExp.make_ultralisk_cavern(i)
    ErmZergExp.make_nyduspit(i)
    ErmZergExp.make_spore_colony(i)
    ErmZergExp.make_sunken_colony(i)
    ErmZergExp.make_infested_cmd(i)
end





