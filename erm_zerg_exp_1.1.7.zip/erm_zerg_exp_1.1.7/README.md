Zerg race for Enemy Race Manager Experimental (HD Assets included - will be released as an additional mod soon to make downloading updates easier and optionally merge the HD Assets with heyqule's original mod).

A few experimental tweaks differing from heyqule's original ERM Zerg:

- Updated the sprites to higher resolution sprites.
- Added Zerg style creep as decoratives (based on the template of the vanilla Biter creep which can theoretically be removed by the Creep Cleaner mod).
- Slightly modified the unit spawns to try and match Zerg unit spawns a little more with the structure they"re associated with; units higher in the Zerg tech tree will have a greater chance of spawning at higher evolution levels, while from the same structure more common Zerg units will spawn early on.
- Buffed the attack range of Zerg Queens, Guardians, and Defilers to suit the original feel and compete with longer ranged modded weapons.
- The Zerg Drone now has a construction animation as it morphs into turrets (the Drone is sacrificed in the process as per lore).
- Added 1 building & 3 additional Zerg units: Infested Command Centre, Broodlings, Queen's Parasite, and Scourge.
- The Queen's Snare attack has also been moved to the new Parasite unit which is basically a suicidal "projectile" type unit that uses Snare and has a chance to spawn Broodlings; the Queen's attack now flings these Parasites from range at its targets.
- The Devourer additionally spawns the new Scourge unit while attacking.
- The Infested Command Centre is a new Zerg unit_spawner building which spawns Infested Terrans.

Any other work and coding I 100% attribute to and appreciate the original ERM - Zerg Units modder heyqule: https://mods.factorio.com/mod/erm_zerg

I recommend Krastorio 2 if you want harvestable creep to spawn, but beware Krastorio 2's creep will spawn in the middle of the Zerg creep and make it look a little patchy (see the lighter purple ground material you see around the Hive in the 2nd picture).

If there are any updates to the base ERM mods or Factorio which require this mod to be updated please let me know.