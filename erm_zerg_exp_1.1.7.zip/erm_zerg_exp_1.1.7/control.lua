--
-- Created by IntelliJ IDEA.
-- User: heyqule
-- Date: 12/20/2020
-- Time: 5:04 PM
-- To change this template use File | Settings | File Templates.
--

local Game = require("__stdlib__/stdlib/game")

local ErmConfig = require("__enemyracemanager__/lib/global_config")
local ErmForceHelper = require("__enemyracemanager__/lib/helper/force_helper")
local ErmRaceSettingsHelper = require("__enemyracemanager__/lib/helper/race_settings_helper")

local Event = require("__stdlib__/stdlib/event/event")
local String = require("__stdlib__/stdlib/utils/string")
local CustomAttacks = require("__erm_zerg_exp__/scripts/custom_attacks")

require("__erm_zerg_exp__/global")
-- Constants

---
--- Enemy Force initialization.
---
local createRace = function()
    local force = game.forces[FORCE_NAME]
    if not force then
        force = game.create_force(FORCE_NAME)
    end

    force.ai_controllable = true;
    force.disable_research()
    force.friendly_fire = false;

    if settings.startup["enemyracemanager-free-for-all"].value then
        ErmForceHelper.set_friends(game, FORCE_NAME, false)
    else
        ErmForceHelper.set_friends(game, FORCE_NAME, true)
    end

    ErmForceHelper.set_neutral_force(game, FORCE_NAME)
end

---
--- Enemy race setting registration.
---
local addRaceSettings = function()
    local race_settings = remote.call("enemyracemanager", "get_race", MOD_NAME)
    if race_settings == nil then
        race_settings = {}
    end

	race_settings.race = race_settings.race or MOD_NAME
    race_settings.label = {"gui.label-erm-zerg-exp"}
    race_settings.level = race_settings.level or 1
    race_settings.tier = race_settings.tier or 1
    race_settings.evolution_point = race_settings.evolution_point or 0
    race_settings.evolution_base_point = race_settings.evolution_base_point or 0
    race_settings.attack_meter = race_settings.attack_meter or 0
    race_settings.attack_meter_total = race_settings.attack_meter_total or 0
    race_settings.last_attack_meter_total = race_settings.last_attack_meter_total or 0
    race_settings.next_attack_threshold = race_settings.next_attack_threshold or 0

    if game.active_mods["Krastorio2"] then
        race_settings.enable_k2_creep = settings.startup["erm_zerg_exp-k2-creep"].value
    end

    --- Units here will used for calculating attack point and level evolution
    --- It should not include timed units and units spawned by other units.
    race_settings.units = {
        {"drone","zergling","hydralisk"},
        {"overlord","lurker","mutalisk","scourge","queen","infested"},
        {"ultralisk","defiler","guardian","devourer"}
    }
    race_settings.turrets = {
        {"sunken_colony","spore_colony"},
        {},
        {}
    }
    race_settings.command_centers = {
        {"hatchery"},
        {"lair"},
        {"hive"}
    }
    race_settings.support_structures = {
        {"spawning_pool","hydraden","chamber"},
        {"spire","infested_cmd","queen_nest"},
        {"ultralisk_cavern","defiler_mound","greater_spire","nyduspit"}
    }
    race_settings.flying_units = {
        {"mutalisk"},
        {"overlord","scourge","queen"},
        {"guardian","devourer"}
    }
    race_settings.time_to_live_units = {
        parasite = true,
        broodling = true
    }
    race_settings.dropship = "overlord"
    race_settings.droppable_units = {
        {{"zergling","hydralisk"},{4,2}},
        {{"zergling"},{8}},
        {{"hydralisk"},{4}},
        {{"lurker"},{2}},
        {{"zergling","hydralisk","drone"},{5,1,1}},
        {{"zergling","hydralisk","lurker"},{2,1,1}},
        {{"zergling","defiler"},{6,1}},
        {{"zergling","infested","ultralisk"},{2,2,1}},
        {{"ultralisk"},{2}}
    }
    race_settings.construction_buildings = {
        {{"sunken_colony_shortrange"},{1}},
        {{"sunken_colony_shortrange"},{1}},
        {{"sunken_colony_shortrange","nyduspit"},{2,1}}
    }
    race_settings.featured_groups = {
        -- Unit list, spawn ratio, unit attack point cost
        {{"zergling"},{18}, 20},
        {{"zergling","ultralisk"},{6,2}, 20},
        {{"hydralisk","lurker","ultralisk"},{3,1,1}, 20},
        {{"zergling","infested","lurker","ultralisk"}, {3,1,2,2}, 15},
        {{"zergling","ultralisk","defiler"},{6,3,1}, 22.5},
        {{"zergling","hydralisk","lurker","ultralisk"},{4,2,1,1}, 20},
        {{"zergling","hydralisk","lurker","ultralisk","defiler"},{2,1,1,2,1}, 20}
    }
    race_settings.featured_flying_groups = {
        {{"mutalisk"}, {6}, 45},
        {{"devourer","guardian"}, {2,1}, 50},
        {{"mutalisk","devourer","queen","scourge"}, {4,2,1,6}, 75},
        {{"mutalisk","guardian","overlord"}, {4,2,1}, 50},
        {{"mutalisk","queen","devourer","guardian"}, {4,1,2,2}, 50}
    }

    race_settings.boss_building = "overmind"
    race_settings.pathing_unit = "zergling"
    race_settings.colliding_unit = "ultralisk"
    race_settings.boss_tier = race_settings.boss_tier or 1
    race_settings.boss_kill_count = race_settings.boss_kill_count or 0

    ErmRaceSettingsHelper.process_unit_spawn_rate_cache(race_settings)

    remote.call("enemyracemanager", "register_race", race_settings)
    CustomAttacks.get_race_settings(MOD_NAME, true)
end

Event.on_init(function(event)
    createRace()
    addRaceSettings()
end)

Event.on_load(function(event)
end)

Event.on_configuration_changed(function(event)
    createRace()
    addRaceSettings()
end)

local attack_functions = {
    [OVERLORD_DROP_ATTACK] = function(args)
        CustomAttacks.process_overlord_drop_attack(args)
    end,
    [DRONE_CONSTRUCTION_TURRET] = function(args)
        CustomAttacks.process_drone_construction_turret(args)
    end,
    [SELF_DESTRUCT] = function(args)
        CustomAttacks.process_self_destruct(args)
    end,
    [SPAWN_PARASITE] = function(args)
        CustomAttacks.process_spawn_parasite(args)
    end,
    [SPAWN_BROODLING] = function(args)
        CustomAttacks.process_spawn_broodling(args)
    end,
    [SPAWN_SCOURGE] = function(args)
        CustomAttacks.process_spawn_scourge(args)
    end,
    [BOSS_SPAWN_ATTACK] = function(args)
        print(CustomAttacks)
        CustomAttacks.process_boss_units(args)
    end,
    [UNITS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_batch_units(args)
    end
}
Event.register(defines.events.on_script_trigger_effect, function(event)
    if  attack_functions[event.effect_id] and
        CustomAttacks.valid(event, MOD_NAME)
    then
        attack_functions[event.effect_id](event)
    end
end)

Event.on_nth_tick(1801, function(event)
    CustomAttacks.clearTimeToLiveUnits(event)
end)

Event.register(defines.events.on_runtime_mod_setting_changed,function(event)
    if event.setting_type == "runtime-global" and
            event.setting == "erm_zerg_exp-team-color"
    then
       local color = ErmConfig.format_team_color(settings.startup["erm_zerg_exp-team-color"].value)
       game.forces[FORCE_NAME].custom_color = color
    end
end)

local ErmBossAttack = require("scripts/boss_attacks")

remote.add_interface("erm_zerg_exp_boss_attacks", {
    get_attack_data = ErmBossAttack.get_attack_data,
})

local RemoteApi = require("scripts/remote")
remote.add_interface("erm_zerg_exp", RemoteApi)

