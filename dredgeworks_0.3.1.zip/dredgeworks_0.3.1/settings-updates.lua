if mods["cargo-ships"] then
    data.raw["bool-setting"]["no_catching_fish"].forced_value=false
    data.raw["bool-setting"]["no_catching_fish"].hidden=true
end