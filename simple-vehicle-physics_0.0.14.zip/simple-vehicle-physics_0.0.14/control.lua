local e = defines.events

local function setup_globals()
    ---@type table<uint, DrivingData>
    global.driving = global.driving or {}
end

script.on_init(setup_globals)
script.on_configuration_changed(setup_globals)

local abs, min, tanh, sin, cos = math.abs, math.min, math.tanh, math.sin, math.cos
local tau = math.pi * 2

local vec = {}
function vec.new(n) return {x = n, y = n} end
function vec.add(a, b) return {x = a.x + b.x, y = a.y + b.y} end
function vec.sub(a, b) return {x = a.x - b.x, y = a.y - b.y} end
function vec.mul(v, n) return {x = v.x * n, y = v.y * n} end
function vec.div(v, n) return {x = v.x / n, y = v.y / n} end
function vec.rotate(v, a) return {x = (v.x * cos(a)) - (v.y * sin(a)), y = (v.x * sin(a)) + (v.y * cos(a))} end

function vec.len(v) return (v.x * v.x + v.y * v.y) ^ 0.5 end
function vec.norm(v)
    local len = vec.len(v)
    if len == 0 then
        len = 1
    end
    return {x = v.x / len, y = v.y / len}
end
function vec.dot(a, b)
    a = vec.norm(a)
    b = vec.norm(b)
    return a.x * b.x + a.y * b.y
end

---@param car LuaEntity
---@return Vector.0
local function get_speed_vector(car)
    local mag = car.speed
    local angle = (car.orientation - 0.25) * tau
    local x = cos(angle) * mag
    local y = sin(angle) * mag
    return {x = x, y = y}
end

local offset = 1/32
---@param car LuaEntity
---@param old_pos MapPosition
---@param pos MapPosition
---@param vector Vector.0
---@return boolean, boolean
local function car_collides(car, old_pos, pos, vector)
    local surface = car.surface
    -- local direction = math.floor(car.orientation * 8)
    -- if surface.entity_prototype_collides(car, pos, false, direction) then return true, false end
    local dummy = car.name .. "-dummy"
    local box = car.prototype.collision_box
    local lt, rb = box.left_top, box.right_bottom
    lt.x, lt.y = lt.x - offset, lt.y - offset
    rb.x, rb.y = rb.x + offset, rb.y + offset
    local angle = car.orientation * tau
    local points = {
        vec.add(pos, vec.rotate({x = lt.x, y = lt.y}, angle)),
        vec.add(pos, vec.rotate({x = 0,    y = lt.y}, angle)),
        vec.add(pos, vec.rotate({x = rb.x, y = lt.y}, angle)),
        vec.add(pos, vec.rotate({x = rb.x, y = 0   }, angle)),
        vec.add(pos, vec.rotate({x = rb.x, y = rb.y}, angle)),
        vec.add(pos, vec.rotate({x = 0,    y = rb.y}, angle)),
        vec.add(pos, vec.rotate({x = lt.x, y = rb.y}, angle)),
        vec.add(pos, vec.rotate({x = lt.x, y = 0   }, angle)),
    }
    if car.speed < 0 then
        vec[1], vec[5] = vec[5], vec[1]
        vec[2], vec[6] = vec[6], vec[2]
        vec[3], vec[7] = vec[7], vec[3]
        vec[4], vec[8] = vec[8], vec[4]
    end
    rendering.clear("simple-vehicle-physics")
    for _, point in pairs(points) do
        if surface.entity_prototype_collides(dummy, point, false) then
            -- rendering.draw_line{
            --     color = {0,1,0},
            --     from = old_pos,
            --     to = point,
            --     surface = car.surface,
            --     width = 4,
            -- }
            return true, vec.dot(vector, vec.sub(point, old_pos)) < 0
        end
    end
    return false, false
end

local penalty = 0.77
script.on_event(e.on_tick, function(event)
    local drift = settings.global["svp-drift"].value
    local handling = settings.global["svp-handling"].value
    for k, data in pairs(global.driving) do
        local car = data.car
        if not car.valid then
        global.driving[k] = nil
        goto continue
        end
        local speed = abs(car.speed) --[[@as float]]
        if speed == 0 and data.speed == 0 then
            data.position = car.position
            data.orientation = car.orientation
            data.vector = {x = 0, y = 0}
            goto continue
        end
        local accelerating = speed > data.speed
        local difference = (car.orientation - data.orientation)
        difference = difference > 0.5 and difference - 1 or difference < -0.5 and difference + 1 or difference
        local _drift = accelerating and drift or drift * penalty
        local _handling = accelerating and 1 - ((1 - handling) * penalty) or handling
        _handling = 1 - _handling * min(abs(difference) * 100, 1)
        local rotation = ((1 - _handling) * tanh(-3.5 * speed + 1.6) + _handling + 1) / 2
        local friction = _drift * (tanh(4.5 * speed - 2) + 1) / 2
        local speed_vector = get_speed_vector(car)
        local vector = vec.div(vec.add(vec.mul(data.vector, friction), speed_vector), friction + 1)
        local new_pos = vec.add(data.position, vector)
        local pos = car.position
        ---@diagnostic disable-next-line: param-type-mismatch
        car.teleport(10, 10)
        local collision, stop = car_collides(car, pos, new_pos, speed_vector)
        if collision then
            new_pos = pos
            if stop then
                car.speed = 0
                speed = 0
            end
        end
        car.teleport(new_pos)
        car.orientation = data.orientation + difference * rotation
        data.vector = vector
        data.speed = speed
        data.position = car.position
        data.orientation = car.orientation
        ::continue::
    end
end)

local is_hovercraft = {
    ["hcraft-entity"] = true,
    ["ecraft-entity"] = true,
    ["mcraft-entity"] = true,
    ["lcraft-entity"] = true
  }

script.on_event(e.on_player_driving_changed_state, function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    local entity = event.entity
    if entity and entity.type == "car" and entity.get_driver() == nil then
        global.driving[entity.unit_number] = nil
    end
    local car = player.vehicle
    if car and car.type == "car" and not is_hovercraft[car.name] then
        global.driving[car.unit_number] = {
            car = car,
            speed = abs(car.speed),
            position = car.position,
            orientation = car.orientation,
            vector = get_speed_vector(car)
        }
    end
end)

script.on_event({"svp-forward", "svp-backward"}, function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    local car = player.vehicle
    if not (car and car.type == "car") then return end
    local data = global.driving[car.unit_number]
    if not data then return end
    local speed_vector = get_speed_vector(car)
    local dot = vec.dot(data.vector, speed_vector)
    if dot < 0 and car.speed > 0 == (event.input_name == "svp-backward") then
        car.speed = -car.speed
        data.position = vec.add(data.position, vec.mul(speed_vector, 2))
    end
end)

---@class DrivingData
---@field car LuaEntity
---@field speed number
---@field position MapPosition
---@field orientation number
---@field vector Vector.0