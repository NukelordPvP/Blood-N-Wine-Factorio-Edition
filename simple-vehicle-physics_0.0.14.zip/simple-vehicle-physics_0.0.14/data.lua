data:extend{{
    type = "custom-input",
    name = "svp-forward",
    key_sequence = "",
    linked_game_control = "move-up",
    action = "lua",
}, {
    type = "custom-input",
    name = "svp-backward",
    key_sequence = "",
    linked_game_control = "move-down",
    action = "lua",
}}