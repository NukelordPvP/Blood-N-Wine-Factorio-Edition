ErmTerranExp = {}

require("__erm_terran_exp__/global")

local ErmConfig = require("__enemyracemanager__/lib/global_config")

data.erm_registered_race = data.erm_registered_race or {}
data.erm_registered_race[MOD_NAME] = true
data.erm_spawn_specs = data.erm_spawn_specs or {}
table.insert(data.erm_spawn_specs, {
    mod_name = MOD_NAME,
    force_name = FORCE_NAME,
    moisture = 2, -- 1 = Dry and 2 = Wet
    aux = 2, -- 1 = red desert, 2 = sand
    elevation = 1, -- 1,2,3 (1 low elevation, 2. medium, 3 high elavation)
    temperature = 2, -- 1,2,3 (1 cold, 2. normal, 3 hot)
})

---
--- This set of data replace vanilla biters for the menu.  It may interfere with other mods that use vanilla biter.
---
data.erm_menu_replacement = data.erm_menu_replacement or {}
data.erm_menu_replacement[MOD_NAME] = {
    race = MOD_NAME,
    level = 3,
    ["unit"] = {
        ["small-biter"] = 'marine',
        ["small-spitter"] = 'wraith',
        ["medium-biter"] = 'firebat',
        ["medium-spitter"] = 'siege_tank',
        ["big-biter"] = 'ghost',
        ["big-spitter"] = 'valkyrie',
        ["behemoth-biter"] = "battlecruiser",
        ["behemoth-spitter"] = "goliath",
    },
    ["turret"] = {
        ["small-worm-turret"] = 'bunker',
        ["medium-worm-turret"] = 'missile_turret',
        ["big-worm-turret"] = 'sentry_turret_bullets',
        ["behemoth-worm-turret"] = 'siege_tank_siege_mode',
    },
    ["turret-scale"] = 0.8,
    ["unit-spawner"] = {
        ["biter-spawner"] = 'barracks',
        ["spitter-spawner"] = 'supply_depot',
    },
    ["unit-spawner-scale"] = 0.8
}

require "prototypes/decoratives"
require "prototypes/projectiles"
require "prototypes/boss-projectiles"

data:extend(
        {
    {
        type = "ammo-category",
        name = MOD_NAME .. "/terran-damage"
    }
})

require "prototypes.enemy.marine"
require "prototypes.enemy.firebat"
require "prototypes.enemy.medic"
require "prototypes.enemy.vulture"
require "prototypes.enemy.spidermine"
require "prototypes.enemy.scv"
require "prototypes.enemy.dropship"
require "prototypes.enemy.wraith"
require "prototypes.enemy.valkyrie"
require "prototypes.enemy.science_vessel"
require "prototypes.enemy.goliath"
require "prototypes.enemy.ghost"
require "prototypes.enemy.siege_tank"
require "prototypes.enemy.battlecruiser"
require "prototypes.enemy.enslaved_hydralisk"
require "prototypes.enemy.enslaved_mutalisk"
require "prototypes.enemy.enslaved_ultralisk"
require "prototypes.enemy.enslaved_zergling"

require "prototypes.building.building_death"
require "prototypes.building.bunker"
require "prototypes.building.siege_tank_siege_mode"
require "prototypes.building.siege_tank_siege_mode_alt"
require "prototypes.building.missile_turret"
require "prototypes.building.sentry_turret_rockets"
require "prototypes.building.sentry_turret_bullets"
require "prototypes.building.command_centre"
require "prototypes.building.boss_psi_disruptor"
require "prototypes.building.supply_depot"
require "prototypes.building.barracks"
require "prototypes.building.engineering_bay"
require "prototypes.building.academy"
require "prototypes.building.factory"
require "prototypes.building.starport_control_tower"
require "prototypes.building.factory_machine_shop"
require "prototypes.building.armoury"
require "prototypes.building.starport"
require "prototypes.building.science_facility_physics_lab"
require "prototypes.building.science_facility_covert_ops"
require "prototypes.building.science_facility"

local max_level = ErmConfig.MAX_LEVELS

for i = 1, max_level + ErmConfig.MAX_ELITE_LEVELS do
    ErmTerranExp.make_marine(i)
    ErmTerranExp.make_firebat(i)
    ErmTerranExp.make_medic(i)
    ErmTerranExp.make_vulture(i)
    ErmTerranExp.make_spidermine(i)
    ErmTerranExp.make_scv(i)
    ErmTerranExp.make_dropship(i)
    ErmTerranExp.make_wraith(i)
    ErmTerranExp.make_valkyrie(i)
    ErmTerranExp.make_science_vessel(i)
    ErmTerranExp.make_goliath(i)
    ErmTerranExp.make_ghost(i)
    ErmTerranExp.make_siege_tank(i)
    ErmTerranExp.make_battlecruiser(i)
    ErmTerranExp.make_enslaved_hydralisk(i)
    ErmTerranExp.make_enslaved_mutalisk(i)
    ErmTerranExp.make_enslaved_ultralisk(i)
    ErmTerranExp.make_enslaved_zergling(i)
end

local boss_level = ErmConfig.BOSS_LEVELS

local boss_unit_ai = { destroy_when_commands_fail = true, allow_try_return_to_spawner = false }
local override_units = {"marine","firebat","medic","vulture","spidermine","scv","dropship","wraith","valkyrie","science_vessel","siege_tank","battlecruiser","enslaved_hydralisk","enslaved_mutalisk","enslaved_ultralisk","enslaved_zergling"}

for i = 1, #boss_level do
    local level = boss_level[i]
    ErmTerranExp.make_marine(level)
    ErmTerranExp.make_firebat(level)
    ErmTerranExp.make_medic(level)
    ErmTerranExp.make_vulture(level)
    ErmTerranExp.make_spidermine(level)
    ErmTerranExp.make_scv(level)
    ErmTerranExp.make_dropship(level)
    ErmTerranExp.make_wraith(level)
    ErmTerranExp.make_valkyrie(level)
    ErmTerranExp.make_science_vessel(level)
    ErmTerranExp.make_goliath(level)
    ErmTerranExp.make_ghost(level)
    ErmTerranExp.make_siege_tank(level)
    ErmTerranExp.make_battlecruiser(level)
    ErmTerranExp.make_enslaved_hydralisk(level)
    ErmTerranExp.make_enslaved_mutalisk(level)
    ErmTerranExp.make_enslaved_ultralisk(level)
    ErmTerranExp.make_enslaved_zergling(level)

    ErmTerranExp.make_boss_psi_disruptor(level, ErmConfig.BOSS_BUILDING_HITPOINT[i])

    for _, unit in pairs(override_units) do
        data.raw["unit"][MOD_NAME .. "/" .. unit .. "/" .. level]["ai_settings"] = boss_unit_ai
    end
end

for i = 1, max_level do
    ErmTerranExp.make_bunker(i)
    ErmTerranExp.make_siege_tank_siege_mode(i)
    ErmTerranExp.make_siege_tank_siege_mode_alt(i)
    ErmTerranExp.make_missile_turret(i)
    ErmTerranExp.make_sentry_turret_rockets(i)
    ErmTerranExp.make_sentry_turret_bullets(i)
    ErmTerranExp.make_command_centre(i)
    ErmTerranExp.make_supply_depot(i)
    ErmTerranExp.make_barracks(i)
    ErmTerranExp.make_engineering_bay(i)
    ErmTerranExp.make_academy(i)
    ErmTerranExp.make_factory(i)
    ErmTerranExp.make_starport_control_tower(i)
    ErmTerranExp.make_factory_machine_shop(i)
    ErmTerranExp.make_armoury(i)
    ErmTerranExp.make_starport(i)
    ErmTerranExp.make_science_facility_physics_lab(i)
    ErmTerranExp.make_science_facility_covert_ops(i)
    ErmTerranExp.make_science_facility(i)
end





