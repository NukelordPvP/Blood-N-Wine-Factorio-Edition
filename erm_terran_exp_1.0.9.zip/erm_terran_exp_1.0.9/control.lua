--
-- Created by IntelliJ IDEA.
-- User: heyqule
-- Date: 12/20/2020
-- Time: 5:04 PM
-- To change this template use File | Settings | File Templates.
--

local Game = require("__stdlib__/stdlib/game")
local ErmForceHelper = require("__enemyracemanager__/lib/helper/force_helper")
local ErmRaceSettingsHelper = require("__enemyracemanager__/lib/helper/race_settings_helper")
local ErmConfig = require("__enemyracemanager__/lib/global_config")

local Event = require("__stdlib__/stdlib/event/event")
local String = require("__stdlib__/stdlib/utils/string")
local CustomAttacks = require("__erm_terran_exp__/scripts/custom_attacks")

require("__erm_terran_exp__/global")
-- Constants


local createRace = function()
    local force = game.forces[FORCE_NAME]
    if not force then
        force = game.create_force(FORCE_NAME)
    end

    force.ai_controllable = true;
    force.disable_research()
    force.friendly_fire = false;

    if settings.startup["enemyracemanager-free-for-all"].value then
        ErmForceHelper.set_friends(game, FORCE_NAME, false)
    else
        ErmForceHelper.set_friends(game, FORCE_NAME, true)
    end

    ErmForceHelper.set_neutral_force(game, FORCE_NAME)
end

local addRaceSettings = function()
    local race_settings = remote.call("enemyracemanager", "get_race", MOD_NAME)
    if race_settings == nil then
        race_settings = {}
    end

    race_settings.race = race_settings.race or MOD_NAME
    race_settings.label = {"gui.label-erm-terran-exp"}
    race_settings.level = race_settings.level or 1
    race_settings.tier = race_settings.tier or 1
    race_settings.evolution_point = race_settings.evolution_point or 0
    race_settings.evolution_base_point = race_settings.evolution_base_point or 0
    race_settings.attack_meter = race_settings.attack_meter or 0
    race_settings.attack_meter_total = race_settings.attack_meter_total or 0
    race_settings.next_attack_threshold = race_settings.next_attack_threshold or 0

    if game.active_mods["Krastorio2"] then
        race_settings.enable_k2_creep = settings.startup["erm_terran_exp-k2-creep"].value
    end

    race_settings.units = {
        {"scv","marine","firebat","medic"},
        {"vulture","dropship","wraith","valkyrie"},
        {"science_vessel","goliath","ghost","siege_tank","battlecruiser"}
    }
    race_settings.turrets = {
        {"bunker","missile_turret","sentry_turret_rockets","sentry_turret_rockets","siege_tank_siege_mode","siege_tank_siege_mode_alt"},
        {},
        {}
    }
    race_settings.command_centers = {
        {"command_centre","supply_depot"},
        {},
        {}
    }
    race_settings.support_structures = {
        {"supply_depot","barracks","engineering_bay"},
        {"academy","starport","factory","starport_control_tower"},
        {"armoury","science_facility","factory_machine_shop","science_facility_physics_lab","science_facility_covert_ops"}
    }
    race_settings.flying_units = {
        {"wraith"},
        {"dropship","valkyrie"},
        {"science_vessel","battlecruiser"}
    }
    race_settings.dropship = "dropship"
    race_settings.droppable_units = {
        {{"marine","medic"},{7,1}},
        {{"marine","firebat","scv"},{4,2,2}},
        {{"marine","firebat","vulture"},{2,2,2}},
        {{"marine","scv","goliath"},{5,1,1}},
        {{"vulture"},{4}},
        {{"siege_tank"},{2}},
        {{"goliath","siege_tank"},{2,1}}
    }
    race_settings.construction_buildings = {
        {{ "bunker","sentry_turret_bullets"},{1,1}},
        {{ "bunker","sentry_turret_rockets"},{1,1}},
        {{ "bunker","missile_turret","supply_depot"},{1,1,1}}
    }
    race_settings.featured_groups = {
        -- Unit list, spawn ratio, unit attack point cost
        {{"marine","firebat"},{6,3}, 20},
        {{"marine","goliath"},{6,3}, 25},
        {{"marine","firebat","goliath"},{3,3,2}, 25},
        {{"marine","firebat","ghost"},{3,3,2}, 25},
        {{"marine","firebat","siege_tank"},{3,3,2}, 25},
        {{"marine","firebat","medic"},{7,3,1}, 25},
        {{"vulture","medic","goliath","ghost"},{4,1,2,1}, 25},
        {{"marine","firebat","vulture","medic","goliath","siege_tank"},{3,3,2,1,1,2}, 30}
    }
    race_settings.featured_flying_groups = {
        {{"wraith","valkyrie"},{1,1}, 35},
        {{"wraith","battlecruiser"},{4,1}, 50},
        {{"valkyrie","science_vessel"},{5,1}, 60},
        {{"wraith","valkyrie","battlecruiser","science_vessel"},{4,4,1,1}, 50},
        {{"wraith","valkyrie","battlecruiser","dropship"},{5,3,2,1}, 60}
    }

    race_settings.boss_building = "psi_disruptor"
    race_settings.pathing_unit = "marine"
    race_settings.colliding_unit = "siege_tank"
    race_settings.boss_tier = race_settings.boss_tier or 1
    race_settings.boss_kill_count = race_settings.boss_kill_count or 0

    ErmRaceSettingsHelper.process_unit_spawn_rate_cache(race_settings)

    remote.call("enemyracemanager", "register_race", race_settings)
    CustomAttacks.get_race_settings(MOD_NAME, true)
end

Event.on_init(function(event)
    createRace()
    addRaceSettings()
end)

Event.on_load(function(event)
end)

Event.on_configuration_changed(function(event)
    createRace()
    addRaceSettings()
end)

local attack_functions = {
    [SCV_ATTACK] = function(args)
        CustomAttacks.process_scv(args)
    end,
    [SPAWN_MARINE] = function(args)
        CustomAttacks.process_spawn_marine(args)
    end,
    [SPAWN_SPIDERMINE] = function(args)
        CustomAttacks.process_spawn_spidermine(args)
    end,
    [SPIDERMINE_ATTACK] = function(args)
        CustomAttacks.process_spidermine_attack(args)
    end,
    [DROPSHIP_DROP_ATTACK] = function(args)
        CustomAttacks.process_dropship_drop_attack(args)
    end,
    [BOSS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_boss_units(args)
        CustomAttacks.process_enslaved_zerg_boss_units(args)
    end,
    [UNITS_SPAWN_ATTACK] = function(args)
        CustomAttacks.process_batch_units(args)
        CustomAttacks.process_enslaved_zerg_batch_units(args)
    end
}
Event.register(defines.events.on_script_trigger_effect, function(event)
    if  attack_functions[event.effect_id] and
            CustomAttacks.valid(event, MOD_NAME)
    then
        attack_functions[event.effect_id](event)
    end
end)

Event.on_nth_tick(1803, function(event)
    CustomAttacks.clearTimeToLiveUnits(event)
end)

Event.register(defines.events.on_runtime_mod_setting_changed,function(event)
    if event.setting_type == "runtime-global" and
            event.setting == "erm_terran_exp-team-color"
    then
       local color = ErmConfig.format_team_color(settings.startup["erm_terran_exp-team-color"].value)
       game.forces[FORCE_NAME].custom_color = color
    end
end)

local ErmBossAttack = require("scripts/boss_attacks")
remote.add_interface("erm_terran_exp_boss_attacks", {
    get_attack_data = ErmBossAttack.get_attack_data,
})

local RemoteApi = require("scripts/remote")
remote.add_interface("erm_terran_exp", RemoteApi)

