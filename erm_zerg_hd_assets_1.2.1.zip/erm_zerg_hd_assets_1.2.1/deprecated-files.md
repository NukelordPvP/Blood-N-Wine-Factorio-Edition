OLD FILES
- infested_cmd.png - ok
- sunken_colony.png - ok (REPLACED with new)
- spore_colony.png - ok (REPLACED with new)
- drone-run.png - ok
- guardian-run.png - ok
- hydralisk-run.png
- hydralisk-attack.png
- infested-run.png
- lurker-burrow-combined.png
- lurker-burrow.png
- lurker-unburrow.png
- mutalisk-run.png
- ultralisk-attack.png
- ultralisk-run.png
- zerling-attack.png
- zerling-run.png
- overmind.png

Older files will be remove once other mods have updated its code.