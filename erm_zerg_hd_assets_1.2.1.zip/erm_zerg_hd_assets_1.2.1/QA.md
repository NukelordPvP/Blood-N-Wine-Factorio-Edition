Must QA against the following mods
- all EMR - Zerg variants
- Latest version of Natural_Evolution_Enemies (TheSAGuys version)