--Make capsules/grenades throw in an arc!

local capsule_speed = 0.5

local old_posion =
{
  type = "capsule",
  name = "poison-capsule",
  icon = "__base__/graphics/icons/poison-capsule.png",
  icon_size = 32,
  capsule_action =
  {
    type = "throw",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "capsule",
      cooldown = 30,
      projectile_creation_distance = 0.6,
      range = 25,
      ammo_type =
      {
        category = "capsule",
        target_type = "position",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "poison-capsule",
            starting_speed = 0.3
          }
        }
      }
    }
  },
  subgroup = "capsule",
  order = "b[poison-capsule]",
  stack_size = 100
}

ammo_type = {
  action = {
    {
      action_delivery = {
        projectile = "poison-capsule",
        starting_speed = 0.3,
        type = "projectile"
      },
      type = "direct"
    },
    {
      action_delivery = {
        target_effects = {
          {
            sound = 0 --[=[ ref [""].capsule["cluster-grenade"].capsule_action.attack_parameters.ammo_type.action[2].action_delivery.target_effects[1].sound ]=],
            type = "play-sound"
          }
        },
        type = "instant"
      },
      type = "direct"
    }
  },
  category = "capsule",
  target_type = "position"
}

local make_capsule_stream = function(ammo_type)
  local root_projectile
  local root_speed
  if ammo_type and ammo_type.action and ammo_type.action.action_delivery and ammo_type.action.action_delivery.type == "projectile" then
    root_projectile = ammo_type.action.action_delivery.projectile
    root_speed = ammo_type.action.action_delivery.starting_speed
  end
  if not root_projectile and root_speed then return end
  local projectile_prototype = data.raw.projectile[root_projectile]
  if not projectile_prototype then return end

  root_speed = math.max(root_speed, 0.1)
  --root_speed = root_speed + (300 * root_speed * (projectile_prototype.acceleration or 0))
  if projectile_prototype.max_speed then
    root_speed = math.min(root_speed, projectile_prototype.max_speed)
  end

  root_speed = capsule_speed

  local stream =
  {
    type = "stream",
    name = projectile_prototype.name.."-stream",
    particle = (projectile_prototype.animation and projectile_prototype.animation[1]) or projectile_prototype.animation,
    shadow = (projectile_prototype.shadow and projectile_prototype.shadow[1]) or projectile_prototype.shadow,
    particle_buffer_size = 1,
    particle_spawn_interval = 0,
    particle_spawn_timeout = 1,
    particle_vertical_acceleration = 0.981 / 60,
    particle_horizontal_speed = root_speed,
    particle_horizontal_speed_deviation = root_speed * 0.1,
    particle_start_alpha = 1,
    particle_end_alpha = 1,
    particle_start_scale = 1,
    particle_loop_frame_count = 1,
    particle_fade_out_threshold = 1,
    particle_loop_exit_threshold = 1,
    smoke_sources = projectile_prototype.smoke,
    action = projectile_prototype.action,
    progress_to_create_smoke = 0,
    oriented_particle = true,
    stream_light = projectile_prototype.light
  }

  data:extend{stream}

  ammo_type.action =
  {
    type = "direct",
    action_delivery =
    {
      type = "stream",
      stream = stream.name,
      source_offset = {0, -(projectile_prototype.height or 1)}
    }
  }

end

local make_capsule = function(capsule_item)
  make_capsule_stream(capsule_item.capsule_action.attack_parameters.ammo_type)

end

make_capsule(data.raw.capsule["poison-capsule"])
make_capsule(data.raw.capsule["slowdown-capsule"])
make_capsule(data.raw.capsule["grenade"])
make_capsule(data.raw.capsule["cluster-grenade"])
make_capsule(data.raw.capsule["defender-capsule"])
make_capsule(data.raw.capsule["distractor-capsule"])
make_capsule(data.raw.capsule["destroyer-capsule"])
make_capsule(data.raw.capsule["cliff-explosives"])

