# Factorio: Space Shuttle
When playing Factorio with Earendel's Space Exploration mod, I never understood why there only is spacewalking in orbit.

This mod adds a space shuttle (based on the cargo plane) when the mod aircraft is installed.

Feel free to review and improve my code.

## Acknowledgements

- [Github actions based on Roang-zero1 Actions](https://github.com/Roang-zero1)
- [Space Exploration is a mod by Earendel](https://mods.factorio.com/mod/space-exploration)
- [Aircraft is a mod by SuicidalKid](https://mods.factorio.com/mod/Aircraft)
- [make sure to check out _snouz_ mods, he did all the images for the new space shuttle version](https://mods.factorio.com/user/snouz)