require("data.prototypes.technology")
require("data.prototypes.subgroup")
