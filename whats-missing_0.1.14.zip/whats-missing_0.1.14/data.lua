local sprite = {
    type = "sprite",
    name = "whats-missing-button",
    filename = "__whats-missing__/graphics/whats-missing-button.png",
    width = 72,
    height = 72
}

data:extend{sprite}