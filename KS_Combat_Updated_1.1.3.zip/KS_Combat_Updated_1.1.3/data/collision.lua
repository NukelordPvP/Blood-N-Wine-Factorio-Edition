-- This layer is used to make certain projectiles collide with not-friend walls.
-- If you have a mod with similar functionality you are encoureaged to use the same layer.
--use force_condition = "not-friend", on the projectile.
local collision_mask_util = require("collision-mask-util")
projectile_collision_layer = projectile_collision_layer or collision_mask_util.get_first_unused_layer()
log("projectile_collision_layer = " .. projectile_collision_layer)
--collision_mask_util.get_mask
local suffix = "-blockable"

local enable = settings.startup["ksc-walls-block-spitters"].value --sets local enable variable based on mod settings

local function add_collision_to_entity(prototype, projectile_collision_layer)
  prototype.collision_mask = collision_mask_util.get_mask(prototype)
  collision_mask_util.add_layer(prototype.collision_mask, projectile_collision_layer)
end

local function make_unit_projectile_blockable (unit)
  if unit.attack_parameters.ammo_type
      and unit.attack_parameters.ammo_type.action
      and unit.attack_parameters.ammo_type.action.action_delivery
      and unit.attack_parameters.ammo_type.action.action_delivery.type
      and unit.attack_parameters.ammo_type.action.action_delivery.type == "projectile" then

        unit.attack_parameters.ammo_type.target_type = "position"
        local projectile_name = unit.attack_parameters.ammo_type.action.action_delivery.projectile
        local projectile = data.raw.projectile[projectile_name]
        if projectile then
          projectile.collision_box = projectile.collision_box or { { -0.05, -0.25 }, { 0.05, 0.25 } }
          projectile.hit_collision_mask = {projectile_collision_layer}
          projectile.force_condition = "not-friend"
        end
  end
end

local function make_unit_projectile_from_stream (unit)
  --log(unit.name)
  if unit.attack_parameters.ammo_type
      and unit.attack_parameters.ammo_type.action
      and unit.attack_parameters.ammo_type.action.action_delivery
      and unit.attack_parameters.ammo_type.action.action_delivery.type
      and unit.attack_parameters.ammo_type.action.action_delivery.type == "stream" then

      unit.attack_parameters.type = "projectile"
      unit.attack_parameters.ammo_type.target_type = "position"

      -- do the stuff
      local stream_name = unit.attack_parameters.ammo_type.action.action_delivery.stream
      local projectile_name =  stream_name .. "-blockable"
      unit.attack_parameters.ammo_type.action.action_delivery = {
              max_range = unit.attack_parameters.ammo_type.action.action_delivery.max_range or ((unit.attack_parameters.range or 16 ) * 1.5),
              projectile = projectile_name,
              starting_speed = unit.attack_parameters.ammo_type.action.action_delivery.starting_speed or 0.5,
              type = "projectile"
      }

      local stream_prototype = data.raw.stream[stream_name]
      local projectile = {
        acceleration = 0.005,
        action = table.deepcopy(stream_prototype.initial_action),
        animation = stream_prototype.particle,
        collision_box = { { -0.05, -0.25 }, { 0.05, 0.25 } },
        hit_collision_mask = {projectile_collision_layer},
        force_condition = "not-friend",
        direction_only = false,
        flags = { "not-on-map" },
        name = projectile_name,
        rotatable = true,
        shadow = stream_prototype.shadow,
        type = "projectile"
      }

      data:extend({projectile})
  end

end

if enable then --enables or disables the collision code

	for _, type in pairs({"wall", "car", "spider-vehicle", "ammo-turret", "electric-turret", "fluid-turret", "unit-spawner"}) do
	  for _, prototype in pairs(data.raw[type]) do
		add_collision_to_entity(prototype, projectile_collision_layer)
	  end
	end

	-- biters
	for _, unit in pairs(data.raw.unit) do
	  if string.find(unit.name, "spitter", 1, true) then
		make_unit_projectile_blockable(unit)
		make_unit_projectile_from_stream(unit)
	  end
	  unit.collision_mask = add_collision_to_entity(unit, projectile_collision_layer)
	end

	-- turrets
	for _, turret in pairs(data.raw.turret) do
	  add_collision_to_entity(turret, projectile_collision_layer)
	end
end