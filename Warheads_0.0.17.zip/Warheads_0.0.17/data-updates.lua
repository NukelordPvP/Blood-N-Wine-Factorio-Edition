if mods["Krastorio2"] then
  require("prototypes.compatibility.K2-weapontypes")
  --require("prototypes.compatibility.K2-warheads")
end
require("prototypes.generate-all")

