data:extend({
  {
    type = "int-setting",
    name = "VehicleSnap_amount",
    setting_type = "runtime-per-user",
    minimum_value = 4,
    default_value = 16
  }
})
