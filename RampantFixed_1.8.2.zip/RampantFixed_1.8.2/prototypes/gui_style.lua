data.raw["gui-style"].default["rampantFixed_menu_button"] = 
{
  type = "button_style",
  height = 24,
  width = 450,
  scalable = false,
}

data.raw["gui-style"].default["rampantFixed_surfaceStatus_button"] = 
{
  type = "button_style",
  width = 150,
  scalable = false,
}


data.raw["gui-style"].default["rampantFixed_menu_label"] = 
{
  type = "label_style",
  height = 24,
  width = 450,
  scalable = false,
}
