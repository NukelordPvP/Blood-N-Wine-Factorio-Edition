data:extend({
    {
        type = "bool-setting",
        name = "ed-fluid-colors",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-voiding",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-inserter-stats",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-solar-ratios",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-tank-size",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-radar-stats",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-heat",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-military-resistances",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-building-size",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ed-allowed-modules",
        setting_type = "startup",
        default_value = true,
    }
})

