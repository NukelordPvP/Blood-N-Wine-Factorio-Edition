data:extend({
    {
        type = "int-setting",
        name = "light-size",
        setting_type = "startup",
        default_value = 70,
        minimum_value = 10,
        maximum_value = 10000
    }
})