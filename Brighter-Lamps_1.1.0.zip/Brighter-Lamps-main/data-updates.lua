--Changes to Small Lamp

data.raw["lamp"]["small-lamp"].light.size = settings.startup["light-size"].value
