local data_util = require("data_util")

local function move_to_specialist_science_packs(tech_name, science_packs, require_imersium)
  data_util.tech_remove_ingredients(tech_name, {"kr-optimization-tech-card", "matter-tech-card", "advanced-tech-card", "se-deep-space-science-pack-1"})
  data_util.tech_remove_prerequisites(tech_name, {"kr-optimization-tech-card", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack-1"})
  data_util.tech_add_ingredients(tech_name, science_packs)
  data_util.tech_add_prerequisites(tech_name, science_packs)
  if require_imersium then
    data_util.tech_add_prerequisites(tech_name, {"kr-imersium-processing"})
  end
end

-- Spidertron
data_util.tech_remove_prerequisites("spidertron", {"kr-ai-core", "kr-optimization-tech-card", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack"})
move_to_specialist_science_packs("spidertron", {"se-biological-science-pack-1"})
data_util.remove_ingredient("spidertron","ai-core")

if data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories then
  data_util.tech_add_prerequisites("spidertron", {"uranium-processing"})
  table.insert(data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories, "nuclear")
end

-- Sheild Projector
-- Include K2 Advanced Tech Card and Lithium Sulfur Battery instead of Base battery.
data.raw.technology["shield-projector"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("shield-projector",{"kr-advanced-tech-card"})
data_util.tech_add_ingredients("shield-projector",{"advanced-tech-card"})
data_util.replace_or_add_ingredient("shield-projector","battery","lithium-sulfur-battery",160)

---- Shields
-- Clean up unused K2 alternate recipes and techs.
data.raw.technology["kr-energy-shield-mk3-equipment"] = nil
data.raw.recipe["energy-shield-mk3-equipment-2"] = nil
data.raw.technology["kr-energy-shield-mk4-equipment"] = nil
data.raw.recipe["energy-shield-mk4-equipment-2"] = nil

-- Energy Shield Mk1
data.raw.technology["energy-shield-equipment"].prerequisites = {"se-holmium-cable", "military-science-pack", "se-adaptive-armour-2"}
data.raw.technology["energy-shield-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-1", 1},
}
data.raw.technology["energy-shield-equipment"].icon_size = 128
data.raw.item["energy-shield-equipment"].order = "s[energy-shield]-s1[energy-shield]"
data.raw.item["energy-shield-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-equipment"].icons = nil
data.raw.item["energy-shield-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-red.png"
data.raw.item["energy-shield-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-red.png"
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.hr_version = nil

-- Energy Shield Mk2
data_util.tech_add_prerequisites("energy-shield-mk2-equipment", {"kr-optimization-tech-card"})
data.raw.technology["energy-shield-mk2-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"kr-optimization-tech-card", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-2", 1}
}
data.raw.technology["energy-shield-mk2-equipment"].icon_size = 128
data.raw.item["energy-shield-mk2-equipment"].order = "s[energy-shield]-s2[energy-shield]"
data.raw.item["energy-shield-mk2-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk2-equipment"].icons = nil
data.raw.item["energy-shield-mk2-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-yellow.png"
data.raw.item["energy-shield-mk2-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-yellow.png"
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.hr_version = nil

-- Energy Shield Mk3
data.raw.technology["energy-shield-mk3-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"kr-optimization-tech-card", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-3", 1}
}
data.raw.item["energy-shield-mk3-equipment"].order = "s[energy-shield]-s3[energy-shield]"
data.raw.item["energy-shield-mk3-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk3-equipment"].icons = nil
data.raw.item["energy-shield-mk3-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-green.png"
data.raw.item["energy-shield-mk3-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-green.png"
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.hr_version = nil

-- Energy Shield Mk4
data.raw.technology["energy-shield-mk4-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"kr-optimization-tech-card", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-4", 1}
}
data.raw.item["energy-shield-mk4-equipment"].order = "s[energy-shield]-s4[energy-shield]"
data.raw.item["energy-shield-mk4-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk4-equipment"].icons = nil
data.raw.item["energy-shield-mk4-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-cyan.png"
data.raw.item["energy-shield-mk4-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-cyan.png"
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.hr_version = nil

-- Energy Shield Mk5
-- Add K2 properties to the Shields
data_util.tech_add_prerequisites("energy-shield-mk5-equipment", {"kr-advanced-tech-card", "se-deep-space-science-pack-1"})
data.raw.technology["energy-shield-mk5-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"advanced-tech-card", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-4", 1},
  {"se-deep-space-science-pack-1", 1}
}
data.raw["energy-shield-equipment"]["energy-shield-mk5-equipment"].categories = { "armor" }
data.raw.item["energy-shield-mk5-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk5-equipment"].order = "s[energy-shield]-s5[energy-shield]"

-- Energy Shield Mk6
-- Add K2 properties to the Shields
data_util.tech_add_prerequisites("energy-shield-mk6-equipment", {"kr-singularity-tech-card"})
data.raw.technology["energy-shield-mk6-equipment"].unit.ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"military-science-pack", 1},
  {"space-science-pack", 1},
  {"se-energy-science-pack-4", 1},
  {"se-kr-matter-science-pack-2", 1},
  {"se-deep-space-science-pack-4", 1},
  {"singularity-tech-card", 1}
}
data.raw["energy-shield-equipment"]["energy-shield-mk6-equipment"].categories = { "armor" }
data.raw.item["energy-shield-mk6-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk6-equipment"].order = "s[energy-shield]-s6[energy-shield]"

---- Batteries
-- Personal Battery Mk2
data_util.replace_or_add_ingredient("battery-mk2-equipment", nil, "se-holmium-cable", 2)
data_util.replace_or_add_ingredient("big-battery-mk2-equipment", nil, "se-holmium-cable", 4)

-- Personal Battery Mk3
data.raw.technology["kr-battery-mk3-equipment"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-battery-mk3-equipment", {"kr-quarry-minerals-extraction"})
data_util.tech_remove_ingredients("kr-battery-mk3-equipment", {"se-energy-science-pack-1","se-material-science-pack-2"})
data_util.tech_add_prerequisites("kr-battery-mk3-equipment", {"se-superconductive-cable"})
data_util.tech_add_ingredients("kr-battery-mk3-equipment", {"se-rocket-science-pack","space-science-pack","production-science-pack","utility-science-pack","se-energy-science-pack-3","se-material-science-pack-3"})
data_util.replace_or_add_ingredient("battery-mk3-equipment", nil, "se-superconductive-cable", 2)
data_util.replace_or_add_ingredient("big-battery-mk3-equipment", nil, "se-superconductive-cable", 4)
data_util.replace_or_add_ingredient("big-battery-mk3-equipment", "lithium-sulfur-battery", "lithium-sulfur-battery", 8)

-- Portable Fusion Reactor
data_util.tech_remove_ingredients("fusion-reactor-equipment", {"se-deep-space-science-pack-1"})
data_util.tech_remove_prerequisites("fusion-reactor-equipment", {"power-armor","se-deep-space-science-pack-1","se-rtg-equipment-2"})
data_util.tech_add_ingredients("fusion-reactor-equipment", {"production-science-pack","se-energy-science-pack-4"})
data_util.tech_add_prerequisites("fusion-reactor-equipment", {"kr-nuclear-reactor-equipment","se-energy-science-pack-4","se-superconductive-cable"})

-- Portable Antimatter Reactor
data.raw.technology["kr-antimatter-reactor-equipment"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-antimatter-reactor-equipment", {"kr-optimization-tech-card","advanced-tech-card","matter-tech-card","se-deep-space-science-pack-1"})
data_util.tech_remove_prerequisites("kr-antimatter-reactor-equipment", {"kr-nuclear-reactor-equipment"})
data_util.tech_add_ingredients("kr-antimatter-reactor-equipment", {"automation-science-pack","logistic-science-pack","chemical-science-pack","se-deep-space-science-pack-3","se-kr-matter-science-pack-2"})
data_util.tech_add_prerequisites("kr-antimatter-reactor-equipment", {"fusion-reactor-equipment"})