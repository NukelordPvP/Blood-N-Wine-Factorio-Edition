local data_util = require("data_util")

-- Remove glass from low density structure
data_util.remove_ingredient("low-density-structure", "glass")
data_util.replace_or_add_ingredient("low-density-structure", "steel-plate", "steel-plate", 2)

-- Remove Rocket Fuel from Water recipe
data_util.delete_recipe("se-rocket-fuel-from-water-copper")

data_util.remove_recipe_from_effects(data.raw.technology["se-pulveriser"].effects, "se-pulverised-sand")
data_util.delete_recipe("se-pulverised-sand")
-- data.raw.recipe["se-pulverised-sand"] = nil
data_util.delete_recipe("glass-from-sand")
-- data.raw.recipe["glass-from-sand"] = nil