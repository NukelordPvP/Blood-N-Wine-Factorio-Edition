local data_util = require("data_util")

-- This source is dedicated to enforcing the balance of the creation of Rocket Fuel within SE and K2

----------------------------------------------------------------------------------------------------------------------
-- Begin rocket fuel energy fixes
-- don't wrap the following changes in if statements, the entities are needed so if one is missing then there is a compatibility problem

data.raw.item["rocket-fuel"].fuel_value = "100MJ"
data.raw.item["rocket-fuel"].stack_size = 10

-- Hydrogen comes from Electrolysis, Increase cost of the process.
data.raw["assembling-machine"]["kr-electrolysis-plant"].energy_usage = "2500kW" --was 375kW
data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].energy_usage = "2500kW" --was 375kW
collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant"].collision_mask, space_collision_layer)
collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].collision_mask, space_collision_layer)
collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant"].collision_mask, spaceship_collision_layer)
collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].collision_mask, spaceship_collision_layer)
data.raw["assembling-machine"]["kr-electrolysis-plant"].localised_description = {"entity-description.kr-electrolysis-plant"}
data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].localised_description = {"space-exploration.structure_description_spaced", {"entity-description.kr-electrolysis-plant"}}

-- make sure that it can't use productivity (true by default)
--data.raw["assembling-machine"]["kr-electrolysis-plant"].allowed_effects = {"consumption", "speed", "pollution"}

-- Increase consumption of gaseous ingredients, add Oxygen and Hydrogen to Vulcanite recipe
data_util.replace_or_add_ingredient("rocket-fuel", "light-oil", "light-oil", 100, true)
data_util.replace_or_add_ingredient("rocket-fuel", "oxygen", "oxygen", 1000, true)
data_util.replace_or_add_ingredient("rocket-fuel-with-ammonia", "ammonia", "ammonia", 1000, true)
data_util.replace_or_add_ingredient("rocket-fuel-with-ammonia", "oxygen", "oxygen", 1000, true)
data_util.replace_or_add_ingredient("rocket-fuel-with-hydrogen-chloride", "hydrogen-chloride", "hydrogen-chloride", 1000, true)
data_util.replace_or_add_ingredient("rocket-fuel-with-hydrogen-chloride", "oxygen", "oxygen", 1000, true)
data_util.replace_or_add_ingredient("se-vulcanite-rocket-fuel", nil, "iron-plate", 1)
data_util.replace_or_add_ingredient("se-vulcanite-rocket-fuel", "oxygen", "oxygen", 500, true)

-- match the SE version to avoid infinite power exploits and cheap fuel
local fuel_refinery = data.raw["assembling-machine"]["kr-fuel-refinery"]
fuel_refinery.allowed_effects = {"consumption", "speed", "productivity", "pollution"}
fuel_refinery.crafting_speed = 1
fuel_refinery.energy_usage = "1000kW"

fuel_refinery = data.raw["assembling-machine"]["kr-fuel-refinery-spaced"]
fuel_refinery.allowed_effects = {"consumption", "speed", "pollution"}
fuel_refinery.crafting_speed = 1
fuel_refinery.energy_usage = "1000kW"
if not data_util.table_contains(fuel_refinery.crafting_categories, "fuel-refining") then
  table.insert(fuel_refinery.crafting_categories, "fuel-refining")
end
fuel_refinery.localised_description = {"space-exploration.structure_description_spaced", ""}
-- end rocket fuel energy fixes
----------------------------------------------------------------------------------------------------------------------