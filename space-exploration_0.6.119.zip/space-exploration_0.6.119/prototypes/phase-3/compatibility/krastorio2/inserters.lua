local data_util = require("data_util")

-- This source follows on from space-exploration/prototypes/phase-2/compatibility/krastorio2/inserters in making changes that cannot be made before this point.

-- This source is dedicated to integrating SE and K2's competing Inserter recipes.

-- Burner Inserter 
if data.raw.recipe["burner-inserter"] then
  -- 1 x Single Cylinder Engine
  -- 1 x Inserter Parts
  data_util.replace_or_add_ingredient("burner-inserter","iron-plate","motor",1)
end

-- Inserter
if data.raw.recipe["inserter"] then
  -- 1 x Small Electric Motor
  -- 1 x Burner Inserter
  -- 1 x Automation Core
  data_util.replace_or_add_ingredient("inserter","inserter-parts","burner-inserter",1)
  data_util.replace_or_add_ingredient("inserter",nil,"electric-motor",1)
end

-- Long Handed Inserter
if data.raw.recipe["long-handed-inserter"] then
  -- 2 x Iron Stick
  -- 1 x Inserter
  data_util.replace_or_add_ingredient("long-handed-inserter","inserter-parts","inserter",1)
  data_util.remove_ingredient("long-handed-inserter","automation-core")
end

-- Fast Inserter
if data.raw.recipe["fast-inserter"] then
  -- 2 x Electronic Circuit
  -- 1 x Inserter
  -- 1 x Steel Plate
  data_util.replace_or_add_ingredient("fast-inserter","inserter-parts","inserter",1)
  data_util.replace_or_add_ingredient("fast-inserter","electronic-circuit","electronic-circuit",2)
end

-- Filter Inserter
if data.raw.recipe["filter-inserter"] then
  -- 2 x Electronic Circuit
  -- 1 x Fast Inserter
  -- 1 x Steel Plate
  data_util.replace_or_add_ingredient("filter-inserter","inserter-parts","fast-inserter",1)
  data_util.replace_or_add_ingredient("filter-inserter","electronic-circuit","electronic-circuit",2)
end

-- Stack Inserter
if data.raw.recipe["stack-inserter"] then
  -- 2 x Advanced Circuit
  -- 2 x Electronic Circuit
  -- 4 x Inserter Parts
  -- 1 x Fast Inserter
  -- 2 x Steel Gear Wheel
  data_util.replace_or_add_ingredient("stack-inserter","inserter-parts","inserter-parts",4)
  data_util.replace_or_add_ingredient("stack-inserter","steel-plate","fast-inserter",1)
  data_util.replace_or_add_ingredient("stack-inserter",nil,"electronic-circuit",2)
end

-- Stack Filter Inserter
if data.raw.recipe["stack-filter-inserter"] then
  -- 2 x Advanced Circuits
  -- 2 x Electronic Circuits
  -- 1 x Stack Inserter
  -- 2 x Steel Gear Wheel
  data_util.replace_or_add_ingredient("stack-filter-inserter","inserter-parts","stack-inserter",1)
  data_util.replace_or_add_ingredient("stack-filter-inserter","steel-plate","electronic-circuit",2)
  data_util.replace_or_add_ingredient("stack-filter-inserter","advanced-circuit","advanced-circuit",2)
end
