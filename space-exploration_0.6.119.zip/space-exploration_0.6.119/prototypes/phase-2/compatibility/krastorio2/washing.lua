local data_util = require("data_util")

-- This source is dedicated to integrating K2's washing process into the SE Iridium and Holmium processes.

-- Create Iridium and Holmium specific Dirty Water
local dirty_ir_water = table.deepcopy(data.raw.fluid["dirty-water"])
dirty_ir_water.name = "dirty-water-ir"
dirty_ir_water.order = "ya03[dirty-water-ir-ho]"
dirty_ir_water.base_color = { r = 0.80, g = 0.50, b = 0.20}
dirty_ir_water.flow_color = { r = 0.80, g = 0.50, b = 0.20}

local dirty_ho_water = table.deepcopy(data.raw.fluid["dirty-water"])
dirty_ho_water.name = "dirty-water-ho"
dirty_ho_water.order = "ya03[dirty-water-ho]"
dirty_ho_water.base_color = { r = 0.80, g = 0.50, b = 0.20}
dirty_ho_water.flow_color = { r = 0.80, g = 0.50, b = 0.20}

data:extend({dirty_ir_water, dirty_ho_water})

-- Create voiding recipe
krastorio.fluid_burner_util.addBurnFluidProduct("dirty-water-ir",{{type = "item", name = "stone", amount = 1, probability = 0.30}})
krastorio.fluid_burner_util.generateBurnFluidsRecipe("dirty-water-ir")

krastorio.fluid_burner_util.addBurnFluidProduct("dirty-water-ho",{{type = "item", name = "stone", amount = 1, probability = 0.30}})
krastorio.fluid_burner_util.generateBurnFluidsRecipe("dirty-water-ho")

-- Replace input water with equal parts Hydrogen Chloride and Nitric Acid
data_util.replace_or_add_ingredient("se-iridium-powder", "water", "hydrogen-chloride", 2, true)
data_util.replace_or_add_ingredient("se-iridium-powder", nil, "nitric-acid", 2, true)

-- Add Dirty Water to Iridium Washing
data_util.replace_or_add_result("se-iridium-powder", "sand", "dirty-water-ir", 4, true) --replace 10% sand

-- Add Iridium recovery from dirty water.
local dirty_iridium = table.deepcopy(data.raw.recipe["dirty-water-filtration-1"])
dirty_iridium.name = "se-dirty-water-filtration-iridium"
dirty_iridium.icons = {
  {
    icon = data.raw.fluid["dirty-water"].icon,
    icon_size = data.raw.fluid["dirty-water"].icon_size,
  },
  {
    icon = data.raw.item["se-iridium-ore-crushed"].icon,
    icon_size = data.raw.item["se-iridium-ore-crushed"].icon_size,
    scale = 0.20 * (data.raw.fluid["dirty-water"].icon_size / data.raw.item["se-iridium-ore-crushed"].icon_size),
    shift = { 0, 4 },
  }, 
}
dirty_iridium.energy_required = 4
dirty_iridium.ingredients = {
  {type = "fluid", name = "dirty-water-ir", amount = 100},
  {name = "se-vulcanite-ion-exchange-beads", amount = 1},
}
dirty_iridium.results = {
  {type = "fluid", name = "water", amount = 80},
  {name = "stone", probability = 0.30, amount = 1},
  {name = "se-iridium-ore-crushed", probability = 0.10, amount = 1},
  {name = "se-vulcanite-ion-exchange-beads", probability = 0.6, amount =1}
}
dirty_iridium.crafting_machine_tint = {
  primary = { r = 0.30, g = 0.30, b = 0.00, a = 0.4},
  secondary = { r = 0.64, g = 0.83, b = 0.93, a = 0.9},
}
dirty_iridium.subgroup = "iridium"
dirty_iridium.order = "a-b-2"

data:extend({dirty_iridium})
data_util.recipe_require_tech("se-dirty-water-filtration-iridium", "se-processing-iridium")
data.raw.recipe["se-dirty-water-filtration-iridium"].normal.always_show_made_in = true
data.raw.recipe["se-dirty-water-filtration-iridium"].expensive.always_show_made_in = true

-- Replace water with Hydrogen Chloride
data_util.replace_or_add_ingredient("se-holmium-chloride","water","hydrogen-chloride", 2, true)

-- Add Dirty Water to Holmium Washing
data_util.replace_or_add_result("se-holmium-chloride", "sand", "dirty-water-ho", 2, true) --replace 10% sand

-- Add Holmium recovery from dirty water.
local dirty_holmium = table.deepcopy(data.raw.recipe["dirty-water-filtration-1"])
dirty_holmium.name = "se-dirty-water-filtration-holmium"
dirty_holmium.icons = {
  {
    icon = data.raw.fluid["dirty-water"].icon,
    icon_size = data.raw.fluid["dirty-water"].icon_size,
  },
  {
    icon = data.raw.item["se-holmium-ore-crushed"].icon,
    icon_size = data.raw.item["se-holmium-ore-crushed"].icon_size,
    scale = 0.20 * (data.raw.fluid["dirty-water"].icon_size / data.raw.item["se-holmium-ore-crushed"].icon_size),
    shift = { 0, 4 },
  }, 
}
dirty_holmium.energy_required = 4
dirty_holmium.ingredients = {
  {type = "fluid", name = "dirty-water-ho", amount = 100},
  {name = "se-cryonite-ion-exchange-beads", amount = 1},
}
dirty_holmium.results = {
  {type = "fluid", name = "water", amount = 80},
  {name = "stone", probability = 0.30, amount = 1},
  {name = "se-holmium-ore-crushed", probability = 0.10, amount = 1},
  {name = "se-cryonite-ion-exchange-beads", probability = 0.6, amount =1}
}
dirty_holmium.crafting_machine_tint = {
  primary = { r = 0.30, g = 0.00, b = 0.00, a = 0.4},
  secondary = { r = 0.64, g = 0.83, b = 0.93, a = 0.9},
}
dirty_holmium.subgroup = "holmium"
dirty_holmium.order = "a-b-2"

data:extend({dirty_holmium})
data_util.recipe_require_tech("se-dirty-water-filtration-holmium", "se-processing-holmium")
data.raw.recipe["se-dirty-water-filtration-holmium"].normal.always_show_made_in = true
data.raw.recipe["se-dirty-water-filtration-holmium"].expensive.always_show_made_in = true

-- Alter K2s existant filtration recipes to make their loops require water input.
data.raw.recipe["dirty-water-filtration-1"].ingredients = {
  { type = "fluid", name = "dirty-water", amount = 100 },
}
data.raw.recipe["dirty-water-filtration-1"].results = {
  { type = "fluid", name = "water", amount = 90 },
  { type = "item", name = "stone", probability = 0.30, amount = 1 },
  { type = "item", name = "iron-ore", probability = 0.10, amount = 1 },
}

data.raw.recipe["dirty-water-filtration-2"].ingredients = {
  { type = "fluid", name = "dirty-water", amount = 100 },
}
data.raw.recipe["dirty-water-filtration-2"].results = {
  { type = "fluid", name = "water", amount = 90 },
  { type = "item", name = "stone", probability = 0.30, amount = 1 },
  { type = "item", name = "copper-ore", probability = 0.10, amount = 1 },
}

data.raw.recipe["dirty-water-filtration-3"].ingredients = {
  { type = "fluid", name = "dirty-water", amount = 100 },
}
data.raw.recipe["dirty-water-filtration-3"].results = {
  { type = "fluid", name = "water", amount = 90 },
  { type = "item", name = "stone", probability = 0.30, amount = 1 },
  { type = "item", name = "raw-rare-metals", probability = 0.05, amount = 1 },
}