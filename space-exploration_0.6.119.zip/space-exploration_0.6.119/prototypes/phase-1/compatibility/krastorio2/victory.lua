local data_util = require("data_util")

-- This source is dedicated to integrating the SE and K2 victory conditions
-- E.G.
--  - Making the Intergalactic Transceiver required for the Spaceship Victory technology.

-- Adjust the Intergalactic Transciever technology
data.raw.technology["kr-intergalactic-transceiver"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-intergalactic-transceiver", {"kr-optimization-tech-card","advanced-tech-card","matter-tech-card"})
data_util.tech_add_ingredients("kr-intergalactic-transceiver",{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-energy-science-pack-4","se-astronomic-science-pack-4","se-material-science-pack-4","se-kr-matter-science-pack-2","se-deep-space-science-pack-3"})

-- Disable SE Spaceship Victory tech. Enabled via script in space-explortation/scripts/compatibility/krastorio2
if data.raw.technology["se-spaceship-victory"] then
  data_util.tech_add_prerequisites("se-spaceship-victory",{"kr-intergalactic-transceiver"})
  data.raw.technology["se-spaceship-victory"].enabled = false
end

-- Replace Battery with Lithium-Sulfur Battery in a secret recipe.
data_util.replace_or_add_ingredient("se-gate-platform","battery","lithium-sulfur-battery",100)