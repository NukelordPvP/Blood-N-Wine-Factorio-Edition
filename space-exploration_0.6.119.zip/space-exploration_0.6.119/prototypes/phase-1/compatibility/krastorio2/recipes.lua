local data_util = require("data_util")

-- Add K2 recipe categories to SE machines
if data.raw["assembling-machine"]["se-space-mechanical-laboratory"].crafting_categories then
  table.insert(data.raw["assembling-machine"]["se-space-mechanical-laboratory"].crafting_categories, "crushing")
else
  data.raw["assembling-machine"]["se-space-mechanical-laboratory"].crafting_categories =  {"crushing"}
end

if data.raw["assembling-machine"]["se-pulveriser"].crafting_categories then
  table.insert(data.raw["assembling-machine"]["se-pulveriser"].crafting_categories, "crushing")
else
  data.raw["assembling-machine"]["se-pulveriser"].crafting_categories = {"crushing"}
end

if data.raw["assembling-machine"]["se-space-decontamination-facility"].crafting_categories then
  table.insert(data.raw["assembling-machine"]["se-space-decontamination-facility"].crafting_categories, "fluid-filtration")
else
  data.raw["assembling-machine"]["se-space-decontamination-facility"].crafting_categories = {"fluid-filtration"}
end

-- Lithium Sulfur batteries
data.raw.recipe["lithium-sulfur-battery"].subgroup = "intermediate-product"

