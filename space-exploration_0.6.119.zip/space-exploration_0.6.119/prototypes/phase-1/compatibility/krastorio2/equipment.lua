local data_util = require("data_util")
local k2_graphics_path = mods["Krastorio2Assets"] and "__Krastorio2Assets__" or "__Krastorio2__/graphics"

-- Allow Jackhammer to collect Space Platform Scaffolding and Plating
table.insert(data.raw["selection-tool"]["kr-jackhammer"].tile_filters,"se-space-platform-scaffold")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].alt_tile_filters,"se-space-platform-scaffold")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].tile_filters,"se-space-platform-plating")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].alt_tile_filters,"se-space-platform-plating")

if data.raw.technology["advanced-radar"] then
  data_util.tech_add_prerequisites("advanced-radar", {"chemical-science-pack"})
  data_util.tech_add_ingredients("advanced-radar", {"chemical-science-pack"})
end

-- Seperate Imersite Weapons away from K2 Military Tech 5 into new Imersite Weapons tech
if data.raw.technology["kr-military-5"] then
  local tech = table.deepcopy(data.raw.technology["kr-military-5"])
  tech.name = "kr-imersite-weapons"
  tech.effects = {}
  tech.prerequisites = {
    "kr-military-5",
    "kr-optimization-tech-card",
    "se-energy-science-pack-1",
    "se-material-science-pack-1",
  }
  tech.unit.ingredients = {
      {"automation-science-pack", 1},
      {"logistic-science-pack", 1},
      {"chemical-science-pack", 1},
      {"production-science-pack", 1},
      {"utility-science-pack", 1},
      {"military-science-pack", 1},
      {"se-rocket-science-pack", 1},
      {"space-science-pack", 1},
      {"kr-optimization-tech-card", 1},
      {"se-energy-science-pack-1", 1},
      {"se-material-science-pack-1", 1}
  }
  tech.check_science_packs_incompatibilities = false
  data:extend({tech})
  data_util.tech_lock_recipes("kr-imersite-weapons", {"impulse-rifle", "impulse-rifle-ammo", "imersite-rifle-magazine", "imersite-anti-material-rifle-magazine"})
  data_util.replace_or_add_ingredient("impulse-rifle", "steel-plate", "imersium-plate", 5)
end
-- Remove Quarry Mineral Extraction as a requirement from Military 5 as no unlocks require it
data_util.tech_remove_prerequisites("kr-military-5", {"kr-quarry-minerals-extraction"})

---- Power Armours
-- Power Armour Mk3
data.raw.technology["kr-power-armor-mk3"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-power-armor-mk3", {"advanced-tech-card"})
data_util.tech_remove_prerequisites("kr-power-armor-mk3", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-power-armor-mk3", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack","production-science-pack","space-science-pack","se-material-science-pack-1","se-energy-science-pack-1"})
data_util.tech_add_prerequisites("kr-power-armor-mk3", {"se-material-science-pack-1","se-energy-science-pack-1"})
data_util.replace_or_add_ingredient("power-armor-mk3", nil, "se-iridium-plate", 25)

--Power Armour Mk4
data.raw.technology["kr-power-armor-mk4"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-power-armor-mk4", {"kr-optimization-tech-card","singularity-tech-card"})
data_util.tech_remove_prerequisites("kr-power-armor-mk4", {"kr-singularity-tech-card"})
data_util.tech_add_ingredients("kr-power-armor-mk4", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack","production-science-pack","space-science-pack","se-material-science-pack-3","se-energy-science-pack-3"})
data_util.tech_add_prerequisites("kr-power-armor-mk4", {"kr-advanced-tech-card"})
data_util.replace_or_add_ingredient("power-armor-mk4", "ai-core", "ai-core", 10)
data_util.replace_or_add_ingredient("power-armor-mk4", "nitric-acid", "se-quantum-processor", 30)
data_util.replace_or_add_ingredient("power-armor-mk4", "imersite-crystal", "energy-control-unit", 15)
data_util.replace_or_add_ingredient("power-armor-mk4", "imersium-plate", "imersium-plate", 15)
data_util.replace_or_add_ingredient("power-armor-mk4", nil, "se-heavy-composite", 20)
data_util.replace_or_add_ingredient("power-armor-mk4", nil, "se-heavy-bearing", 5)

---- Thruster Suits
-- Apply K2 armour grids to the SE armours so that they have the same grid and categories
data.raw.armor["se-thruster-suit"].equipment_grid = "medium-equipment-grid"
data.raw.armor["se-thruster-suit-2"].equipment_grid = "large-equipment-grid"
data.raw.armor["se-thruster-suit-3"].equipment_grid = "mk3-armor-grid"
data.raw.armor["se-thruster-suit-4"].equipment_grid = "mk4-armor-grid"

-- Thruster Suit 3
data_util.tech_remove_ingredients("se-thruster-suit-3", {"se-biological-science-pack-1"})
data_util.tech_add_ingredients("se-thruster-suit-3", {"advanced-tech-card","se-biological-science-pack-3"})
data_util.tech_add_prerequisites("se-thruster-suit-3", {"kr-advanced-tech-card"})
data_util.replace_or_add_ingredient("thruster-suit-3", "processing-unit", "processing-unit", 50)
data_util.replace_or_add_ingredient("thruster-suit-3", nil, "energy-control-unit", 20)

-- Thruster Suit 4
data_util.replace_or_add_ingredient("thruster-suit-4", "processing-unit", "processing-unit", 100)
data_util.replace_or_add_ingredient("thruster-suit-4", nil, "energy-control-unit", 30)
data_util.replace_or_add_ingredient("thruster-suit-4", nil, "ai-core", 5)

-- Rebalance cost of Superiror Robot Battery tech
data.raw.technology["kr-robot-battery-plus"].check_science_packs_incompatibilities = false
data_util.tech_add_ingredients("kr-robot-battery-plus",{"automation-science-pack","logistic-science-pack","chemical-science-pack","space-science-pack","advanced-tech-card","se-energy-science-pack-3"})
data_util.tech_remove_ingredients("kr-robot-battery-plus",{"matter-tech-card"})
data_util.tech_remove_prerequisites("kr-robot-battery-plus", {"kr-matter-tech-card"})

---- Adaptive Armor
-- Alter ordering
data.raw.item["se-adaptive-armour-equipment-1"].subgroup = "character-equipment"
data.raw.item["se-adaptive-armour-equipment-1"].order = "s[energy-shield]-a1[adaptive-armour]"
data.raw.item["se-adaptive-armour-equipment-2"].subgroup = "character-equipment"
data.raw.item["se-adaptive-armour-equipment-2"].order = "s[energy-shield]-a2[adaptive-armour]"
data.raw.item["se-adaptive-armour-equipment-3"].subgroup = "character-equipment"
data.raw.item["se-adaptive-armour-equipment-3"].order = "s[energy-shield]-a3[adaptive-armour]"
data.raw.item["se-adaptive-armour-equipment-4"].subgroup = "character-equipment"
data.raw.item["se-adaptive-armour-equipment-4"].order = "s[energy-shield]-a4[adaptive-armour]"
data.raw.item["se-adaptive-armour-equipment-5"].subgroup = "character-equipment"
data.raw.item["se-adaptive-armour-equipment-5"].order = "s[energy-shield]-a5[adaptive-armour]"

-- Adaptive Armor 3
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-3",nil,"lithium-sulfur-battery",5)

-- Adaptive Armor 4
data_util.tech_add_prerequisites("se-adaptive-armour-equipment-4", {"kr-imersium-processing"})
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-4", "steel-plate", "imersium-plate", 20)

-- Adaptive Armor 5
data_util.tech_add_prerequisites("se-adaptive-armour-equipment-5", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("se-adaptive-armour-equipment-5", {"advanced-tech-card"})
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", "processing-unit", "processing-unit", 20)
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", "steel-plate", "imersium-plate", 40)
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", nil, "energy-control-unit", 5)

---- Power Producers
-- -- Rebalance Portable RTGs stats compared with K2 balancing
-- Portable RTG
data.raw.item["se-rtg-equipment"].subgroup = "equipment"
data.raw.item["se-rtg-equipment"].order = "a2[energy-source]-a41[portable-nuclear-core]"
data.raw["generator-equipment"]["se-rtg-equipment"].power = "800kW"
table.insert(data.raw["generator-equipment"]["se-rtg-equipment"].categories, "universal-equipment")

-- Portable RTG 2
data.raw.item["se-rtg-equipment-2"].subgroup = "equipment"
data.raw.item["se-rtg-equipment-2"].order = "a2[energy-source]-a42[portable-nuclear-core]"
data.raw["generator-equipment"]["se-rtg-equipment-2"].power = "1200kW"
table.insert(data.raw["generator-equipment"]["se-rtg-equipment-2"].categories, "universal-equipment")

---- Medical Items
-- For K2 make the first medpack only require the basic tech card
if data.raw.tool["basic-tech-card"] then
  data_util.tech_remove_ingredients("se-medpack", {"automation-science-pack"})
  data_util.tech_add_ingredients("se-medpack", {"basic-tech-card"})
  data.raw.technology["se-medpack"].prerequisites = {}
end

-- First Aid Kit
data_util.enable_recipe("first-aid-kit")
data.raw.capsule["first-aid-kit"].subgroup = "tool"
data.raw.capsule["first-aid-kit"].order = "a"
data.raw.capsule["first-aid-kit"].stack_size = 20
data.raw.capsule["first-aid-kit"].capsule_action = {
  attack_parameters = {
    ammo_category = "capsule",
    ammo_type = {
      action = {
        action_delivery = {
          target_effects = {
            damage = {
              amount = -25,
              type = "poison"
            },
            type = "damage"
          },
          type = "instant"
        },
        type = "direct"
      },
      category = "capsule",
      target_type = "position"
    },
    cooldown = 10,
    range = 0,
    type = "projectile"
  },
  type = "use-on-self"
}

-- Alt First Aid Kit
local first_aid_kit_2 = table.deepcopy(data.raw.recipe["first-aid-kit"])
first_aid_kit_2.name = "first-aid-kit-fish"
data:extend({first_aid_kit_2})
data_util.replace_or_add_ingredient("first-aid-kit-fish", "biomass", "raw-fish", 1)

-- Medpack 1
data_util.replace_or_add_ingredient("se-medpack", "iron-plate", "first-aid-kit", 1)
data_util.replace_or_add_ingredient("se-medpack", "wood", "wood", 2)
data_util.replace_or_add_ingredient("se-medpack", "raw-fish", "raw-fish", 1)
data_util.replace_or_add_ingredient("se-medpack", "biomass", "biomass", 1)

-- Alt Medpack 1
data_util.replace_or_add_ingredient("se-medpack-plastic", "iron-plate", "first-aid-kit", 1)

---- Capsules
-- Creep Virus capsule
--move_to_specialist_science_packs("kr-creep-virus", {"se-biological-science-pack-1"})
data_util.tech_remove_prerequisites("kr-creep-virus", {"kr-advanced-tech-card", "kr-military-5","kr-matter-tech-card"})
data_util.tech_remove_ingredients("kr-creep-virus", {"advanced-tech-card","matter-tech-card"})
data_util.tech_add_prerequisites("kr-creep-virus", {"se-vitalic-acid"})
data_util.tech_add_ingredients("kr-creep-virus", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "military-science-pack","se-biological-science-pack-1"})
data_util.replace_or_add_ingredient("kr-creep-virus","sulfuric-acid","se-vitalic-acid",25, true)
data_util.replace_or_add_ingredient("kr-creep-virus", nil, "se-genetic-data", 1)

-- Biter Virus capsule
--move_to_specialist_science_packs("kr-biter-virus", {"se-biological-science-pack-3"})
data_util.tech_remove_ingredients("kr-biter-virus", {"advanced-tech-card", "matter-tech-card"})
data_util.tech_add_prerequisites("kr-biter-virus", {"se-capsule-big-biter", "se-capsule-big-spitter"})
data_util.tech_add_ingredients("kr-biter-virus", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "military-science-pack","se-biological-science-pack-3"})
data_util.replace_or_add_ingredient("kr-biter-virus", "imersite-powder", "se-capsule-big-spitter", 1)
data_util.replace_or_add_ingredient("kr-biter-virus", "poison-capsule", "se-capsule-big-biter", 1)
data_util.replace_or_add_ingredient("kr-biter-virus", nil, "kr-creep-virus", 1)

---- Ammo
-- Tesla Gun Ammo
data_util.replace_or_add_ingredient("se-tesla-ammo", "battery", "lithium-sulfur-battery", 10)

---- Lasers
-- Personal Laser Defence Mk3
data.raw.technology["kr-personal-laser-defense-mk3-equipment"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-personal-laser-defense-mk3-equipment", {"advanced-tech-card"})
data_util.tech_remove_prerequisites("kr-personal-laser-defense-mk3-equipment", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-personal-laser-defense-mk3-equipment", {"automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","production-science-pack","kr-optimization-tech-card","space-science-pack","se-energy-science-pack-2"})
data_util.tech_add_prerequisites("kr-personal-laser-defense-mk3-equipment", {"se-energy-science-pack-2"})

-- Personal Laser Defense Mk4
data.raw.technology["kr-personal-laser-defense-mk4-equipment"].check_science_packs_incompatibilities = false
data_util.tech_remove_ingredients("kr-personal-laser-defense-mk4-equipment", {"singularity-tech-card","kr-optimization-tech-card"})
data_util.tech_remove_prerequisites("kr-personal-laser-defense-mk4-equipment", {"kr-singularity-tech-card"})
data_util.tech_add_ingredients("kr-personal-laser-defense-mk4-equipment", {"automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","production-science-pack","space-science-pack","se-energy-science-pack-4"})
data_util.tech_add_prerequisites("kr-personal-laser-defense-mk4-equipment", {"kr-advanced-tech-card","se-energy-science-pack-4"})

---- Exoskeleton
-- Advanced Exoskeleton
data_util.tech_add_prerequisites("kr-advanced-exoskeleton-equipment", {"production-science-pack"})
data_util.tech_add_ingredients("kr-advanced-exoskeleton-equipment", {"production-science-pack"})
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", "advanced-circuit", "processing-unit", 10)
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", "speed-module-2", "speed-module-3", 10)
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", nil, "lubricant", 10, true)
data.raw.recipe["advanced-exoskeleton-equipment"].category = "crafting-with-fluid"

-- Superiror Exoskeleton
data.raw.technology["kr-superior-exoskeleton-equipment"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-superior-exoskeleton-equipment", {"kr-advanced-tech-card"})
data_util.tech_remove_ingredients("kr-superior-exoskeleton-equipment", {"advanced-tech-card"})
data_util.tech_add_prerequisites("kr-superior-exoskeleton-equipment", {"production-science-pack","se-aeroframe-scaffold","se-heavy-bearing","speed-module-5"})
data_util.tech_add_ingredients("kr-superior-exoskeleton-equipment", {"automation-science-pack","logistic-science-pack","chemical-science-pack","production-science-pack","se-astronomic-science-pack-2","se-material-science-pack-2"})
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", "ai-core", "se-aeroframe-scaffold", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", "speed-module-3", "speed-module-5", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", nil, "se-heavy-bearing", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", nil, "processing-unit", 20)

---- Nightvision
-- Imersite Nightvision
data_util.tech_add_prerequisites("kr-imersite-night-vision-equipment", {"production-science-pack","space-science-pack"})
data_util.tech_add_ingredients("kr-imersite-night-vision-equipment", {"production-science-pack","space-science-pack"})

---- Vehicles
-- Tank
--move_to_specialist_science_packs("kr-advanced-tank", {"se-material-science-pack-2"})
data_util.tech_remove_prerequisites("kr-advanced-tank", {"kr-advanced-tech-card","kr-matter-tech-card"})
data_util.tech_remove_ingredients("kr-advanced-tank", {"advanced-tech-card","matter-tech-card"})
data_util.tech_add_prerequisites("kr-advanced-tank", {"se-heavy-bearing","kr-energy-control-unit","se-holmium-solenoid"})
data_util.tech_add_ingredients("kr-advanced-tank", {"automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","se-energy-science-pack-2","se-material-science-pack-2"}, true)
data_util.replace_or_add_ingredient("kr-advanced-tank", "imersium-gear-wheel", "imersium-gear-wheel", 20)
data_util.replace_or_add_ingredient("kr-advanced-tank", "low-density-structure", "low-density-structure", 50)
data_util.replace_or_add_ingredient("kr-advanced-tank", nil, "se-heavy-bearing", 20)
data_util.replace_or_add_ingredient("kr-advanced-tank", nil, "se-heavy-girder", 10)
data_util.replace_or_add_ingredient("kr-advanced-tank", nil, "se-holmium-solenoid", 10)
