local data_util = require("data_util")

-- This source is dedicated to making changes to K2 and SE entities

local function move_to_specialist_science_packs(tech_name, science_packs, require_imersium)
	data_util.tech_remove_ingredients(tech_name, {"kr-optimization-tech-card", "matter-tech-card", "advanced-tech-card", "se-deep-space-science-pack-1"})
	data_util.tech_remove_prerequisites(tech_name, {"kr-optimization-tech-card", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack-1"})
	data_util.tech_add_ingredients(tech_name, science_packs)
	data_util.tech_add_prerequisites(tech_name, science_packs)
	if require_imersium then
		data_util.tech_add_prerequisites(tech_name, {"kr-imersium-processing"})
	end
end

if krastorio.general.getSafeSettingValue("kr-containers") then
  -- Harmonize AAI Containers & Warehouses and Krastorio 2 versions
  -- Correct Medium Container and Warehouse item-subgroups
  data.raw.item["kr-medium-container"].subgroup = "kr-logistics-2"
  data.raw.item["kr-big-container"].subgroup = "kr-logistics-3"
  -- Correct item ordering within their groups.
  data.raw.item["kr-medium-container"].order = "b[storage]-3-a[kr-medium-container]"
  data.raw.item["kr-medium-passive-provider-container"].order = "b[storage]-3-b[kr-passive-provider-container]"
  data.raw.item["kr-medium-active-provider-container"].order = "b[storage]-3-c[kr-active-provider-container]"
  data.raw.item["kr-medium-storage-container"].order = "b[storage]-3-d[kr-storage-container]"
  data.raw.item["kr-medium-buffer-container"].order = "b[storage]-3-e[kr-buffer-container]"
  data.raw.item["kr-medium-requester-container"].order = "b[storage]-3-f[kr-requester-container]"
  --
  data.raw.item["kr-big-container"].order = "b[storage]-6-a[kr-big-container]"
  data.raw.item["kr-big-passive-provider-container"].order = "b[storage]-6-b[kr-big-passive-provider-container]"
  data.raw.item["kr-big-active-provider-container"].order = "b[storage]-6-c[kr-big-active-provider-container]"
  data.raw.item["kr-big-storage-container"].order = "b[storage]-6-d[kr-big-storage-container]"
  data.raw.item["kr-big-buffer-container"].order = "b[storage]-6-e[kr-big-buffer-container]"
  data.raw.item["kr-big-requester-container"].order = "b[storage]-6-f[kr-big-requester-container]"
  -- Correct Medium Container and Warehouse item-subgroups
  data.raw.recipe["kr-medium-container"].subgroup = "kr-logistics-2"
  data.raw.recipe["kr-big-container"].subgroup = "kr-logistics-3"
  -- Correct recipe ordering within their groups
  data.raw.recipe["kr-medium-container"].order = "b[storage]-3-a[kr-medium-container]"
  data.raw.recipe["kr-medium-passive-provider-container"].order = "b[storage]-3-b[kr-passive-provider-container]"
  data.raw.recipe["kr-medium-active-provider-container"].order = "b[storage]-3-c[kr-active-provider-container]"
  data.raw.recipe["kr-medium-storage-container"].order = "b[storage]-3-d[kr-storage-container]"
  data.raw.recipe["kr-medium-buffer-container"].order = "b[storage]-3-e[kr-buffer-container]"
  data.raw.recipe["kr-medium-requester-container"].order = "b[storage]-3-f[kr-requester-container]"
  --
  data.raw.recipe["kr-big-container"].order = "b[storage]-6-a[kr-big-container]"
  data.raw.recipe["kr-big-passive-provider-container"].order = "b[storage]-6-b[kr-big-passive-provider-container]"
  data.raw.recipe["kr-big-active-provider-container"].order = "b[storage]-6-c[kr-big-active-provider-container]"
  data.raw.recipe["kr-big-storage-container"].order = "b[storage]-6-d[kr-big-storage-container]"
  data.raw.recipe["kr-big-buffer-container"].order = "b[storage]-6-e[kr-big-buffer-container]"
  data.raw.recipe["kr-big-requester-container"].order = "b[storage]-6-f[kr-big-requester-container]"

  -- Adjust recipes of all of them to be the same so that one isn't cheaper than the other, but keep them existing in case of aestheric choices by the player.
  data_util.replace_or_add_ingredient("kr-big-container", "kr-medium-container", "concrete", 100)
  data_util.replace_or_add_ingredient("kr-big-container", nil, "steel-plate", 100)
  data_util.replace_or_add_ingredient("kr-big-container", "steel-beam", "steel-beam", 50)

  data_util.replace_or_add_ingredient("kr-big-passive-provider-container", "advanced-circuit", "advanced-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-passive-provider-container", nil, "electronic-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-active-provider-container", "advanced-circuit", "advanced-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-active-provider-container", nil, "electronic-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-storage-container", "advanced-circuit", "advanced-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-storage-container", nil, "electronic-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-buffer-container", "advanced-circuit", "advanced-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-buffer-container", nil, "electronic-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-requester-container", "advanced-circuit", "advanced-circuit", 20)
  data_util.replace_or_add_ingredient("kr-big-requester-container", nil, "electronic-circuit", 20)

  data_util.replace_or_add_ingredient("kr-medium-container", "steel-chest", "steel-plate", 15)
  data_util.replace_or_add_ingredient("kr-medium-container", "steel-beam", "steel-beam", 5)

  data_util.replace_or_add_ingredient("kr-medium-passive-provider-container", "advanced-circuit", "advanced-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-passive-provider-container", nil, "electronic-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-active-provider-container", "advanced-circuit", "advanced-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-active-provider-container", nil, "electronic-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-storage-container", "advanced-circuit", "advanced-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-storage-container", nil, "electronic-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-buffer-container", "advanced-circuit", "advanced-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-buffer-container", nil, "electronic-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-requester-container", "advanced-circuit", "advanced-circuit", 4)
  data_util.replace_or_add_ingredient("kr-medium-requester-container", nil, "electronic-circuit", 4)
end

-- Adjust cost of AAI Containers even if K2s Containers are disabled.
data_util.replace_or_add_ingredient("aai-strongbox", "steel-plate", "steel-plate", 15)
data_util.replace_or_add_ingredient("aai-strongbox", nil, "steel-beam", 5)

data_util.replace_or_add_ingredient("aai-storehouse", "steel-plate", "steel-plate", 50)
data_util.replace_or_add_ingredient("aai-storehouse", nil, "steel-beam", 25)

data_util.replace_or_add_ingredient("aai-warehouse", "steel-plate", "steel-plate", 100)
data_util.replace_or_add_ingredient("aai-warehouse", nil, "steel-beam", 50)

-- Advanced Assembler
-- Tell K2 to not check science pack coherance since SE-K2 has a different paradigm
data.raw.technology["kr-automation"].check_science_packs_incompatibilities = false
-- Make changes
move_to_specialist_science_packs("kr-automation", {"se-material-science-pack-2","kr-optimization-tech-card"})
data_util.tech_add_ingredients("kr-automation", {"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card"})
data_util.tech_add_prerequisites("kr-automation", {"se-heavy-bearing"})
data_util.tech_remove_prerequisites("kr-automation", {"kr-energy-control-unit"})
data_util.replace_or_add_ingredient("kr-advanced-assembling-machine", "ai-core", "se-heavy-bearing", 10)
data.raw.recipe["kr-advanced-assembling-machine"].subgroup = "assembling"
data.raw.item["kr-advanced-assembling-machine"].subgroup = "assembling"
table.insert(data.raw["assembling-machine"]["kr-advanced-assembling-machine"].crafting_categories, "crafting-or-electromagnetics")

-- Advanced Furnace
-- Tell K2 to not check science pack coherance since SE-K2 has a different paradigm
data.raw.technology["kr-advanced-furnace"].check_science_packs_incompatibilities = false
--Make Changes
move_to_specialist_science_packs("kr-advanced-furnace", {"se-material-science-pack-1"})
data_util.tech_add_ingredients("kr-advanced-furnace", {"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card","se-energy-science-pack-1"})
local adv_furnace = data.raw["assembling-machine"]["kr-advanced-furnace"]
adv_furnace.crafting_speed = 8
adv_furnace.module_specification.module_slots = 5

-- Advanced Chemical Plant
-- Tell K2 to not check science pack coherance since SE-K2 has a different paradigm
data.raw.technology["kr-advanced-chemical-plant"].check_science_packs_incompatibilities = false
--Make Changes
move_to_specialist_science_packs("kr-advanced-chemical-plant", {"se-biological-science-pack-2","kr-optimization-tech-card"})
data_util.tech_add_ingredients("kr-advanced-chemical-plant", {"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card"})
data.raw.recipe["kr-advanced-chemical-plant"].subgroup = "chemistry"
data.raw.item["kr-advanced-chemical-plant"].subgroup = "chemistry"
table.insert(data.raw["assembling-machine"]["kr-advanced-chemical-plant"].crafting_categories, "melting")

-- Rebalancing the K2 Fusion Reactor
data_util.tech_add_prerequisites("kr-fusion-energy", {"se-space-particle-collider"})
move_to_specialist_science_packs("kr-fusion-energy", {"se-energy-science-pack-3"})

-- 16720 to power 16 K2 Advanced Turbines, for an output of 1.6GW, pretty much the limit of efficiency for D-T Fusion.
data.raw.recipe["kr-fusion"].ingredients = {
	{ type = "fluid", name = "water", amount = 16720},
	{ type = "item", name = "dt-fuel", amount = 1 },
}
data.raw.recipe["kr-fusion"].results = {
	{ type = "fluid", name = "steam", amount = 16720, temperature = 975 },
	{ type = "item", name = "empty-dt-fuel", amount = 1 }
}
data.raw["generator"]["kr-advanced-steam-turbine"].max_power_output = "100MW"
data.raw["generator"]["kr-advanced-steam-turbine"].effectivity = 1
-- 1045/300 to get the correct consumption of 209/s of steam to make 100MW at 975C in the Factorio Engine.
data.raw["generator"]["kr-advanced-steam-turbine"].fluid_usage_per_tick = 1045/300

---- Supercomputers
-- Integrate the K2 AI Core into Neural Supercomputers recipe
data_util.tech_add_prerequisites("se-space-supercomputer-3",{"kr-ai-core"})
data_util.replace_or_add_ingredient("se-space-supercomputer-3","se-bioelectrics-data","ai-core", 50)
data_util.remove_ingredient_sub(data.raw.recipe["se-space-supercomputer-3"],"se-neural-gel-2")

-- Integrate the K2 AI Core into the Dimensional Anchor recipe
data_util.replace_or_add_ingredient("se-dimensional-anchor","se-quantum-processor","ai-core",8)

-- Update the Research Server recipe for its new role producing insights and sig data
data_util.replace_or_add_ingredient("kr-research-server", "advanced-circuit", "processing-unit", 50)
data_util.replace_or_add_ingredient("kr-research-server", "electronic-components", "se-space-assembling-machine", 1)

-- Add Imersium Beams to the Advanced Research Server recipe
data_util.replace_or_add_ingredient("kr-quantum-computer", "steel-beam", "imersium-beam", 20)
data_util.replace_or_add_ingredient("kr-quantum-computer", "copper-plate", "kr-research-server", 1)
data_util.replace_or_add_ingredient("kr-quantum-computer", "rare-metals", "se-holmium-solenoid", 20)

-- Adjust Pylon recipies to use Lithium-Sulfur batteries instead
data_util.replace_or_add_ingredient("se-pylon-substation","battery","lithium-sulfur-battery",16)
data_util.replace_or_add_ingredient("se-pylon-construction","battery","lithium-sulfur-battery",16)
data_util.replace_or_add_ingredient("se-pylon-construction-radar","battery","lithium-sulfur-battery",16)

-- Update the cost of the Advanced Robotport Tech
-- Tell K2 to not check science pack coherance since SE-K2 has a different paradigm
data.raw.technology["kr-advanced-roboports"].check_science_packs_incompatibilities = false
-- Make changes
data_util.tech_add_ingredients("kr-advanced-roboports",{"automation-science-pack","logistic-science-pack","chemical-science-pack","space-science-pack","se-material-science-pack-3","se-energy-science-pack-3"})

-- Include SE Resources in Advanced Roboport Recipes
data_util.replace_or_add_ingredient("kr-large-roboport","rare-metals","rare-metals",40)
data_util.replace_or_add_ingredient("kr-large-roboport",nil,"se-aeroframe-scaffold",20)
data_util.replace_or_add_ingredient("kr-large-roboport",nil,"se-heavy-composite",20)

data_util.replace_or_add_ingredient("kr-small-roboport","rare-metals","rare-metals",10)
data_util.replace_or_add_ingredient("kr-small-roboport",nil,"se-aeroframe-scaffold",5)
data_util.replace_or_add_ingredient("kr-small-roboport",nil,"se-heavy-composite",5)


-- Add Space Science packs to more K2 technologies
--Integrate Material Science and its products into K2 Belts.
data_util.tech_remove_prerequisites("kr-logistic-4", {"utility-science-pack"})
data_util.tech_add_prerequisites("kr-logistic-4", {"kr-imersium-processing","se-material-science-pack-1"})
data_util.tech_add_ingredients("kr-logistic-4", {"se-material-science-pack-1"})
data_util.replace_or_add_ingredient("kr-advanced-splitter","steel-gear-wheel","imersium-gear-wheel",4)
data_util.replace_or_add_ingredient("kr-advanced-transport-belt","steel-gear-wheel","imersium-gear-wheel",4)

data.raw.technology["kr-logistic-5"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-logistic-5", {"kr-advanced-tech-card"})
data_util.tech_remove_ingredients("kr-logistic-5", {"advanced-tech-card"})
data_util.tech_add_prerequisites("kr-logistic-5", {"kr-optimization-tech-card","se-heavy-bearing"})
data_util.tech_add_ingredients("kr-logistic-5", {"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card","se-material-science-pack-2"})
data_util.replace_or_add_ingredient("kr-superior-splitter",nil,"se-heavy-bearing",4)
data_util.replace_or_add_ingredient("kr-superior-transport-belt",nil,"se-heavy-bearing",4)

-- Supercomputer 4
data.raw.technology["se-space-supercomputer-4"].check_science_packs_incompatibilities = false
data_util.tech_add_ingredients("se-space-supercomputer-4", {"automation-science-pack","logistic-science-pack","chemical-science-pack","matter-tech-card"})

-- If K2 Advanced Lab exists, add it to the Space Science Laboratory recipe
if data.raw.item["biusart-lab"] then
	data_util.replace_or_add_ingredient("se-space-science-lab", "lab", "biusart-lab", 10)
	data_util.tech_add_prerequisites("se-space-science-lab", {"kr-advanced-lab"})
end

-- Replace Battery with Lithium-Sulfur Battery in the Space Science Laboratory recipe
data_util.replace_or_add_ingredient("se-space-science-lab","battery","lithium-sulfur-battery",10)

---- Production ----
-- Basic Beacon       = 0.5  *  8 modules =  4.0 module equivalent over 9*9 area
---- Energy 2 ----
-- Compact Beacon     = 0.75 * 10 modules =  7.5 module equivalent over 6*6 area
-- Wide Area Beacon   = 0.5  * 15 modules =  7.5 module equivalent over 32*32 area
---- DSS 2 ----
-- Compact Beacon 2   = 1.0  * 10 modules = 10.0 module equivalent over 6*6 area
-- Wide Area Beacon 2 = 0.5  * 20 modules = 10.0 module equivalent over 32*32 area

if data.raw.beacon["kr-singularity-beacon"] then
  ---- Graphics Conversion ----
	local adv_beacon = data.raw.beacon["kr-singularity-beacon"]
  local adv_beacon_item = data.raw.item["kr-singularity-beacon"]
	local compact_beacon_2 = data.raw.beacon["se-compact-beacon-2"]
  local compact_beacon_2_item = data.raw.item["se-compact-beacon-2"]

  -- Set Compact Beacon 2 graphics to the Advanced Beacon from K2
  compact_beacon_2.icon = adv_beacon.icon
  compact_beacon_2.icon_size = adv_beacon.icon_size
  compact_beacon_2.icon_mipmaps = adv_beacon.icon_mipmaps
  compact_beacon_2.base_picture = adv_beacon.base_picture
  compact_beacon_2.animation = adv_beacon.animation
  compact_beacon_2.animation_shadow = adv_beacon.animation_shadow
  compact_beacon_2.water_reflection = adv_beacon.water_reflection
  compact_beacon_2.open_sound = adv_beacon.open_sound
  compact_beacon_2.close_sound = adv_beacon.close_sound

  -- Set Adv Beacon module definition to have 15 modules to allow the migration to work correctly
  adv_beacon.module_specification.module_slots = 15

  -- Set item graphics
  compact_beacon_2_item.icon = adv_beacon_item.icon
  compact_beacon_2_item.icon_mipmaps = adv_beacon_item.icon_mipmaps

  -- Set recipe graphics
  data.raw.recipe["se-compact-beacon-2"].icon = data.raw.recipe["kr-singularity-beacon"].icon

  -- Make the Advanced Beacon item place the Compact Beacon 1 entity
  adv_beacon_item.place_result = "se-compact-beacon"

  -- Prevent the Advanced Beacon from being used to build Compact Beacon 1 in blueprints
  local compact_beacon_item = data.raw.item["se-compact-beacon"]
  if compact_beacon_item.flags == nil then
    compact_beacon_item.flags = {}
  end
  table.insert(compact_beacon_item.flags, "primary-place-result")

  -- Remove Advanced Beacon recipe.
  data_util.delete_recipe("kr-singularity-beacon")

  ---- Beacon Recipes ----
  -- Compact Beacon
  data_util.replace_or_add_ingredient("se-compact-beacon", "processing-unit", "processing-unit", 15)
  data_util.replace_or_add_ingredient("se-compact-beacon", "low-density-structure", "low-density-structure", 15)
  data_util.replace_or_add_ingredient("se-compact-beacon", "se-holmium-cable", "se-holmium-cable", 60)
  data_util.replace_or_add_ingredient("se-compact-beacon", nil, "energy-control-unit", 5)
  data_util.replace_or_add_ingredient("se-compact-beacon", nil, "imersium-plate", 10)

  -- Wide Area Beacon
  data_util.replace_or_add_ingredient("se-wide-beacon", "processing-unit", "processing-unit", 30)
  data_util.replace_or_add_ingredient("se-wide-beacon", "low-density-structure", "low-density-structure", 30)
  data_util.replace_or_add_ingredient("se-wide-beacon", "se-holmium-cable", "se-holmium-cable", 120)
  data_util.replace_or_add_ingredient("se-wide-beacon", nil, "energy-control-unit", 10)
  data_util.replace_or_add_ingredient("se-wide-beacon", nil, "imersium-plate", 20)

  ---- Beacon Technologies ----
  -- Compact Beacon
  data_util.tech_add_prerequisites("se-compact-beacon",{"kr-energy-control-unit"})

  -- Wide Area Beacon
  data_util.tech_add_prerequisites("se-wide-beacon",{"kr-energy-control-unit"})

  -- -- Compact Beacon 2
  local compact_beacon_2_tech = data.raw.technology["se-compact-beacon-2"]
  local adv_beacon_tech = data.raw.technology["kr-singularity-beacon"]
  -- Set technology graphics
  compact_beacon_2_tech.icon = adv_beacon_tech.icon
  compact_beacon_2_tech.icon_size = adv_beacon_tech.icon_size
  compact_beacon_2_tech.icon_mipmaps = adv_beacon_tech.icon_mipmaps
  -- Remove Advanced Beacon tech.
  data.raw.technology["kr-singularity-beacon"] = nil
 
end

-- Adjust Holmium Accumulator item to require Lithium-Sulfur Batteries
data_util.tech_add_prerequisites("se-space-accumulator",{"kr-energy-control-unit"})
data_util.replace_or_add_ingredient("se-space-accumulator",nil,"energy-control-unit",2)

-- Integrate the Miners.
data_util.tech_add_prerequisites("area-mining-drill", {"kr-electric-mining-drill-mk2"})
data_util.replace_or_add_ingredient("area-mining-drill", "electric-mining-drill", "kr-electric-mining-drill-mk2", 1)
data.raw.recipe["area-mining-drill"].order = "a[items]-c[electric-mining-drill-mk2]-b"
data.raw.item["area-mining-drill"].order = "a[items]-c[electric-mining-drill-mk2]-b"

-- Make MK3 miner an upgrade to the Area Miner
data.raw.technology["kr-electric-mining-drill-mk3"].check_science_packs_incompatibilities = false
data_util.tech_add_prerequisites("kr-electric-mining-drill-mk3", {"kr-advanced-tech-card","area-mining-drill","se-dynamic-emitter","se-heavy-composite"})
data_util.tech_add_ingredients("kr-electric-mining-drill-mk3", {"automation-science-pack","logistic-science-pack","chemical-science-pack","advanced-tech-card","se-material-science-pack-3","se-energy-science-pack-4"})
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "kr-electric-mining-drill-mk2", "area-mining-drill", 1)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "ai-core", "se-heavy-bearing", 10)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "imersite-crystal", "se-dynamic-emitter", 2)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", nil, "se-heavy-composite", 4)

local miner_mk3 = data.raw["mining-drill"]["kr-electric-mining-drill-mk3"]
table.insert(miner_mk3.resource_categories, "hard-resource")
miner_mk3.module_specification.module_slots = 5
miner_mk3.energy_usage = "500kW"
miner_mk3.mining_speed = 1.2

-- Laser Artillery Turret
move_to_specialist_science_packs("kr-laser-artillery-turret", {"se-energy-science-pack-2"})
data_util.tech_add_ingredients("kr-laser-artillery-turret", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "military-science-pack"})
data_util.tech_add_prerequisites("kr-laser-artillery-turret", {"se-holmium-solenoid", "se-heavy-girder"})
data_util.replace_or_add_ingredient("kr-laser-artillery-turret", "ai-core", "se-holmium-solenoid", 20)
data_util.replace_or_add_ingredient("kr-laser-artillery-turret", "steel-beam", "se-heavy-girder", 10)

move_to_specialist_science_packs("kr-rocket-turret", {"se-material-science-pack-1"})
data_util.replace_or_add_ingredient("kr-rocket-turret", "steel-beam", "se-heavy-girder", 10)

-- Railgun Turret
data_util.tech_add_ingredients("kr-railgun-turret", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack"})

-- Rocket Turret
data_util.tech_add_ingredients("kr-rocket-turret", {"automation-science-pack", "logistic-science-pack", "chemical-science-pack"})


---- Waterless Atmospheric Condenser
local waterless_prototype = table.deepcopy(data.raw["assembling-machine"]["kr-atmospheric-condenser"])
waterless_prototype.name = waterless_prototype.name .. "-_-" .. "waterless"
waterless_prototype.placeable_by = {item = "kr-atmospheric-condenser", count = 1}
data:extend({waterless_prototype})

-- Change recipe category of water condensation
data.raw.recipe["water-from-atmosphere"].category = "atmosphere-condensation-water"

-- Add Water to the regular Atmospheric Condenser
table.insert(data.raw["assembling-machine"]["kr-atmospheric-condenser"].crafting_categories, "atmosphere-condensation-water")