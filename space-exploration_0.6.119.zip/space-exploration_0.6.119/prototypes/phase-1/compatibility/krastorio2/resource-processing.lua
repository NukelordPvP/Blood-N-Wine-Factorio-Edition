local data_util = require("data_util")

-- This source is dedicated to maintaining compatability changes required for the K2 and SE resource processing steps.
-- E.G.
--  - Making sure K2 enrichment and SE molten metal casting are both available and the recipe amounts make sense as progressive levels of plate production efficiency
--  - Introducing changes to Iridium and Holomium to include the K2 Washing loop.

-- Remove Imersite Crystal to Imersite Powder recipe, it leads to loops and is unnecessary.
data_util.delete_recipe("imersite-crystal-to-dust")

-- Fine Imersite Powder
local fine_powder = {
  type = "item",
  name = "se-kr-fine-imersite-powder",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/fine-imersite-powder.png",
  icon_size = 64,
  group = "resources",
  subgroup = "imersite",
  order = "c",
  stack_size = 100
}
data:extend({fine_powder})

-- Imersium Sulfide
local imersium_sulfide = {
  type = "fluid",
  name = "se-kr-imersium-sulfide",
  default_temperature = 25,
  heat_capacity = "0.1KJ",
  max_temperature = 100,
  base_color = {r=136 , g=10, b=95},
  flow_color = {r=248 , g=76, b=244},
  icon = "__space-exploration-graphics__/graphics/compatability/icons/imersium-sulfide.png",
  icon_size = 64,
  icon_mipmaps = 1,
  order = "a[resource-fluid]-k2",
  pressure_to_speed_ratio = 0.4,
  flow_to_energy_ratio = 0.59,
  auto_barrel = true,
  subgroup = "space-fluids"
}
data:extend({imersium_sulfide})

-- Rebalance Coal Liquefaction to avoid creation of matter with Prod 9 modules
data.raw.recipe["coal-liquefaction"].ingredients = {
  {type = "item", name = "coal", amount = 10},
  {type = "fluid", name = "heavy-oil", amount = 25, catalyst_amount = 25},
  {type = "fluid", name = "steam", amount = 50},
}
data.raw.recipe["coal-liquefaction"].results = {
  {type = "fluid", name = "heavy-oil", amount = 85, catalyst_amount = 25},
  {type = "fluid", name = "light-oil", amount = 20},
  {type = "fluid", name = "petroleum-gas", amount = 10},
}

-- Rebalance Used Fuel Cell Reprocessing to avoid creation of matter with Prod 9 modules
krastorio.recipes.replaceProduct("nuclear-fuel-reprocessing", "uranium-238", {type = "item", name = "uranium-238", amount = 5})
krastorio.recipes.replaceProduct("nuclear-fuel-reprocessing", "stone", {type = "item", name = "stone", amount = 3})