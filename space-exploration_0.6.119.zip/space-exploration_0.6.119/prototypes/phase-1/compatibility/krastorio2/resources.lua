local data_util = require("data_util")

-- This source is dedicated to maintaining compatability changes required for the K2 and SE resources
-- E.G.
--  - Making sure meteors contain K2 Raw Rare metals when mined.
--  - Control the ability to gather gases from the atmosphere

-- Add Raw Rare Metals to meteor shower meteors
table.insert(data.raw["simple-entity"]["se-static-meteor-01"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-02"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-03"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-04"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-05"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-06"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-07"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-08"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-09"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-10"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-11"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-12"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-13"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-14"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-15"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})
table.insert(data.raw["simple-entity"]["se-static-meteor-16"].minable.results, {name = "raw-rare-metals", amount_min = 0, amount_max = 30})

---- Atmospheric Condenser Changes
-- Can't get hydrogen for free. Use electrolyser
data_util.delete_recipe("hydrogen")

-- Increase Oxygen and Nitrogen production amount, increase KW usage proportionally
-- Atmosphere composition is 70:20 Nitrogen:Oxygen, Nitrogen is easier to collect.
local oxygen = data.raw.recipe["oxygen"]
oxygen.energy_required = 10
oxygen.results = {
  {type = "fluid", name = "oxygen", amount = 300}
}

local nitrogen = data.raw.recipe["nitrogen"]
nitrogen.energy_required = 5
nitrogen.results = {
  {type = "fluid", name = "nitrogen", amount = 475}
}

-- Increase cost of Atmospheric Condensing
data.raw["assembling-machine"]["kr-atmospheric-condenser"].energy_usage = "400kW" --was 250kW

-- Correct Salt Water Electrolysis gas production ratios
local electrolysis = data.raw.recipe["kr-water-electrolysis"]
electrolysis.energy_required = 5
electrolysis.results = {
  {type = "fluid", name = "chlorine", amount = 20},
  {type = "fluid", name = "hydrogen", amount = 20},
}
data_util.disallow_productivity("kr-water-electrolysis")

-- Correct Water Seperation gas production ratios
local separation = data.raw.recipe["kr-water-separation"]
separation.energy_required = 6
separation.ingredients = {
  {type = "fluid", name = "water", amount = 60, catalyst_amount = 60}
}
separation.results = {
  {type = "fluid", name = "oxygen", amount = 20},
  {type = "fluid", name = "hydrogen", amount = 40},
}
data_util.disallow_productivity("kr-water-separation")

-- Correct Water Creation consumption ratios
local water = data.raw.recipe["kr-water"]
water.energy_required = 6
water.ingredients = {
  {type = "fluid", name = "oxygen", amount = 20},
  {type = "fluid", name = "hydrogen", amount = 40},
}
water.results = {
  {type = "fluid", name = "water", amount = 60}
}
data_util.disallow_productivity("kr-water")