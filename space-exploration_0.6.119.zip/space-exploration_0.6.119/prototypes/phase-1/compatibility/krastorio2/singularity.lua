local data_util = require("data_util")
-- Suggested Philosophy for Singularity in K2SE context:
-- Singularity Tech is the improvements of current technology with Arcosphere physics bending insights

-- Possible Future Idea
-- Create item 'Arcosphere Folding Observation Data' produced by acrosphere folding processes
-- Consume this item in more 'efficient' arcosphere folding recipes and the Singularity tech card
-- -- or --
-- Create multiple alternative singularity tech card recipes that switch much as the arcosphere
-- folding recipes do, each one requiring a specific polarisation of arcosphere?

-- Move Singularity Card to be unlocked by Deep Space Science Pack 3 and Matter Science Pack 2
data_util.tech_remove_prerequisites("kr-singularity-tech-card",{"kr-optimization-tech-card","kr-matter-processing","se-deep-space-science-pack-4"})
data_util.tech_remove_ingredients("kr-singularity-tech-card",{"se-deep-space-science-pack-4","matter-tech-card"})
data_util.tech_add_prerequisites("kr-singularity-tech-card",{"se-deep-space-science-pack-3","se-kr-matter-science-pack-2"})
data_util.tech_add_ingredients("kr-singularity-tech-card",{"se-deep-space-science-pack-3","se-kr-matter-science-pack-2"})


if data.raw.recipe["singularity-tech-card"] then
  local card = data.raw.recipe["singularity-tech-card"]
  card.category = "arcosphere"
  card.energy_required = 180
  card.allow_productivity = false
  card.ingredients = {
    {"se-deep-space-science-pack-3" , 6},
    {"se-significant-data", 1},
    {"ai-core", 1},
    {"se-arcosphere-a", 1}, -- lambda
    --{"se-arcosphere-b", 0}, -- xi
    --{"se-arcosphere-c", 0}, -- zeta
    {"se-arcosphere-d", 1}, -- theta
    {"se-arcosphere-e", 1}, -- epsilon
    --{"se-arcosphere-f", 0}, -- phi
    --{"se-arcosphere-g", 0}, -- gamma
    {"se-arcosphere-h", 1}, -- omega
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 200}
  }
  card.result = nil
  card.result_count = nil
  card.results = {
    {"singularity-tech-card", 8},
    {"se-junk-data", 4},
    {"se-broken-data", 1},
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 200},
    {"se-arcosphere-a", 1}, -- lambda
    {"se-arcosphere-b", 0}, -- xi
    {"se-arcosphere-c", 1}, -- zeta
    {"se-arcosphere-d", 0}, -- theta
    {"se-arcosphere-e", 1}, -- epsilon
    {"se-arcosphere-f", 0}, -- phi
    {"se-arcosphere-g", 1}, -- gamma
    {"se-arcosphere-h", 0}, -- omega
  }
  card.main_product = "singularity-tech-card"
  card.always_show_made_in = true
end

local card_alt = table.deepcopy(data.raw.recipe["singularity-tech-card"])
card_alt.name = "singularity-tech-card-alt"
card_alt.ingredients = {
  {"se-deep-space-science-pack-3" , 6},
  {"se-significant-data", 1},
  {"ai-core", 1},
  {"se-arcosphere-a", 1}, -- lambda
  --{"se-arcosphere-b", 0}, -- xi
  --{"se-arcosphere-c", 0}, -- zeta
  {"se-arcosphere-d", 1}, -- theta
  {"se-arcosphere-e", 1}, -- epsilon
  --{"se-arcosphere-f", 0}, -- phi
  --{"se-arcosphere-g", 0}, -- gamma
  {"se-arcosphere-h", 1}, -- omega
  { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 200}
}
card_alt.results = {
  {"singularity-tech-card", 8},
  {"se-junk-data", 4},
  {"se-broken-data", 1},
  { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 200},
  {"se-arcosphere-a", 0}, -- lambda
  {"se-arcosphere-b", 1}, -- xi
  {"se-arcosphere-c", 0}, -- zeta
  {"se-arcosphere-d", 1}, -- theta
  {"se-arcosphere-e", 0}, -- epsilon
  {"se-arcosphere-f", 1}, -- phi
  {"se-arcosphere-g", 0}, -- gamma
  {"se-arcosphere-h", 1}, -- omega
}
card_alt.icon = "__Krastorio2Assets__/icons/cards/singularity-tech-card.png"
card_alt.icon_size = 64
card_alt.icon_mipmaps = 4
card_alt.subgroup = "science-pack"
card_alt.order = "b11[singularity-tech-card]"
data:extend({card_alt})
table.insert(data.raw.technology["kr-singularity-tech-card"].effects, { type = "unlock-recipe", recipe = "singularity-tech-card-alt"})

-- Singularity Lab Recipe
data.raw.recipe["kr-singularity-lab"].category = "space-manufacturing"
data.raw.recipe["kr-singularity-lab"].ingredients = { -- this needs to change too much to make item by item changes
  {"se-space-science-lab", 1},
  {"se-space-radiator-2",8},
  {"se-space-hypercooler",2},
  {"ai-core", 50}, -- Biological
  {"se-heavy-composite",50}, -- Material
  {"se-dynamic-emitter",50}, -- Energy
  {"se-nanomaterial",50}, -- Astronomic
  { type = "fluid", name = "se-space-coolant-supercooled", amount = 2000},
}

-- K2 Antimatter reactor, renamed to Singularity Reactor in locale
data.raw.technology["kr-antimatter-reactor"].check_science_packs_incompatibilities = false
data_util.tech_add_prerequisites("kr-antimatter-reactor", {"se-antimatter-reactor"})
data_util.tech_add_ingredients("kr-antimatter-reactor", {"automation-science-pack","logistic-science-pack","chemical-science-pack","se-energy-science-pack-4","se-material-science-pack-4","se-kr-matter-science-pack-2","se-deep-space-science-pack-3"})
data_util.tech_remove_ingredients("kr-antimatter-reactor", {"kr-optimization-tech-card","advanced-tech-card","matter-tech-card"})

-- K2 Antimatter (Renamed to Singularity)
-- Add Naquium products to K2 Antimatter processes
data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-processor", 10)
data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-plate", 350)
data_util.replace_or_add_ingredient("kr-antimatter-reactor", "steel-plate", "se-antimatter-reactor", 1)

-- Ensure balanced efficiency for lack of logistical challenge for this energy producer
data.raw["burner-generator"]["kr-antimatter-reactor"].burner.effectivity = 0.8
data.raw["burner-generator"]["kr-antimatter-reactor"].max_power_output = "2GW"
data.raw.item["charged-antimatter-fuel-cell"].fuel_value = "100GJ" --same as antimatter cell

-- Add Singularity Tech Card to Teleportation Tech
data_util.tech_add_prerequisites("se-teleportation",{"kr-singularity-tech-card"})
data_util.tech_add_ingredients("se-teleportation",{"singularity-tech-card","se-kr-matter-science-pack-2"})

-- Move K2 Planetary Teleporter to require SE Teleportation Tech
data.raw.technology["kr-planetary-teleporter"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-planetary-teleporter",{"effect-transmission"})
data_util.tech_remove_ingredients("kr-planetary-teleporter",{"kr-optimization-tech-card","advanced-tech-card","matter-tech-card"})
data_util.tech_add_prerequisites("kr-planetary-teleporter",{"se-teleportation"})
data_util.tech_add_ingredients("kr-planetary-teleporter",{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-energy-science-pack-4","se-material-science-pack-4","se-deep-space-science-pack-4","se-kr-matter-science-pack-2"})

-- Add Singularity Tech Card to Arcolink Chest tech
data_util.tech_add_ingredients("se-linked-container",{"automation-science-pack","chemical-science-pack","singularity-tech-card","se-kr-matter-science-pack-2"})

-- Bring K2 Planetary Teleporter recipe closer in line with Arcolink Chest
-- No arcospheres due to same-surface restriction that currently exists?
data.raw.recipe["kr-planetary-teleporter"].ingredients = { -- this needs to change too much to make item by item changes
  {"se-nanomaterial", 10},
  {"se-lattice-pressure-vessel",10},
  {"se-heavy-assembly", 10},
  {"se-self-sealing-gel", 10},
  {"energy-control-unit", 10},
  {"se-dynamic-emitter", 10},
  {"se-naquium-processor", 10},
  {"teleportation-gps-module", 1}
}
