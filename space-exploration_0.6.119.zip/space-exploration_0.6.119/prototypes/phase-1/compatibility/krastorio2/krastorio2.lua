local data_util = require("data_util")

if mods["Krastorio2"] then
  -- Progression in base K2 had Production and Utility sciences before Rocket Science prior to v0_6
  -- Now that SE pushes Production and Utility to after Rocket Science but before the Specialist Sciecnes
  -- we need to adjust the tech progression in SE-K2.
  --
  -- Pre-Rocket Sciences
  -- Rocket Science
  -- Production/Utility/Optimization 1
  -- Material/Biological/Astronomic/Energy 1
  -- Material/Biological/Astronomic/Energy 2
  -- Material/Biological/Astronomic/Energy 3
  -- Optimization 2 (Advanced) / Matter 1
  -- Material/Biological/Astronomic/Energy 4
  -- Deep Space 1
  -- Deep Space 2
  -- Deep Space 3/Matter 2
  -- Optimisation 3 (Singularity)
  -- Deep Space 4

  -- Handle science pack compatibility manually
  table.insert(se_procedural_tech_exclusions, "kr-")

  for tech_name, technology in pairs(data.raw.technology) do
    if string.sub(tech_name, 1, 3) == "se-" then
      technology.check_science_packs_incompatibilities = false
    end
  end

  -- Ensure space collisisons are appropriate.
  require("prototypes/phase-1/compatibility/krastorio2/collisions")
  
  require("prototypes/phase-1/compatibility/krastorio2/entity")
  
  require("prototypes/phase-1/compatibility/krastorio2/resources")
  require("prototypes/phase-1/compatibility/krastorio2/resource-processing")
  require("prototypes/phase-1/compatibility/krastorio2/loaders")
  require("prototypes/phase-1/compatibility/krastorio2/equipment")
  require("prototypes/phase-1/compatibility/krastorio2/victory")
  require("prototypes/phase-1/compatibility/krastorio2/power")
  require("prototypes/phase-1/compatibility/krastorio2/science-production")
  require("prototypes/phase-1/compatibility/krastorio2/singularity")
  require("prototypes/phase-1/compatibility/krastorio2/intermediates")

  require("prototypes/phase-1/compatibility/krastorio2/items")
  require("prototypes/phase-1/compatibility/krastorio2/recipes")
  require("prototypes/phase-1/compatibility/krastorio2/technology")
end