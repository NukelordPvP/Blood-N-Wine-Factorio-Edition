collision_mask_util_extended = require("__combat-mechanics-overhaul__/collision-mask-util-extended/data/collision-mask-util-extended")
require("prototypes/phase-1/init-trigger-types")
require("prototypes/phase-1/init-named-collision-layers")
