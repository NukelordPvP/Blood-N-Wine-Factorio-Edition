table.insert(data.raw.wall['stone-wall'].resistances, {type = "cold",percent = 70}) 

if data.raw.wall['concrete-wall'] then 
table.insert(data.raw.wall['concrete-wall'].resistances, {type = "cold",percent = 80}) 
end

if data.raw.wall['steel-wall'] then 
table.insert(data.raw.wall['steel-wall'].resistances, {type = "cold",percent = 90}) 
end
