data:extend(
{
  {
    type = "damage-type",
    name = "cold"
  },
}
)
