local biter_tint1 = {r=0, g=0.1, b=0.9, a=1}
local biter_tint2 = {r=1, g=1, b=1, a=0.9}

local HEALTH_S = settings.startup["cb-HealthScaler"].value
local DAMAGE_S = settings.startup["cb-DamageScaler"].value

local sounds = require("__base__/prototypes/entity/sounds.lua")

local function make_biter_area_damage(damage,radius)
return  {
					type = "area",
					radius = radius,
					force = "enemy",
					ignore_collision_condition = true,
					action_delivery =
					{
					  type = "instant",
					  target_effects =
					  {
						{
						  type = "damage",
						  damage = {amount = damage, type = "physical"}
						},
						{
						type = "create-particle",
						repeat_count = 5,
						particle_name = "explosion-remnants-particle",
						initial_height = 0.5,
						speed_from_center = 0.08,
						speed_from_center_deviation = 0.15,
						initial_vertical_speed = 0.08,
						initial_vertical_speed_deviation = 0.15,
						offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
						},
					  }
					}
                   }
end




function make_boss(k)
local scale = 1.5 + k/3
local base_resist = 17+k*2
local resistances =  
    {
      {
        type = "physical",
        decrease = k,
        percent = base_resist,
      },
      {
        type = "explosion",
        percent = -40,
      },
      {
        type = "laser",
        percent = base_resist,
      },
      {
        type = "impact",
        percent = base_resist,
      },

      {
        type = "fire",
        percent = -100,
      },
      {
        type = "electric",
        percent = -20,
      },
      {
        type = "poison",
        percent = base_resist,
      },
      {
        type = "acid",
        percent = base_resist,
      },
    }
	
data:extend(
{


  {
    type = "unit",
    name = "maf-boss-frost-biter-"..k,
	localised_name =  {"",{"entity-name.maf-boss-frost-biter"}," ",k},
    order="b-f-y-BOSS"..k,
    icon = "__base__/graphics/icons/big-biter.png",   icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000 * k * HEALTH_S,
    subgroup="enemies",
    resistances = resistances,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.7, -2.4}, {1.7, 2.4}},
    sticker_box = {{-0.7, -1.2}, {0.7, 0.2}},
    distraction_cooldown = 100,
	call_for_help_radius = 100+k*5,	
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
    attack_parameters =
                {
                    type = "projectile",
                    range = 1+k/5,
                    cooldown = 35,
                    sound =  sounds.biter_roars_behemoth(0.9),
                    animation = biterattackanimation(scale, biter_tint1, biter_tint2),
      ammo_type = 
      {
        category = "melee",
        target_type = "entity",
        action =
        {
		   make_biter_area_damage((50+k*10)* DAMAGE_S,k+1),
          {
		  type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              {
                type = "damage",
                damage = { amount = (70+k*25) *DAMAGE_S, type = "physical"}
              },
              {
                type = "damage",
                damage = { amount = (30+k*15) *DAMAGE_S , type = "cold"}
              }
            }
          }}
        }
      },
                },	
	
    vision_distance = 30,
    movement_speed = 0.17,
    distance_per_frame = 0.2,
    -- in pu
    pollution_to_join_attack = 300,
    corpse = "corpse-maf-boss-frost-biter-"..k,
    dying_explosion = "small-atomic-cold-explosion",
    working_sound = sounds.biter_calls_big(1.4),
    dying_sound = sounds.biter_dying_big(1),
    walking_sound = sounds.biter_walk_big(1.2),
	running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-biter'].damaged_trigger_effect),
	water_reflection = biter_water_reflection(scale),	
    run_animation = biterrunanimation(scale,biter_tint1, biter_tint2),
	ai_settings = {destroy_when_commands_fail = false}
  },
 
  add_biter_die_animation(scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "corpse-maf-boss-frost-biter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selection_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-f[frost]-y-BOSS"..k,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.01,
  }),  


 
  {
    type = "unit",
    name = "maf-boss-frost-spitter-"..k,
	localised_name =  {"",{"entity-name.maf-boss-frost-spitter"}," ",k},
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health =  30000*k *HEALTH_S,
    order="b-fs-y-BOSS"..k,	
    subgroup="enemies",
	resistances = resistances,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
	collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{-3.4, -3.4}, {3.4, 3.4}},
	sticker_box = {{-0.4, -0.6}, {0.4, 0.2}},
    distraction_cooldown = 100,
    loot =  { },
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???	
	attack_parameters = spitter_behemoth_attack_parameters(
	  {
      acid_stream_name = "cb-cluster-cold-projectile-boss",
      range=40+k*2,
      min_attack_distance=10,
      cooldown=130-k*3,
	  cooldown_deviation = 0.15,
      damage_modifier=12+k*4*DAMAGE_S,
      scale=scale,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"	  

    }),	
	vision_distance = 80+k,
    movement_speed = 0.07+ k/150,
    distance_per_frame = 0.04,
    pollution_to_join_attack = 400,
    corpse = "corpse-maf-boss-frost-spitter-"..k,
    dying_explosion = "small-atomic-cold-explosion",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale, biter_tint1, biter_tint2),
	ai_settings = {destroy_when_commands_fail = false}
  },


  add_spitter_die_animation(scale,biter_tint, biter_tint2,
  {
    type = "corpse",
    name = "corpse-maf-boss-frost-spitter-"..k,
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-ts[spitter]-e[leviathan]-BOSS"..k,
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.01,
  }),   


  
})
end


for k=1,10 do make_boss(k) end