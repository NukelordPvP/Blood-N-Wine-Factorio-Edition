require ("prototypes.values")
local sounds = require("__base__/prototypes/entity/sounds.lua")


local scale_spitter_small    = 0.5
local scale_spitter_medium   = 0.7
local scale_spitter_big      = 1.0
local scale_spitter_behemoth = 1.2
local leviathan_scale=2.5

local biter_tint1 = {r=0, g=0.1, b=0.9, a=1}
local biter_tint2 = {r=1, g=1, b=1, a=0.9}

local HEALTH_S = settings.startup["cb-HealthScaler"].value
local DAMAGE_S = settings.startup["cb-DamageScaler"].value


local stream_cluster_small = "cb-cluster-cold-projectile-small"
local stream_cluster_big = "cb-cluster-cold-projectile-big" 

if settings.startup["cb-disable-cluster-spit"].value then
	stream_cluster_small = "cb-cold-stream-small"
	stream_cluster_big = "cb-cold-stream-big"
	end



data:extend(
{

   {
    type = "unit",
    name = "small-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 10*HEALTH_S,
    order="b-fs-a",
    subgroup="enemies",
	resistances =cold_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
    attack_parameters = spitter_attack_parameters(
    {
      acid_stream_name = "cb-cold-stream-small",
      range=13,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,	  
      damage_modifier=DAMAGE_S*damage_modifier_spitter_small,
      scale=scale_spitter_small,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=0.4,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),
    vision_distance = 30,
    movement_speed = 0.185,
    distance_per_frame = 0.04,
    -- in pu
    pollution_to_join_attack = 4,
    corpse = "small-cold-spitter-corpse",
    dying_explosion = "cb-cold-explosion",
    working_sound = sounds.spitter_calls(0.7),
    dying_sound = sounds.spitter_dying(0.4),
    walking_sound = sounds.spitter_walk(0.3),	
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['small-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_small),
    run_animation = spitterrunanimation(scale_spitter_small, biter_tint1, biter_tint2),
    ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "medium-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50*HEALTH_S,
    order="b-fs-b",
    subgroup="enemies",
	resistances =cold_resists,
    healing_per_tick = 0.01,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.7}, {0.5, 0.7}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
    attack_parameters = spitter_attack_parameters(
    {
      acid_stream_name = "cb-cold-stream-small",
      range=14,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,	  
      damage_modifier=damage_modifier_spitter_medium*DAMAGE_S,
      scale=scale_spitter_medium,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=0.5,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),
    vision_distance = 30,
    movement_speed = 0.165,
    distance_per_frame = 0.055,
    -- in pu
    pollution_to_join_attack = 12,
    corpse = "medium-cold-spitter-corpse",
    dying_explosion = "cb-medium-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['medium-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['medium-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['medium-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['medium-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_medium),	
    run_animation = spitterrunanimation(scale_spitter_medium, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },

  
  {
    type = "unit",
    name = "big-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 200*HEALTH_S,
    order="b-fs-c",
    subgroup="enemies",
	resistances =cold_resists,
    spawning_time_modifier = 3,
    healing_per_tick = 0.01,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
    attack_parameters = spitter_attack_parameters(
    {
      acid_stream_name = stream_cluster_small,
      range=15,
      min_attack_distance=7,
      cooldown=100,
	  cooldown_deviation = 0.15,	  
      damage_modifier=damage_modifier_spitter_big*DAMAGE_S,
      scale=scale_spitter_big,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=0.6,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.07,
    -- in pu
    pollution_to_join_attack = 30,
    corpse = "big-cold-spitter-corpse",
    dying_explosion = "cb-big-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['big-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['big-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['big-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
	water_reflection = spitter_water_reflection(scale_spitter_big),	
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['big-spitter'].damaged_trigger_effect),
    run_animation = spitterrunanimation(scale_spitter_big, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },

  {
    type = "unit",
    name = "behemoth-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 1500*HEALTH_S,
    order="b-fs-d",
    subgroup="enemies",
	resistances =cold_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{-0.7, -1.0}, {0.7, 1.0}},
    sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
    distraction_cooldown = 300,
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
	attack_parameters = spitter_attack_parameters(
	  {
      acid_stream_name = stream_cluster_big,
      range=16,
      min_attack_distance=10,
      cooldown=100,
	  cooldown_deviation = 0.15,	  
      damage_modifier=damage_modifier_spitter_behemoth*DAMAGE_S,
      scale=scale_spitter_behemoth,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=0.7,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),	
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.084,
    pollution_to_join_attack = 250,
    corpse = "behemoth-cold-spitter-corpse",
    dying_explosion = "cb-big-artillery-cold-explosion",
    working_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].working_sound),
    dying_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].dying_sound),
    walking_sound = table.deepcopy(data.raw['unit']['behemoth-spitter'].walking_sound),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(scale_spitter_behemoth),	
    run_animation = spitterrunanimation(scale_spitter_behemoth, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },


  
  
  {
    type = "unit",
    name = "leviathan-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 50000*HEALTH_S,
    order="b-fs-l",
    subgroup="enemies",
	resistances = cold_leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.7, -2.4}, {1.7, 2.4}},
    sticker_box = {{-0.7, -1.2}, {0.7, 0.2}},
    distraction_cooldown = 300,
    loot = {},	
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
	attack_parameters = spitter_attack_parameters(
	  {
      acid_stream_name = stream_cluster_big,
      range=22,
      min_attack_distance=11,
      cooldown=100,
	  cooldown_deviation = 0.15,	  
      damage_modifier=90*DAMAGE_S,
      scale=leviathan_scale,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=0.8,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),	
    vision_distance = 50,
    movement_speed = 0.15,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 700,
    corpse = "leviathan-cold-spitter-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    working_sound = sounds.spitter_calls_big(1),
    dying_sound = sounds.spitter_dying_big(1),
    walking_sound = sounds.spitter_walk_big(0.9),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(leviathan_scale),	
    run_animation = spitterrunanimation(leviathan_scale, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },
  


  
  -- CORPSES  *********************************
  
  
  add_spitter_die_animation(leviathan_scale, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "leviathan-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-0.9, -1.2}, {0.9, 1.2}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-l[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.02,
  }),    
 
  add_spitter_die_animation(scale_spitter_small, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "small-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-a[small]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_medium, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "medium-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-b[medium]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),    
   
  add_spitter_die_animation(scale_spitter_big, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "big-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-c[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
  
  add_spitter_die_animation(scale_spitter_behemoth, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "behemoth-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-d[behemoth]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
  }),   
 
  
})



if not settings.startup["cb-disable-mother"].value then
data:extend(
{
 
  {
    type = "unit",
    name = "mother-cold-spitter",
    icon = "__base__/graphics/icons/big-spitter.png",
	icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
    max_health = 100000*HEALTH_S,
    order="b-fs-m",
    subgroup="enemies",
	resistances = cold_leviathan_resists,
    spawning_time_modifier = 12,
    healing_per_tick = 0.1,
    collision_box = {{-2, -2}, {2, 2}},
    selection_box = {{-2, -2}, {2, 2}},
    sticker_box = {{-1.5, -1.5}, {1.5, 1.5}},
    distraction_cooldown = 300,
    loot = {},	
    min_pursue_time = 10 * 60,
    max_pursue_distance = 50,
	alternative_attacking_frame_sequence = spitter_alternative_attacking_animation_sequence, --???
	attack_parameters = spitter_attack_parameters(
	  {
      acid_stream_name = "cb-cluster-coldmother-projectile-big",
      range=35,
      min_attack_distance=11,
      cooldown=400,
	  cooldown_deviation = 0.15,	  
      damage_modifier=120*DAMAGE_S,
      scale=leviathan_scale +1,
      tint1=biter_tint1,
      tint2=biter_tint2,
      roarvolume=2,
	  range_mode = "bounding-box-to-bounding-box"	  
    }),	
    vision_distance = 80,
    movement_speed = 0.10,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 1000,
    corpse = "mother-cold-spitter-corpse",
    dying_explosion = "small-atomic-cold-explosion",
    working_sound = sounds.spitter_calls_big(1.2),
    dying_sound = sounds.spitter_dying_big(1.2),
    walking_sound = sounds.spitter_walk_big(1),
    running_sound_animation_positions = {2,},
    damaged_trigger_effect = table.deepcopy(data.raw['unit']['behemoth-spitter'].damaged_trigger_effect),
	water_reflection = spitter_water_reflection(leviathan_scale+1),	
    run_animation = spitterrunanimation(leviathan_scale+1, biter_tint1, biter_tint2),
	ai_settings = biter_ai_settings
  },

  
  add_spitter_die_animation(leviathan_scale+1, biter_tint1, biter_tint2,
  {
    type = "corpse",
    name = "mother-cold-spitter-corpse",
    icon = "__base__/graphics/icons/big-biter-corpse.png",
    icon_size = 64, icon_mipmaps = 4,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    subgroup="corpses",
    order = "c[corpse]-fs[spitter]-m[leviathan]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
	dying_speed = 0.007,
  }),  
  
})
end