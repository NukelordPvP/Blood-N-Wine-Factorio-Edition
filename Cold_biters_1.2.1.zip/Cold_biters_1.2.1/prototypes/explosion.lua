local sounds = require("__base__/prototypes/entity/sounds.lua")
ENTITYPATH = "__Cold_biters__/graphics/entity/"
local DAMAGE_S = settings.startup["cb-DamageScaler"].value


data:extend(
{
  {
    type = "explosion",
    name = "cold-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = ENTITYPATH .. "explosion-1.png",
        priority = "high",
        width = 64,
        height = 59,
        frame_count = 16,
        animation_speed = 0.5
      },
      {
        filename = ENTITYPATH .. "explosion-2.png",
        priority = "high",
        width = 64,
        height = 57,
        frame_count = 16,
        animation_speed = 0.5
      },
      {
        filename = ENTITYPATH .. "explosion-3.png",
        priority = "high",
        width = 64,
        height = 49,
        frame_count = 16,
        animation_speed = 0.5
      },
      {
        filename = ENTITYPATH .. "explosion-4.png",
        priority = "high",
        width = 64,
        height = 51,
        frame_count = 16,
        animation_speed = 0.5
      }
    },
    light = {intensity = 1, size = 20, color = {r=1.0, g=1.0, b=1.0}},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1,
    sound = sounds.small_explosion(0.5),
  },
  
  
  

  {
    type = "explosion",
    name = "medium-cold-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = ENTITYPATH .. "medium-explosion.png",
        priority = "high",
        width = 112,
        height = 94,
        frame_count = 54,
        line_length = 6,
        shift = {-0.56, -0.96},
        animation_speed = 0.5
      }
    },
    light = {intensity = 1, size = 50, color = {r=1.0, g=1.0, b=1.0}},
    sound = sounds.large_explosion(0.7),
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-particle",
            repeat_count = 20,
            particle_name = "explosion-remnants-particle",
            initial_height = 0.5,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            initial_vertical_speed = 0.08,
            initial_vertical_speed_deviation = 0.15,
            offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
          }
        }
      }
    }
  },




  {
    type = "explosion",
    name = "big-cold-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = ENTITYPATH .. "big-explosion.png",
        flags = { "compressed" },
        width = 197,
        height = 245,
        frame_count = 47,
        line_length = 6,
        shift = {0.1875, -0.75},
        animation_speed = 0.5
      }
    },
    light = {intensity = 1, size = 50, color = {r=1.0, g=1.0, b=1.0}},
    sound = sounds.large_explosion(0.8),
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-particle",
            repeat_count = 20,
            particle_name = "explosion-remnants-particle",
            initial_height = 0.5,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            initial_vertical_speed = 0.08,
            initial_vertical_speed_deviation = 0.15,
            offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
          }
        }
      }
    }
  },










   {
    type = "explosion",
    name = "big-artillery-cold-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = ENTITYPATH .. "hr-bigass-explosion-36f.png",
        flags = { "compressed" },
        animation_speed = 0.5,
        width = 324,
        height = 416,
        frame_count = 36,
        shift = util.by_pixel(0, -48),
        stripes =
        {
          {
            filename = ENTITYPATH .. "hr-bigass-explosion-36f-1.png",
            width_in_frames = 6,
            height_in_frames = 3
          },
          {
            filename = ENTITYPATH .. "hr-bigass-explosion-36f-2.png",
            width_in_frames = 6,
            height_in_frames = 3
          }
        }
      }
    },
    light = {intensity = 1, size = 50, color = {r=1.0, g=1.0, b=1.0}},
    sound = sounds.large_explosion(1.0),
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-particle",
            repeat_count = 5,
            particle_name = "explosion-remnants-particle",
            initial_height = 0.5,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            initial_vertical_speed = 0.08,
            initial_vertical_speed_deviation = 0.15,
            offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
          }
        }
      }
    }
  },
  
  
  
  
  
  
  
  
  
    {
    type = "projectile",
    name = "atomic-cold-wave",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-entity",
              entity_name = "cold-explosion"
            }
          }
        }
      },
      {
        type = "area",
        radius = 3,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            type = "damage",
            damage = {amount = 400, type = "cold"}
          }
        }
      }
    },
    animation =
    {
      filename = "__core__/graphics/empty.png",
      frame_count = 1,
      width = 1,
      height = 1,
      priority = "high"
    },
    shadow =
    {
      filename = "__core__/graphics/empty.png",
      frame_count = 1,
      width = 1,
      height = 1,
      priority = "high"
    }
  },
  
  
  
  
  
   {
    type = "explosion",
    name = "small-atomic-cold-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = ENTITYPATH .. "medium-explosion.png",
        priority = "extra-high",
        width = 112,
        height = 94,
        scale = 0.8,
        frame_count = 54,
        line_length = 6,
        shift = {-0.56, -0.96},
        animation_speed = 0.5
      }
    },
    light = {intensity = 1, size = 50, color = {r=1.0, g=1.0, b=1.0}},
    sound = sounds.large_explosion(1.0),
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-particle",
            repeat_count = 60,
            particle_name = "explosion-remnants-particle",
            initial_height = 0.5,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            initial_vertical_speed = 0.08,
            initial_vertical_speed_deviation = 0.15,
            offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}}
          },
          {
            type = "nested-result",
            action =
            {
              type = "area",
              target_entities = false,
			         trigger_from_target = true,
              repeat_count = 1000,
			         radius = 10,
              action_delivery =
              {
                type = "projectile",
                projectile = "atomic-cold-wave",
                starting_speed = 0.4
              }
            }
          }
		  
		  
        }
      }
    }
  },

  
})





function cb_create_explosion(explosion_name,damage,radius)
data:extend({

   {
    type = "explosion",
    name = "cb-"..explosion_name,
    flags = {"not-on-map"},
    animations = table.deepcopy(data.raw.explosion[explosion_name].animations),
   -- light = {intensity = 0.7, size = radius * 10, color = {r=1.0, g=1.0, b=1.0}},
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "nested-result",
            action =
            {
              type = "area",
              radius = radius,
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                  {
                    type = "damage",
                    damage = {amount = damage*DAMAGE_S , type = "cold"}
                  }
                }
              }
            }
          },		
	
          {
            type = "create-entity",
            entity_name = explosion_name
          },
		  
        }
      }
    }
  }



})
end


cb_create_explosion("cold-explosion",90,2)   -- cb-cold-explosion
cb_create_explosion("medium-cold-explosion",140,3) -- cb-medium-cold-explosion
cb_create_explosion("big-cold-explosion",190,4) -- cb-big-cold-explosion
cb_create_explosion("big-artillery-cold-explosion",250,5)  --  cb-big-artillery-cold-explosion
