
local replaces = {
	['small-cold-worm-turret']={'small-worm-turret'},
	['medium-cold-worm-turret']={'medium-worm-turret'},
	['big-cold-worm-turret']={'big-worm-turret'},
	['behemoth-cold-worm-turret']={'behemoth-worm-turret'},
	['leviathan-cold-worm-turret']={'behemoth-worm-turret'},
	['mother-cold-worm-turret']={'behemoth-worm-turret'},
	['cb-cold-spawner']={'biter-spawner','spitter-spawner'},
	}
	

local names = {'small-cold-biter',
'medium-cold-biter',
'big-cold-biter',
'behemoth-cold-biter',
'leviathan-cold-biter',
'small-cold-spitter',
'medium-cold-spitter',
'big-cold-spitter',
'behemoth-cold-spitter',
'leviathan-cold-spitter',
'cb-cold-spawner',
'mother-cold-spitter',
'small-cold-worm-turret',
'medium-cold-worm-turret',
'big-cold-worm-turret',
'behemoth-cold-worm-turret',
'leviathan-cold-worm-turret',
'mother-cold-worm-turret'}



function On_Died(event)
local ent = event.entity	
local cloud = 'cold-cloud-1'
if string.find(ent.name,'leviathan') or string.find(ent.name,'mother') then	cloud = 'cold-cloud-2' end
ent.surface.create_entity{name=cloud, position=ent.position, force=ent.force}
end
local filters = {}
for n=1,#names do table.insert(filters, {filter = "name", name = names[n]}) end
script.on_event(defines.events.on_entity_died, On_Died, filters) 


local function GetLocalTemperature(surface,position)
local temperature
local calc = surface.calculate_tile_properties({'temperature'},{position}) 
if calc and calc.temperature then
	temperature = calc.temperature[1] end
return temperature
end

script.on_event(defines.events.on_biter_base_built, function(event)
if not settings.startup["cb-disable-temperature-check"].value then


local entity=event.entity
if replaces[entity.name] then
	local position=entity.position
	local surface=entity.surface
	local force=entity.force
	local temperature = GetLocalTemperature(surface,position) 
	if temperature then 
		if temperature > global.temp_max or temperature < global.temp_min then
			local name   = entity.name
			local replac = replaces[name][math.random(#replaces[name])]
			entity.destroy()
			surface.create_entity{name=replac, position=position, force=force} 
			end
		end
	end
	
end
end)


local function SetTemperatures()
global.temp_min = 0
global.temp_max = 25
if game.active_mods['alien-biomes']  then 
	global.temp_min=-50 --frozen areas
	global.temp_max=10  
	end
end


local function on_configuration_changed(data)
SetTemperatures()
end

local function on_init()
SetTemperatures()
end

script.on_configuration_changed(on_configuration_changed)
script.on_init(on_init)
