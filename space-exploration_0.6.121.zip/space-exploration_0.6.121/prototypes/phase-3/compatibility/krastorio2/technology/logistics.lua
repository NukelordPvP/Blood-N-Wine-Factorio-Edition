local data_util = require("data_util")

-- Effect Transmission
-- K2 sets this research cost to 500, we return it to SEs value
data.raw.technology["effect-transmission"].unit.count = 75
