local data_util = require("data_util")

data_util.remove_recipe_from_effects(data.raw.technology["se-pulveriser"].effects, "se-pulverised-sand")
data_util.delete_recipe("se-pulverised-sand")
data_util.delete_recipe("glass-from-sand")