local path = "prototypes/phase-2/compatibility/krastorio2/entity/"


require(path .. "science_labs")
require(path .. "power")